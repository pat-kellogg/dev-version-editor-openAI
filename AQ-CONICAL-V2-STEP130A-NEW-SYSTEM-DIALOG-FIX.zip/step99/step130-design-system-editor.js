(function(){
  'use strict';
  const ROLES=['surface.default','surface.accent','text.primary','text.muted','radius.default','spacing.sm','spacing.md','spacing.lg'];
  const TEMPLATES={
    'AQ Default':{'surface.default':'#ffffff','surface.accent':'#2563eb','text.primary':'#0f172a','text.muted':'#475569','radius.default':'16px','spacing.sm':'8px','spacing.md':'16px','spacing.lg':'24px'},
    'Brand':{'surface.default':'#b91c1c','surface.accent':'#4f46e5','text.primary':'#ffffff','text.muted':'#ffffff','radius.default':'0px','spacing.sm':'8px','spacing.md':'24px','spacing.lg':'32px'},
    'Ocean Test':{'surface.default':'#006D77','surface.accent':'#FF5DA2','text.primary':'#FFF4A3','text.muted':'#FFFFFF','radius.default':'20px','spacing.sm':'10px','spacing.md':'24px','spacing.lg':'36px'},
    'Shock Test':{'surface.default':'#3B0A45','surface.accent':'#39FF14','text.primary':'#FFFFFF','text.muted':'#FFFFFF','radius.default':'0px','spacing.sm':'12px','spacing.md':'32px','spacing.lg':'48px'},
    'Minimal Test':{'surface.default':'#FFFFFF','surface.accent':'#E5E7EB','text.primary':'#111827','text.muted':'#4B5563','radius.default':'4px','spacing.sm':'8px','spacing.md':'16px','spacing.lg':'24px'}
  };
  let selectedId='', draft=null;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slug=s=>String(s||'design-system').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  function registry(){return window.AQDesignSystemRegistry}
  function uniqueId(name){let base=slug(name),id=base,n=2;while(registry().has(id))id=base+'-'+n++;return id}
  function semanticTokens(system){
    if(!system)return {...TEMPLATES['AQ Default']};
    if(system.id==='aq-default')return {...TEMPLATES['AQ Default']};
    if(system.id==='brand-default')return {...TEMPLATES.Brand};
    const map=(system.metadata&&system.metadata.semanticMapping)||{};
    const out={}; ROLES.forEach(r=>out[r]=(system.tokens||{})[map[r]||r]);
    return Object.assign({...TEMPLATES['AQ Default']},Object.fromEntries(Object.entries(out).filter(([,v])=>v!==undefined)));
  }
  function install(){
    const anchor=document.getElementById('designSystemImportGroup'); if(!anchor||document.getElementById('aqDesignSystemBuilder'))return;
    const box=document.createElement('div'); box.className='group aq-ds-builder'; box.id='aqDesignSystemBuilder';
    box.innerHTML='<div class="aq-ds-builder-head"><div><strong>Create and edit design systems</strong><div class="xsmall muted">Work with semantic choices; AQ creates the JSON.</div></div><div class="aq-ds-builder-actions"><button class="btn primary" id="aqDsNew" type="button">New Design System</button></div></div><div class="aq-ds-builder-layout"><div class="aq-ds-builder-list" id="aqDsList"></div><div class="aq-ds-builder-editor" id="aqDsEditor"><div class="aq-ds-builder-empty">Select a design system or create a new one.</div></div></div>';
    anchor.parentNode.insertBefore(box,anchor); document.getElementById('aqDsNew').onclick=newFlow; renderList();
  }
  function renderList(){
    const el=document.getElementById('aqDsList'); if(!el||!registry())return;
    const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';
    el.innerHTML=registry().list().map(s=>'<button type="button" data-id="'+esc(s.id)+'" class="'+(s.id===selectedId?'is-selected ':'')+(s.id===active?'is-active':'')+'"><strong>'+esc(s.name)+'</strong><div class="xsmall muted">'+(s.builtIn?'Built in':'Editable')+'</div></button>').join('');
    el.querySelectorAll('button').forEach(b=>b.onclick=()=>selectSystem(b.dataset.id));
  }
  function selectSystem(id){const s=registry().get(id);if(!s)return;selectedId=id;draft={id:s.id,name:s.name,version:s.version||'1.0.0',description:(s.metadata&&s.metadata.description)||'',builtIn:s.builtIn,tokens:semanticTokens(s),baseTokens:((s.metadata&&s.metadata.baseTokens)||semanticTokens(s))};renderList();renderEditor()}
  function newFlow(){
    const choices=Object.keys(TEMPLATES).concat(registry().list().filter(s=>!s.builtIn).map(s=>s.name));
    const previous=document.getElementById('aqDsNewDialog');
    if(previous)previous.remove();
    const dialog=document.createElement('dialog');
    dialog.id='aqDsNewDialog';
    dialog.className='aq-ds-new-dialog';
    dialog.innerHTML='<form method="dialog" class="aq-ds-new-dialog-card"><div class="aq-ds-new-dialog-head"><div><strong>New Design System</strong><div class="xsmall muted">Choose a starting point, then name your system.</div></div><button class="btn" value="cancel" type="submit" aria-label="Close">Close</button></div><label class="aq-ds-builder-field"><span>Start from</span><select id="aqDsBaseChoice">'+choices.map(x=>'<option value="'+esc(x)+'">'+esc(x)+'</option>').join('')+'</select></label><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsNewName" type="text" value="My Design System" autocomplete="off"></label><div class="aq-ds-new-dialog-actions"><button class="btn" value="cancel" type="submit">Cancel</button><button class="btn primary" id="aqDsCreateNew" value="default" type="button">Create</button></div></form>';
    document.body.appendChild(dialog);
    const select=dialog.querySelector('#aqDsBaseChoice');
    const nameInput=dialog.querySelector('#aqDsNewName');
    const create=dialog.querySelector('#aqDsCreateNew');
    const syncCreateState=()=>{create.disabled=!nameInput.value.trim();};
    nameInput.addEventListener('input',syncCreateState);
    create.addEventListener('click',()=>{
      const choice=select.value;
      let tokens=TEMPLATES[choice];
      if(!tokens){const existing=registry().list().find(s=>s.name.toLowerCase()===String(choice).toLowerCase());tokens=semanticTokens(existing)}
      tokens={...(tokens||TEMPLATES['AQ Default'])};
      const name=nameInput.value.trim();
      if(!name){nameInput.focus();return}
      selectedId='';draft={id:uniqueId(name),name,version:'1.0.0',description:'',builtIn:false,isNew:true,tokens,baseTokens:{...tokens}};
      dialog.close();dialog.remove();renderList();renderEditor();
    });
    dialog.addEventListener('close',()=>dialog.remove(),{once:true});
    syncCreateState();
    dialog.showModal();
    setTimeout(()=>nameInput.select(),0);
  }
  function field(label,key,type='text'){
    const value=draft.tokens[key];
    if(type==='color')return '<label class="aq-ds-builder-field"><span>'+label+'</span><div class="aq-ds-color-row"><input data-token="'+key+'" type="text" value="'+esc(value)+'"><input data-color="'+key+'" type="color" value="'+esc(/^#[0-9a-f]{6}$/i.test(value)?value:'#000000')+'"></div></label>';
    return '<label class="aq-ds-builder-field"><span>'+label+'</span><input data-token="'+key+'" type="text" value="'+esc(value)+'"></label>';
  }
  function renderEditor(){
    const el=document.getElementById('aqDsEditor');if(!el||!draft)return;
    const editable=!draft.builtIn;
    el.innerHTML='<div class="aq-ds-builder-grid"><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsName" type="text" value="'+esc(draft.name)+'" '+(!editable?'disabled':'')+'></label><label class="aq-ds-builder-field"><span>Version</span><input id="aqDsVersion" type="text" value="'+esc(draft.version)+'" '+(!editable?'disabled':'')+'></label></div><label class="aq-ds-builder-field" style="margin-top:10px"><span>Description</span><textarea id="aqDsDescription" rows="2" '+(!editable?'disabled':'')+'>'+esc(draft.description)+'</textarea></label><h4>Colors</h4><div class="aq-ds-builder-grid">'+field('Surface','surface.default','color')+field('Accent / action','surface.accent','color')+field('Primary text','text.primary','color')+field('Muted text','text.muted','color')+'</div><h4>Corners and spacing</h4><div class="aq-ds-builder-grid">'+field('Corner radius','radius.default')+field('Small spacing','spacing.sm')+field('Medium spacing','spacing.md')+field('Large spacing','spacing.lg')+'</div><div class="aq-ds-builder-preview" id="aqDsPreview"><div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">Live Preview</div><h3 style="margin:8px 0">Professional Plan</h3><p class="muted">A governed component using this design system.</p><div style="font-size:28px;font-weight:700;margin:12px 0">$49 <span class="muted" style="font-size:14px">per month</span></div><button type="button">Subscribe</button></div><div class="aq-ds-builder-footer">'+(editable?'<button class="btn primary" id="aqDsSave" type="button">Save</button><button class="btn" id="aqDsReset" type="button">Reset to Base</button><button class="btn" id="aqDsDuplicate" type="button">Duplicate</button><button class="btn" id="aqDsExport" type="button">Export JSON</button>'+(draft.isNew?'':'<button class="btn" id="aqDsDelete" type="button">Delete</button>'):'<button class="btn" id="aqDsDuplicate" type="button">Duplicate</button>')+'</div>';
    el.querySelectorAll('[data-token]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.token]=i.value;const c=el.querySelector('[data-color="'+i.dataset.token+'"]');if(c&&/^#[0-9a-f]{6}$/i.test(i.value))c.value=i.value;preview()}});
    el.querySelectorAll('[data-color]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.color]=i.value;el.querySelector('[data-token="'+i.dataset.color+'"]').value=i.value;preview()}});
    if(editable){document.getElementById('aqDsSave').onclick=save;document.getElementById('aqDsReset').onclick=()=>{draft.tokens={...draft.baseTokens};renderEditor()};document.getElementById('aqDsExport').onclick=exportJson;if(!draft.isNew)document.getElementById('aqDsDelete').onclick=remove}
    document.getElementById('aqDsDuplicate').onclick=duplicate;preview();
  }
  function preview(){const p=document.getElementById('aqDsPreview');if(!p)return;p.style.setProperty('--aq-preview-surface',draft.tokens['surface.default']);p.style.setProperty('--aq-preview-accent',draft.tokens['surface.accent']);p.style.setProperty('--aq-preview-primary',draft.tokens['text.primary']);p.style.setProperty('--aq-preview-muted',draft.tokens['text.muted']);p.style.setProperty('--aq-preview-radius',draft.tokens['radius.default']);p.style.padding=draft.tokens['spacing.md']}
  function payload(){return{id:draft.id,name:document.getElementById('aqDsName').value.trim(),version:document.getElementById('aqDsVersion').value.trim()||'1.0.0',tokens:{...draft.tokens},metadata:{description:document.getElementById('aqDsDescription').value.trim(),baseTokens:{...draft.baseTokens}}}}
  function save(){try{const data=payload();let rec;if(draft.isNew)rec=registry().importFromObject(data,{fallbackName:data.name+'.json'});else rec=registry().replaceImported(draft.id,data,{useImportedName:true});selectedId=rec.id;draft.isNew=false;selectSystem(rec.id);if(window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId&&window.AQActiveDesignSystem.getActiveId()===rec.id)window.AQActiveDesignSystem.setActiveSystem(rec.id,{source:'design-system-editor-save'});if(typeof window.renderImportedDesignSystemRegistry==='function')window.renderImportedDesignSystemRegistry();alert('Design system saved.')}catch(e){alert('Could not save: '+e.message)}}
  function duplicate(){const name=window.prompt('Name the duplicate:',draft.name+' Copy');if(!name)return;const tokens={...draft.tokens};draft={id:uniqueId(name),name,version:draft.version,description:draft.description,builtIn:false,isNew:true,tokens,baseTokens:{...tokens}};selectedId='';renderList();renderEditor()}
  function exportJson(){const data=payload();const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=slug(data.name)+'-'+data.version+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
  function remove(){if(!confirm('Delete '+draft.name+'?'))return;const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'';if(active===draft.id){alert('Activate another system before deleting this one.');return}registry().remove(draft.id);selectedId='';draft=null;renderList();document.getElementById('aqDsEditor').innerHTML='<div class="aq-ds-builder-empty">Select a design system or create a new one.</div>'}
  document.addEventListener('DOMContentLoaded',()=>{install();const btn=document.getElementById('designSystemBtn');if(btn)btn.addEventListener('click',()=>setTimeout(()=>{install();renderList()},0));});
})();
