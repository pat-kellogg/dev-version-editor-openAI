(function(){
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];});}
  var CONTRACT={
    id:'example-callout-card',
    name:'Example Callout Card',
    runtime:'web-component',
    tag:'example-callout-card',
    type:'imported-contract',
    props:{headline:'Contract-backed callout',body:'This is rendered in the canvas by the live <example-callout-card> Web Component runtime.',tone:'info',variant:'soft',ctaLabel:'Learn more',badgeSlot:'Contract slot',mediaSlot:'',actionsSlot:'Secondary action'},
    slots:['badge','media','actions'],
    propOptions:{tone:['info','success','warning'],variant:['soft','solid','outline']},
    tokenBindings:{
      surface:'semantic.surface.callout',
      border:'semantic.border.callout',
      heading:'semantic.text.heading',
      body:'semantic.text.body',
      radius:'radius.lg',
      spacing:'space.4'
    },
    tokenValues:{
      'semantic.surface.callout':'#eef2ff',
      'semantic.border.callout':'#4f46e5',
      'semantic.text.heading':'#1f2937',
      'semantic.text.body':'#64748b',
      'radius.lg':'18px',
      'space.4':'18px'
    },
    variants:['info','success','warning']
  };

  function defineExampleCalloutCard(){
    if(window.customElements && !customElements.get('example-callout-card')){
      customElements.define('example-callout-card', class extends HTMLElement{
        static get observedAttributes(){ return ['headline','body','tone','variant','cta-label','badge-slot','media-slot','actions-slot']; }
        constructor(){ super(); this.attachShadow({mode:'open'}); }
        connectedCallback(){ this.render(); }
        attributeChangedCallback(){ this.render(); }
        render(){
          var headline=this.getAttribute('headline')||'';
          var body=this.getAttribute('body')||'';
          var tone=this.getAttribute('tone')||'info';
          var variant=this.getAttribute('variant')||'soft';
          var cta=this.getAttribute('cta-label')||'';
          var badge=this.getAttribute('badge-slot')||'';
          var media=this.getAttribute('media-slot')||'';
          var actions=this.getAttribute('actions-slot')||'';
          var surface='var(--contract-surface, #eef2ff)';
          var border='var(--contract-border, #4f46e5)';
          var heading='var(--contract-heading, #1f2937)';
          var bodyColor='var(--contract-body, #64748b)';
          var radius='var(--contract-radius, 18px)';
          var spacing='var(--contract-spacing, 18px)';
          function h(v){return String(v==null?'':v).replace(/[&<>"']/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];});}
          this.shadowRoot.innerHTML='<style>:host{display:block;width:100%;box-sizing:border-box}.card{box-sizing:border-box;width:100%;border:1px solid '+border+';border-radius:'+radius+';background:'+surface+';padding:'+spacing+';box-shadow:0 6px 18px rgba(15,23,42,.08);font-family:Inter,system-ui,Arial,sans-serif}.media{margin:0 0 12px}.media img{width:100%;max-height:180px;object-fit:cover;border-radius:calc('+radius+' - 6px);display:block}.kicker{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:950;letter-spacing:.04em;text-transform:uppercase;color:#4f46e5;margin-bottom:6px}.slot-badge{display:inline-flex;padding:2px 7px;border-radius:999px;background:#fff;border:1px solid #dbe4ee;color:#4f46e5;font-size:10px;font-weight:950}.title{font-size:22px;font-weight:900;margin-bottom:6px;color:'+heading+'}.body{line-height:1.45;margin-bottom:12px;color:'+bodyColor+'}.meta{display:flex;gap:8px;flex-wrap:wrap}.chip{display:inline-flex;padding:3px 7px;border-radius:999px;border:1px solid #dbe4ee;background:#fff;color:#64748b;font-size:11px;font-weight:800}.actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px}.cta{display:inline-flex;margin-top:4px;font-weight:900;color:#4f46e5}</style><article class="card" data-tone="'+h(tone)+'" data-variant="'+h(variant)+'">'+(media?'<div class="media"><img alt="" src="'+h(media)+'"></div>':'')+'<div class="kicker">Runtime Web Component '+(badge?'<span class="slot-badge">'+h(badge)+'</span>':'')+'<slot name="badge"></slot></div><slot name="media"></slot><div class="title">'+h(headline)+'</div><div class="body">'+h(body)+'</div><div class="meta"><span class="chip">tag: example-callout-card</span><span class="chip">tone: '+h(tone)+'</span><span class="chip">variant: '+h(variant)+'</span></div><div class="actions">'+(cta?'<span class="cta">'+h(cta)+'</span>':'')+(actions?'<span class="cta">'+h(actions)+'</span>':'')+'<slot name="actions"></slot></div></article>';
        }
      });
    }
  }
  defineExampleCalloutCard();
  var IMPORTED_INSTANCES=[];
  var instanceCounter=0;
  function cloneContract(){ return JSON.parse(JSON.stringify(CONTRACT)); }
  function clone(v){ return JSON.parse(JSON.stringify(v)); }
  function nextInstanceId(){ instanceCounter+=1; return 'imported-contract-'+Date.now().toString(36)+'-'+instanceCounter; }
  function getContract(node){
    try { return JSON.parse(node.getAttribute('data-contract-json') || ''); }
    catch(e){ return cloneContract(); }
  }
  function setContract(node, contract){ node.setAttribute('data-contract-json', JSON.stringify(contract)); }
  function setStatus(msg){var el=document.getElementById('importedContractPocStatus'); if(el) el.textContent=msg;}
  function renderNode(node){
    var contract=getContract(node); var props=contract.props||{};
    node.setAttribute('data-tone', props.tone || 'info');
    node.setAttribute('data-variant', props.variant || 'soft');
    node.innerHTML='<example-callout-card class="imported-contract-runtime" '+
      'headline="'+esc(props.headline)+'" '+
      'body="'+esc(props.body)+'" '+
      'tone="'+esc(props.tone||'info')+'" '+
      'variant="'+esc(props.variant||'soft')+'" '+
      'cta-label="'+esc(props.ctaLabel||'')+'" '+
      'badge-slot="'+esc(props.badgeSlot||'')+'" '+
      'media-slot="'+esc(props.mediaSlot||'')+'" '+
      'actions-slot="'+esc(props.actionsSlot||'')+'">'+slotLightDom(contract)+'</example-callout-card>'+
      '<div class="imported-contract-poc-meta" style="margin-top:8px;">'+
      '<span class="imported-contract-poc-chip">type: imported-contract</span>'+
      '<span class="imported-contract-poc-chip">runtime: web-component</span>'+
      '<span class="imported-contract-poc-chip">tag: '+esc(contract.tag)+'</span>'+
      '</div>';
    applyTokenStyles(node);
  }

  function slotLightDom(contract){
    var p=(contract&&contract.props)||{};
    var out='';
    if(p.badgeSlot) out+='<span slot="badge" class="contract-slot-badge">'+esc(p.badgeSlot)+'</span>';
    if(p.mediaSlot) out+='<img slot="media" class="contract-slot-media" alt="" src="'+esc(p.mediaSlot)+'">';
    if(p.actionsSlot) out+='<button slot="actions" class="contract-slot-action" type="button">'+esc(p.actionsSlot)+'</button>';
    return out;
  }

  function propControl(name, value, contract){
    var safeName=esc(name), safeValue=esc(value);
    var options=(contract.propOptions && contract.propOptions[name]) || (name==='tone' ? contract.variants : null);
    if(Array.isArray(options) && options.length){
      var opts=options.map(function(opt){
        return '<option value="'+esc(opt)+'"'+(String(opt)===String(value)?' selected':'')+'>'+esc(opt)+'</option>';
      }).join('');
      return '<label class="contract-control-label">'+safeName+' <span class="contract-generated-note">from contract</span></label><select class="contract-control-input" data-contract-prop="'+safeName+'">'+opts+'</select>';
    }
    if(name==='body'){
      return '<label class="contract-control-label">'+safeName+'</label><textarea class="contract-control-input" data-contract-prop="'+safeName+'">'+safeValue+'</textarea>';
    }
    return '<label class="contract-control-label">'+safeName+'</label><input class="contract-control-input" data-contract-prop="'+safeName+'" value="'+safeValue+'">';
  }
  function renderTokenBindings(contract){
    var bindings=contract.tokenBindings||{};
    var values=contract.tokenValues||{};
    var keys=Object.keys(bindings);
    if(!keys.length) return '<div class="hint">No token bindings defined for this contract.</div>';
    return keys.map(function(role){
      var token=bindings[role];
      var value=values[token] || '';
      var chip='';
      if(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(value)){
        chip='<span class="contract-token-swatch" style="background:'+esc(value)+'"></span>';
      }
      return '<div class="contract-token-row">'+
        '<strong>'+esc(role)+'</strong>'+
        '<span><code>'+esc(token)+'</code><em>'+chip+esc(value)+'</em></span>'+
        '</div>';
    }).join('');
  }
  function runtimeMarkupForContract(contract){
    contract=contract||{};
    var p=contract.props||{};
    var tag=contract.tag||'example-callout-card';
    return '<'+tag+'\n'+
      '  headline="'+esc(p.headline||'')+'"\n'+
      '  body="'+esc(p.body||'')+'"\n'+
      '  tone="'+esc(p.tone||'info')+'"\n'+
      '  variant="'+esc(p.variant||'soft')+'"\n'+
      '  cta-label="'+esc(p.ctaLabel||'')+'"\n'+
      '  badge-slot="'+esc(p.badgeSlot||'')+'"\n'+
      '  media-slot="'+esc(p.mediaSlot||'')+'"\n'+
      '  actions-slot="'+esc(p.actionsSlot||'')+'"\n'+
      '>'+slotLightDom(contract)+'</'+tag+'>';
  }
  function runtimeMarkupBlock(contract){
    var markup=runtimeMarkupForContract(contract);
    return '<textarea class="contract-runtime-snippet" readonly rows="8">'+esc(markup)+'</textarea>'+
      '<button class="btn contract-copy-runtime" type="button" data-copy-runtime-markup="true">Copy runtime markup</button>';
  }

  function effectiveTokenValues(contract){
    contract=contract||{};
    var values=Object.assign({}, contract.tokenValues||{});
    Object.assign(values, contract.tokenOverrides||{});
    return values;
  }
  function isColorValue(value){ return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(String(value||'')); }
  function tokenValueForRole(contract, role){
    var token=(contract.tokenBindings||{})[role];
    if(!token) return '';
    return effectiveTokenValues(contract)[token] || '';
  }
  function applyTokenStyles(node){
    var contract=getContract(node);
    var surface=tokenValueForRole(contract,'surface') || '#eef2ff';
    var border=tokenValueForRole(contract,'border') || '#4f46e5';
    var heading=tokenValueForRole(contract,'heading') || '#1f2937';
    var body=tokenValueForRole(contract,'body') || '#64748b';
    var radius=tokenValueForRole(contract,'radius') || '18px';
    var spacing=tokenValueForRole(contract,'spacing') || '18px';
    node.style.background=surface;
    node.style.borderColor=border;
    node.style.borderRadius=radius;
    node.style.padding=spacing;
    var runtimeEl=node.querySelector('example-callout-card');
    if(runtimeEl){
      runtimeEl.style.setProperty('--contract-surface', surface);
      runtimeEl.style.setProperty('--contract-border', border);
      runtimeEl.style.setProperty('--contract-heading', heading);
      runtimeEl.style.setProperty('--contract-body', body);
      runtimeEl.style.setProperty('--contract-radius', radius);
      runtimeEl.style.setProperty('--contract-spacing', spacing);
      var rp=(contract.props||{});
      runtimeEl.setAttribute('headline', rp.headline||'');
      runtimeEl.setAttribute('body', rp.body||'');
      runtimeEl.setAttribute('tone', rp.tone||'info');
      runtimeEl.setAttribute('variant', rp.variant||'soft');
      runtimeEl.setAttribute('cta-label', rp.ctaLabel||'');
      runtimeEl.setAttribute('badge-slot', rp.badgeSlot||'');
      runtimeEl.setAttribute('media-slot', rp.mediaSlot||'');
      runtimeEl.setAttribute('actions-slot', rp.actionsSlot||'');
    }
    var title=node.querySelector('.imported-contract-poc-title');
    var bodyEl=node.querySelector('.imported-contract-poc-body');
    if(title) title.style.color=heading;
    if(bodyEl) bodyEl.style.color=body;
  }
  function renderTokenOverrides(contract){
    var bindings=contract.tokenBindings||{};
    var values=effectiveTokenValues(contract);
    var roles=['surface','border','heading','body','radius','spacing'];
    return roles.filter(function(role){ return bindings[role]; }).map(function(role){
      var token=bindings[role];
      var value=values[token] || '';
      var type=isColorValue(value) ? 'color' : 'text';
      var swatch=isColorValue(value) ? '<span class="contract-token-swatch" style="background:'+esc(value)+'"></span>' : '';
      return '<div class="contract-control-row contract-token-override-row">'+
        '<label class="contract-control-label">'+esc(role)+' <span class="contract-generated-note">'+esc(token)+'</span></label>'+
        '<div class="contract-token-override-control">'+swatch+'<input class="contract-control-input" type="'+type+'" data-token-override="'+esc(token)+'" value="'+esc(value)+'"></div>'+
      '</div>';
    }).join('') || '<div class="hint">No editable token bindings available.</div>';
  }
  function showPanel(node){
    var panel=document.getElementById('rightPanel'); if(!panel) return;
    var contract=getContract(node); var props=contract.props||{};
    var controls=Object.keys(props).map(function(key){ return '<div class="contract-control-row">'+propControl(key, props[key], contract)+'</div>'; }).join('');
    var tokenRows=renderTokenBindings(contract);
    panel.innerHTML='<div class="group contract-poc-panel">'+
      '<h4>Component Contract: '+esc(contract.name)+'</h4>'+
      '<div class="hint">Editable controls generated from the imported contract props.</div>'+
      '<div class="contract-row"><strong>Contract ID</strong><span>'+esc(contract.id)+'</span></div>'+
      '<div class="contract-row"><strong>Runtime</strong><span>'+esc(contract.runtime)+'</span></div>'+
      '<div class="contract-row"><strong>Target tag</strong><span class="code-chip">'+esc(contract.tag)+'</span></div>'+
      '</div>'+
      '<div class="group contract-poc-runtime-map">'+
      '<h4>Runtime Mapping</h4>'+
      '<div class="hint">Shows how this imported contract maps to runtime markup. This is read-only and does not change export behavior.</div>'+
      '<div class="contract-row"><strong>Runtime</strong><span>'+esc(contract.runtime||"web-component")+'</span></div>'+
      '<div class="contract-row"><strong>Custom element</strong><span class="code-chip">&lt;'+esc(contract.tag||"example-callout-card")+'&gt;</span></div>'+
      '<div class="contract-token-row"><strong>Attributes</strong><span><code>headline</code><code>body</code><code>tone</code><code>variant</code><code>cta-label</code><code>badge-slot</code><code>media-slot</code><code>actions-slot</code></span></div>'+
      '<div class="contract-token-row"><strong>Slots</strong><span><code>badge</code><code>media</code><code>actions</code></span></div>'+
      '<div class="contract-token-row"><strong>Contract source</strong><span><code>'+esc(contract.id||"example-callout-card")+'</code></span></div>'+
      '</div>'+
      '<div class="group contract-poc-runtime-snippet">'+
      '<h4>Runtime Markup</h4>'+
      '<div class="hint">Copyable custom element markup generated from the current imported-contract props.</div>'+runtimeMarkupBlock(contract)+
      '</div>'+
      '<div class="group contract-poc-controls">'+
      '<h4>Contract Props</h4>'+
      '<div class="hint">Dropdown options are generated from the imported contract metadata.</div>'+controls+
      '</div>'+
      '<div class="group contract-poc-tokens">'+
      '<h4>Token Bindings</h4>'+
      '<div class="hint">Read-only roles and token names from the imported component contract.</div>'+tokenRows+
      '</div>'+ 
      '<div class="group contract-poc-token-overrides">'+
      '<h4>Token Overrides</h4>'+ 
      '<div class="hint">Editable token values for this imported contract instance. Color bindings show color pickers; spacing/radius use text values.</div>'+renderTokenOverrides(contract)+
      '</div>';
    panel.querySelectorAll('[data-contract-prop]').forEach(function(input){
      input.addEventListener('input', function(){ updateProp(node, input.getAttribute('data-contract-prop'), input.value); });
      input.addEventListener('change', function(){ updateProp(node, input.getAttribute('data-contract-prop'), input.value); });
    });
    panel.querySelectorAll('[data-token-override]').forEach(function(input){
      input.addEventListener('input', function(){ updateTokenOverride(node, input.getAttribute('data-token-override'), input.value); });
      input.addEventListener('change', function(){ updateTokenOverride(node, input.getAttribute('data-token-override'), input.value); showPanel(node); });
    });
    var copyBtn=panel.querySelector('[data-copy-runtime-markup]');
    if(copyBtn){
      copyBtn.addEventListener('click', function(){
        var text=runtimeMarkupForContract(getContract(node));
        if(navigator.clipboard && navigator.clipboard.writeText){
          navigator.clipboard.writeText(text).then(function(){ copyBtn.textContent='Copied'; setTimeout(function(){copyBtn.textContent='Copy runtime markup';},1200); });
        } else {
          var ta=panel.querySelector('.contract-runtime-snippet');
          if(ta){ ta.focus(); ta.select(); document.execCommand('copy'); copyBtn.textContent='Copied'; setTimeout(function(){copyBtn.textContent='Copy runtime markup';},1200); }
        }
      });
    }
  }
  function updateTokenOverride(node, token, value){
    var contract=getContract(node);
    contract.tokenOverrides=contract.tokenOverrides||{};
    contract.tokenOverrides[token]=value;
    setContract(node, contract);
    syncNodeToInstance(node);
    applyTokenStyles(node);
  }
  function updateProp(node, key, value){
    // Keep the active right-panel field mounted while typing.
    // Rebuilding the whole panel on every keypress forces the input to lose focus,
    // which made text entry behave like one character at a time.
    var contract=getContract(node);
    contract.props=contract.props||{};
    contract.props[key]=value;
    setContract(node, contract);
    syncNodeToInstance(node);
    renderNode(node);
  }
  function selectNode(node){
    document.querySelectorAll('.imported-contract-poc-item.selected').forEach(function(x){x.classList.remove('selected')});
    node.classList.add('selected'); showPanel(node);
  }
  function getInstanceById(id){ return IMPORTED_INSTANCES.find(function(x){return x.id===id;}); }
  function syncNodeToInstance(node){
    var id=node && node.getAttribute('data-imported-instance-id');
    var inst=getInstanceById(id);
    if(inst) inst.contract=getContract(node);
  }
  function createNodeForInstance(inst){
    var node=document.createElement('div');
    node.className='imported-contract-poc-item';
    node.tabIndex=0;
    node.setAttribute('data-item-type','imported-contract');
    node.setAttribute('data-contract-id', inst.contract.id || CONTRACT.id);
    node.setAttribute('data-imported-instance-id', inst.id);
    setContract(node, clone(inst.contract));
    renderNode(node);
    node.addEventListener('click',function(e){e.preventDefault(); e.stopPropagation(); selectNode(node);});
    node.addEventListener('keydown',function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); selectNode(node); }});
    return node;
  }
  function clearImportedSelectionPanelIfNeeded(node){
    try{
      if(!node || !node.classList || !node.classList.contains('selected')) return;
      var panel=document.getElementById('rightPanel');
      if(panel){
        panel.innerHTML='<div class="group"><h4>No component selected</h4><div class="hint">Select a section or component on the canvas to edit its properties.</div></div>';
      }
    }catch(_){ }
  }
  function removeImportedContractNode(node){
    if(!node) return false;
    var id=node.getAttribute('data-imported-instance-id');
    if(id){
      IMPORTED_INSTANCES = IMPORTED_INSTANCES.filter(function(inst){ return inst.id !== id; });
    }
    clearImportedSelectionPanelIfNeeded(node);
    if(node.parentNode) node.parentNode.removeChild(node);
    var canvas=document.getElementById('canvas');
    if(canvas && !canvas.children.length){
      var empty=document.createElement('div');
      empty.className='empty';
      empty.textContent='Add a section or component to begin.';
      canvas.appendChild(empty);
    }
    setStatus('Removed imported contract item.');
    return true;
  }
  function getSelectedImportedContractNode(){
    return document.querySelector('.imported-contract-poc-item.selected');
  }
  function installImportedDeleteHooks(){
    if(window.__importedContractDeleteHooksInstalled) return;
    window.__importedContractDeleteHooksInstalled=true;
    document.addEventListener('click', function(e){
      var t=e.target && e.target.closest && e.target.closest('#quickDeleteBtn,#deleteBtnTop,#deleteBtn');
      if(!t) return;
      var selected=getSelectedImportedContractNode();
      if(!selected) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      removeImportedContractNode(selected);
    }, true);
    document.addEventListener('keydown', function(e){
      if(e.key !== 'Delete' && e.key !== 'Backspace') return;
      var active=document.activeElement;
      if(active && /^(input|textarea|select)$/i.test(active.tagName||'')) return;
      var selected=getSelectedImportedContractNode();
      if(!selected) return;
      e.preventDefault(); e.stopPropagation();
      removeImportedContractNode(selected);
    }, true);
  }
  var rehydrating=false;
  function rehydrateImportedInstances(){
    if(rehydrating) return;
    rehydrating=true;
    try{
      var canvas=document.getElementById('canvas');
      if(!canvas || !IMPORTED_INSTANCES.length) return;
      var empty=canvas.querySelector('.empty');
      if(empty && canvas.children.length===1) empty.remove();
      IMPORTED_INSTANCES.forEach(function(inst){
        var existing=canvas.querySelector('[data-imported-instance-id="'+CSS.escape(inst.id)+'"]');
        if(existing) return;
        var node=createNodeForInstance(inst);
        canvas.insertBefore(node, canvas.firstChild);
      });
    } finally { rehydrating=false; }
  }
  function installPersistenceHooks(){
    ['renderCanvas','render'].forEach(function(name){
      var fn=window[name];
      if(typeof fn==='function' && !fn.__importedContractPersistWrapped){
        var wrapped=function(){ var out=fn.apply(this, arguments); setTimeout(rehydrateImportedInstances,0); return out; };
        wrapped.__importedContractPersistWrapped=true; window[name]=wrapped;
      }
    });
    var canvas=document.getElementById('canvas');
    if(canvas && !canvas.__importedContractObserver){
      canvas.__importedContractObserver=true;
      var pending=false;
      new MutationObserver(function(){
        if(pending) return; pending=true;
        setTimeout(function(){ pending=false; rehydrateImportedInstances(); }, 40);
      }).observe(canvas,{childList:true});
    }
  }
  window.addImportedContractPocDirect=function(){
    var canvas=document.getElementById('canvas'); if(!canvas){ setStatus('Canvas not found.'); return; }
    installPersistenceHooks();
    var contract=cloneContract();
    var inst={id:nextInstanceId(), contract:contract};
    IMPORTED_INSTANCES.push(inst);
    var empty=canvas.querySelector('.empty'); if(empty) empty.remove();
    var node=createNodeForInstance(inst);
    node.classList.add('selected');
    canvas.insertBefore(node, canvas.firstChild);
    selectNode(node); setStatus('Added live runtime Web Component item. It should stay when other components are added.');
  };

  function inlineStyleForContract(c){
    var surface=tokenValueForRole(c,'surface') || '#eef2ff';
    var border=tokenValueForRole(c,'border') || '#4f46e5';
    var radius=tokenValueForRole(c,'radius') || '18px';
    var spacing=tokenValueForRole(c,'spacing') || '18px';
    return 'border:1px solid '+esc(border)+';border-radius:'+esc(radius)+';background:'+esc(surface)+';padding:'+esc(spacing)+';box-shadow:0 6px 18px rgba(15,23,42,.08);font-family:Inter,system-ui,Arial,sans-serif;';
  }
  function importedExportMarkup(){
    if(!IMPORTED_INSTANCES.length) return '';
    return IMPORTED_INSTANCES.map(function(inst){
      var c=inst.contract||cloneContract(); var p=c.props||{};
      var heading=tokenValueForRole(c,'heading') || '#1f2937';
      var bodyColor=tokenValueForRole(c,'body') || '#64748b';
      var slotFallback='';
      if(p.badgeSlot) slotFallback+='<span class="contract-slot-badge" style="display:inline-flex;margin-left:8px;padding:2px 7px;border-radius:999px;background:#fff;border:1px solid #dbe4ee;color:#4f46e5;font-size:10px;font-weight:950;">'+esc(p.badgeSlot)+'</span>';
      var mediaFallback=p.mediaSlot ? '<div class="contract-slot-media-wrap" style="margin:0 0 12px;"><img class="contract-slot-media" alt="" src="'+esc(p.mediaSlot)+'" style="display:block;width:100%;max-height:180px;object-fit:cover;border-radius:12px;"></div>' : '';
      var actionFallback=p.actionsSlot ? '<button class="contract-slot-action" type="button" style="margin-top:8px;border:1px solid #dbe4ee;border-radius:999px;background:#fff;color:#4f46e5;padding:7px 11px;font-weight:900;">'+esc(p.actionsSlot)+'</button>' : '';
      return '<section class="section imported-contract-export-section" style="display:block;width:100%;max-width:none;margin:0 0 24px 0;padding:0;grid-column:1 / -1;" data-component-type="imported-contract" data-contract-id="'+esc(c.id||'')+'" data-contract-name="'+esc(c.name||'')+'">'+
        '<example-callout-card class="imported-contract-runtime-export" style="display:block;width:100%;max-width:none;'+inlineStyleForContract(c)+'" '+
        'headline="'+esc(p.headline||'')+'" body="'+esc(p.body||'')+'" tone="'+esc(p.tone||'info')+'" variant="'+esc(p.variant||'soft')+'" cta-label="'+esc(p.ctaLabel||'')+'" badge-slot="'+esc(p.badgeSlot||'')+'" media-slot="'+esc(p.mediaSlot||'')+'" actions-slot="'+esc(p.actionsSlot||'')+'">'+
          slotLightDom(c)+
          '<article class="imported-contract-runtime-fallback" style="box-sizing:border-box;width:100%;max-width:none;'+inlineStyleForContract(c)+'" data-tone="'+esc(p.tone||'info')+'" data-variant="'+esc(p.variant||'soft')+'">'+
            mediaFallback+
            '<div class="imported-contract-poc-kicker">Runtime Web Component '+slotFallback+'</div>'+ 
            '<div class="imported-contract-poc-title" style="color:'+esc(heading)+'">'+esc(p.headline||'')+'</div>'+ 
            '<div class="imported-contract-poc-body" style="color:'+esc(bodyColor)+'">'+esc(p.body||'')+'</div>'+ 
            '<div class="imported-contract-poc-meta"><span class="imported-contract-poc-chip">tag: '+esc(c.tag||'example-callout-card')+'</span><span class="imported-contract-poc-chip">tone: '+esc(p.tone||'info')+'</span><span class="imported-contract-poc-chip">variant: '+esc(p.variant||'soft')+'</span></div>'+ 
            '<div class="imported-contract-export-actions" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px;">'+
              (p.ctaLabel?'<span class="imported-contract-runtime-cta" style="display:inline-flex;font-weight:900;color:#4f46e5">'+esc(p.ctaLabel)+'</span>':'')+
              actionFallback+
            '</div>'+ 
          '</article>'+ 
        '</example-callout-card>'+ 
        '<script type="application/json" data-component-contract>'+esc(JSON.stringify(c))+'</'+'script>'+ 
        '</section>';
    }).join('\n');
  }
  function injectImportedContractsIntoHtml(html){
    html=String(html||'');
    if(!IMPORTED_INSTANCES.length) return html;
    if(html.indexOf('<!-- Imported component-contract export extension -->') !== -1) return html;
    var exportCss='<style id="imported-contract-export-css">.imported-contract-export-section{display:block;width:100%;max-width:none;margin:0 0 24px 0;padding:0;grid-column:1 / -1}.imported-contract-export-section .imported-contract-poc-item,.imported-contract-runtime-export,.imported-contract-runtime-fallback{box-sizing:border-box;width:100%;max-width:none;display:block}.imported-contract-poc-kicker{font-size:11px;font-weight:950;letter-spacing:.04em;text-transform:uppercase;color:#4f46e5;margin-bottom:6px}.imported-contract-poc-title{font-size:22px;font-weight:900;margin-bottom:6px}.imported-contract-poc-body{line-height:1.45;margin-bottom:12px}.imported-contract-poc-meta{display:flex;gap:8px;flex-wrap:wrap}.imported-contract-poc-chip{display:inline-flex;padding:3px 7px;border-radius:999px;border:1px solid #dbe4ee;background:#fff;color:#64748b;font-size:11px;font-weight:800}.contract-slot-badge{display:inline-flex}.contract-slot-media{display:block}.contract-slot-action{cursor:pointer}</style>';
    var payload='\n<!-- Imported component-contract export extension -->\n'+exportCss+'\n'+importedExportMarkup()+'\n<!-- /Imported component-contract export extension -->\n';
    // Preserve canvas order: imported contract placeholders are prepended to the editor canvas,
    // so export them as the first content inside <main>, before the normal section rows.
    if(/<main\b[^>]*>/i.test(html)) return html.replace(/(<main\b[^>]*>)/i, '$1'+payload);
    if(/<\/body>/i.test(html)) return html.replace(/<\/body>/i, payload+'</body>');
    return html+payload;
  }
  function runOriginalExportWithImportedContracts(originalExport){
    if(!originalExport){ setStatus('Original export function not found.'); return; }
    var NativeBlob = window.Blob;
    var patchedOnce = false;
    window.Blob = function(parts, options){
      try{
        var type = options && options.type ? String(options.type) : '';
        if(!patchedOnce && /text\/html/i.test(type) && parts && parts.length && typeof parts[0] === 'string'){
          patchedOnce = true;
          parts = [injectImportedContractsIntoHtml(parts[0])].concat(Array.prototype.slice.call(parts,1));
        }
      }catch(_){ }
      return new NativeBlob(parts, options);
    };
    try {
      var result = originalExport.apply(window, Array.prototype.slice.call(arguments,1));
      if(window.__lastStandaloneExportHtml){
        window.__lastStandaloneExportHtml = injectImportedContractsIntoHtml(window.__lastStandaloneExportHtml);
      }
      return result;
    }
    finally { setTimeout(function(){ window.Blob = NativeBlob; }, 0); }
  }
  function exportPageWithImportedContracts(){
    var originalExport = window.__importedContractOriginalExportHTML || ((typeof window.exportHTML === 'function') ? window.exportHTML : null);
    return runOriginalExportWithImportedContracts(originalExport);
  }
  function installGlobalImportedExportPatch(){
    var current = (typeof window.exportHTML === 'function') ? window.exportHTML : null;
    if(!current || current.__importedContractExportWrapped) return;
    window.__importedContractOriginalExportHTML = current;
    var wrapped = function importedContractExportHTMLWrapper(){
      return runOriginalExportWithImportedContracts(window.__importedContractOriginalExportHTML, ...arguments);
    };
    wrapped.__importedContractExportWrapped = true;
    window.exportHTML = wrapped;
    try { exportHTML = wrapped; } catch(_) { }
  }
  function installImportedExportCapture(){
    document.addEventListener('click', function(e){
      var t=e.target && e.target.closest && e.target.closest('#exportBtn,#exportCheckDownloadBtn');
      if(!t || !IMPORTED_INSTANCES.length) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      exportPageWithImportedContracts();
    }, true);
  }

  function bind(){
    var btn=document.getElementById('addImportedContractPoc');
    if(!btn || btn.getAttribute('data-direct-bound')==='true') return;
    btn.setAttribute('data-direct-bound','true');
    btn.addEventListener('click',function(e){e.preventDefault(); e.stopPropagation(); window.addImportedContractPocDirect();}, true);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){bind();installPersistenceHooks();installImportedExportCapture();installImportedDeleteHooks();installGlobalImportedExportPatch();}); else {bind();installPersistenceHooks();installImportedExportCapture();installImportedDeleteHooks();installGlobalImportedExportPatch();}
  setTimeout(function(){bind();installPersistenceHooks();installImportedDeleteHooks();installGlobalImportedExportPatch();},500); setTimeout(function(){bind();installPersistenceHooks();installImportedDeleteHooks();installGlobalImportedExportPatch();rehydrateImportedInstances();},1500);
})();
