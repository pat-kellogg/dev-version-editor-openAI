(function(){
  // v2A Shoelace sl-button external library import

  'use strict';
  var STORAGE_KEY='aq.component.registry.contracts.v1d';
  var LAST_CONFIG_KEY='aq.component.registry.lastConfig.v1e';

  var contractPresets={
    'sp-button': {
      label:'Spectrum Button — Primary', library:'Spectrum', markup:'<sp-button variant="primary" size="m">Save</sp-button>',
      props:[{name:'variant',value:'primary'},{name:'size',value:'m'},{name:'treatment',value:'fill'},{name:'disabled',value:false}],
      slots:['default','icon'], events:['click']
    },
    'sp-button-secondary': {
      label:'Spectrum Button — Secondary', library:'Spectrum', tag:'sp-button', markup:'<sp-button variant="secondary" size="m">Cancel</sp-button>',
      props:[{name:'variant',value:'secondary'},{name:'size',value:'m'},{name:'treatment',value:'outline'},{name:'disabled',value:false}],
      slots:['default','icon'], events:['click']
    },
    'sp-button-danger': {
      label:'Spectrum Button — Negative', library:'Spectrum', tag:'sp-button', markup:'<sp-button variant="negative" size="m">Delete</sp-button>',
      props:[{name:'variant',value:'negative'},{name:'size',value:'m'},{name:'treatment',value:'fill'},{name:'disabled',value:false}],
      slots:['default','icon'], events:['click']
    },
    'sp-textfield': {
      label:'Spectrum Text Field — Email', library:'Spectrum', markup:'<sp-textfield label="Email" placeholder="name@example.com"></sp-textfield>',
      props:[{name:'label',value:'Email'},{name:'placeholder',value:'name@example.com'},{name:'value',value:''},{name:'required',value:false},{name:'disabled',value:false}],
      slots:['default'], events:['input','change']
    },
    'sp-textfield-required': {
      label:'Spectrum Text Field — Required', library:'Spectrum', tag:'sp-textfield', markup:'<sp-textfield label="Full name" placeholder="Enter full name" required></sp-textfield>',
      props:[{name:'label',value:'Full name'},{name:'placeholder',value:'Enter full name'},{name:'value',value:''},{name:'required',value:true},{name:'disabled',value:false}],
      slots:['default'], events:['input','change']
    },
    'sl-button': {
      label:'Shoelace Button — Primary', library:'Shoelace', tag:'sl-button', markup:'<sl-button variant="primary" size="medium">Save</sl-button>',
      props:[{name:'variant',value:'primary'},{name:'size',value:'medium'},{name:'disabled',value:false},{name:'pill',value:false},{name:'caret',value:false}],
      slots:['default','prefix','suffix'], events:['click','sl-focus','sl-blur']
    }
  };
  function clonePreset(tag){
    var key=String(tag||'').trim();
    var p=contractPresets[key];
    if(!p) return null;
    var copy=JSON.parse(JSON.stringify(p));
    copy.tag = copy.tag || key;
    return copy;
  }
  function presetOptions(selected){
    var keys=Object.keys(contractPresets);
    return '<option value="">Choose a preset...</option>'+keys.map(function(k){ return '<option value="'+esc(k)+'" '+(k===selected?'selected':'')+'>'+esc(contractPresets[k].label+' ('+k+')')+'</option>'; }).join('');
  }
  function propLinesFromPreset(p){ return (p.props||[]).map(function(x){ return (x.name||'')+(x.value!==undefined && x.value!=='' ? '=' + x.value : ''); }).join('\n'); }


  function ensureShoelaceRuntime(){
    if(document.getElementById('aq-shoelace-light-theme')) return;
    var link=document.createElement('link');
    link.id='aq-shoelace-light-theme';
    link.rel='stylesheet';
    link.href='https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.20.1/cdn/themes/light.css';
    document.head.appendChild(link);
    var script=document.createElement('script');
    script.id='aq-shoelace-autoloader';
    script.type='module';
    script.src='https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.20.1/cdn/shoelace-autoloader.js';
    document.head.appendChild(script);
  }

  var builtIns=[
    { tag:'sl-button', label:'Shoelace Button', markup:'<sl-button variant="primary" size="medium">Save</sl-button>', icon:'◨', library:'Shoelace', props:[{name:'variant',value:'primary'},{name:'size',value:'medium'},{name:'disabled',value:false},{name:'pill',value:false},{name:'caret',value:false}], slots:['default','prefix','suffix'], events:['click','sl-focus','sl-blur'] },
    { tag:'sp-button', label:'Spectrum Button', markup:'<sp-button variant="primary">Save</sp-button>', icon:'◧', proxy:'leftSpectrumButtonPlugin', library:'Spectrum' },
    { tag:'sp-textfield', label:'Spectrum Text Field', markup:'<sp-textfield label="Email"></sp-textfield>', icon:'⌨', proxy:'leftSpectrumTextFieldPlugin', library:'Spectrum' },
    { tag:'sp-checkbox', label:'Spectrum Checkbox', markup:'<sp-checkbox>Subscribe</sp-checkbox>', icon:'☑', proxy:'leftSpectrumCheckboxPlugin', library:'Spectrum' },
    { tag:'sp-switch', label:'Spectrum Switch', markup:'<sp-switch>Enable notifications</sp-switch>', icon:'⏽', proxy:'leftSpectrumSwitchPlugin', library:'Spectrum' },
    { tag:'sp-slider', label:'Spectrum Slider', markup:'<sp-slider label="Amount" value="50"></sp-slider>', icon:'↔', proxy:'leftSpectrumSliderPlugin', library:'Spectrum' },
    { tag:'sp-progress-circle', label:'Spectrum Progress Circle', markup:'<sp-progress-circle indeterminate></sp-progress-circle>', icon:'◌', proxy:'leftSpectrumProgressCirclePlugin', library:'Spectrum' },
    { tag:'sp-accordion', label:'Spectrum Accordion', markup:'<sp-accordion></sp-accordion>', icon:'▾', proxy:'leftSpectrumAccordionPlugin', library:'Spectrum' },
    { tag:'sp-tabs', label:'Spectrum Tabs', markup:'<sp-tabs></sp-tabs>', icon:'▥', proxy:'leftSpectrumTabsPlugin', library:'Spectrum' },
    { tag:'sp-dialog', label:'Spectrum Dialog', markup:'<sp-dialog><h2 slot="heading">Dialog</h2>Dialog content</sp-dialog>', icon:'▣', proxy:'leftSpectrumDialogPlugin', library:'Spectrum' },
    { tag:'sp-toast', label:'Spectrum Toast / Notification', markup:'<sp-toast open>Saved successfully</sp-toast>', icon:'◉', proxy:'leftSpectrumToastPlugin', library:'Spectrum' },
    { tag:'sp-picker', label:'Spectrum Picker / Dropdown', markup:'<sp-picker label="Options"></sp-picker>', icon:'⌄', proxy:'leftSpectrumPickerPlugin', library:'Spectrum' },
    { tag:'aq-contact-section-pattern', label:'Spectrum Contact Section Pattern', markup:'<section data-pattern="contact"></section>', icon:'✉', proxy:'leftSpectrumContactSectionPlugin', library:'Spectrum' },
  ];
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }
  function $(id){ return document.getElementById(id); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function status(msg){ var el=$('aqRegistryStatus'); if(el) el.textContent=msg; }
  function extractAttrs(markup){
    var attrs=[]; var open=String(markup||'').match(/<\s*[a-z][a-z0-9-]*\b([^>]*)>/i); if(!open) return attrs;
    var re=/\s([:@a-zA-Z_][\w:.-]*)(?:\s*=\s*("[^"]*"|'[^']*'|[^\s>]+))?/g, m;
    while((m=re.exec(open[1]))){ if(!m[1].startsWith('/')) attrs.push({name:m[1], value:m[2]?m[2].replace(/^['"]|['"]$/g,''):true}); }
    return attrs;
  }
  function extractTag(input){
    input=(input||'').trim(); if(!input) return '';
    try { var obj=JSON.parse(input); if(obj && obj.tag) return String(obj.tag).trim(); } catch(e){}
    var m=input.match(/<\s*([a-z][a-z0-9-]*)\b/i); return m ? m[1] : '';
  }
  function attrsFromObservedAttributes(raw){
    raw=String(raw||'');
    var out=[];
    var m=raw.match(/observedAttributes\s*\(\)\s*\{[\s\S]*?return\s*\[([\s\S]*?)\]/i) || raw.match(/observedAttributes\s*=\s*\[([\s\S]*?)\]/i);
    if(!m) return out;
    var re=/['\"]([^'\"]+)['\"]/g, x;
    while((x=re.exec(m[1]))){ out.push({name:x[1], value:''}); }
    return out;
  }
  function tagFromCustomElements(raw){
    var m=String(raw||'').match(/customElements\.define\s*\(\s*['\"]([a-z][a-z0-9-]*)['\"]/i);
    return m ? m[1] : '';
  }
  function storybookProps(raw){
    raw=String(raw||'');
    var out=[];
    var block=raw.match(/argTypes\s*[:=]\s*\{([\s\S]*?)\n\s*\}/i);
    var src=block ? block[1] : raw;
    var re=/([A-Za-z_$][\w$-]*)\s*:\s*\{/g, m;
    while((m=re.exec(src))){ if(['control','options','table'].indexOf(m[1])===-1) out.push({name:m[1], value:''}); }
    return out;
  }
  function toContract(input, importType){
    var raw=String(input||'').trim(); var json=null;
    try { json=JSON.parse(raw); } catch(e){}
    if(json && json.tag){
      var preset=clonePreset(json.tag) || {};
      return {
        id: json.id || ('aq-contract-'+Date.now()),
        tag: String(json.tag),
        label: json.label || json.name || preset.label || labelForTag(json.tag),
        source: json.source || json.importType || importType || 'json-contract',
        library: json.library || json.sourceLibrary || preset.library || detectLibrary(json.tag),
        markup: json.markup || json.html || preset.markup || ('<'+json.tag+'></'+json.tag+'>'),
        props: json.props || json.attributes || preset.props || [],
        slots: json.slots || preset.slots || [],
        events: json.events || preset.events || []
      };
    }
    var tag=extractTag(raw) || tagFromCustomElements(raw);
    var preset=clonePreset(tag) || {};
    var detectedProps=extractAttrs(raw).map(function(a){ return {name:a.name, value:a.value}; });
    if(!detectedProps.length) detectedProps = attrsFromObservedAttributes(raw);
    if(!detectedProps.length && importType === 'storybook') detectedProps = storybookProps(raw);
    return {
      id:'aq-contract-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),
      tag:tag,
      label:preset.label || labelForTag(tag),
      source: importType || 'web-component',
      library:preset.library || detectLibrary(tag),
      markup:raw || preset.markup || '',
      props:detectedProps.length ? detectedProps : (preset.props || []),
      slots:preset.slots || (raw.indexOf('</')>-1 ? ['default'] : []),
      events:preset.events || []
    };
  }
  function detectLibrary(tag){ tag=String(tag||''); return /^sp-/.test(tag) ? 'Spectrum' : (/^sl-/.test(tag) ? 'Shoelace' : 'Custom'); }
  function labelForTag(tag){ return tag ? String(tag).replace(/^sp-/,'Spectrum ').replace(/^sl-/,'Shoelace ').replace(/-/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();}) : 'Imported Component'; }
  function load(){ try { return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]') || []; } catch(e){ return []; } }
  function save(list){ try { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); } catch(e){} }
  function allContracts(){ return builtIns.concat(load()); }
  function contractExportShape(contract){
    var props = normalizeProps(contract).map(function(p){ return { name:p.name, defaultValue:p.value }; });
    return {
      id: contract.id || ('registry-'+(contract.tag||'component')),
      name: contract.label || labelForTag(contract.tag),
      tag: contract.tag || '',
      runtime: 'web-component',
      source: contract.source || contract.importType || (contract.library === 'Spectrum' ? 'spectrum' : 'web-component'),
      sourceLibrary: contract.library || detectLibrary(contract.tag),
      importMode: contract.proxy ? 'linked-existing-palette-action' : 'direct-markup-contract',
      defaultMarkup: contract.markup || '',
      props: props,
      slots: contract.slots || [],
      events: contract.events || [],
      handoffNote: 'Imported through AQ Component Registry. Developers should load the source library/module before using this tag in production.'
    };
  }
  function registryExportPayload(){
    var contracts = allContracts().map(contractExportShape);
    return {
      exportType: 'aq-component-registry-contracts',
      version: '1.0.0',
      generatedAt: new Date().toISOString(),
      summary: { totalContracts: contracts.length, libraries: contracts.reduce(function(acc,c){ acc[c.sourceLibrary||'Custom']=(acc[c.sourceLibrary||'Custom']||0)+1; return acc; }, {}) },
      contracts: contracts
    };
  }
  function downloadText(filename, content, type){
    var blob=new Blob([content], {type:type||'text/plain'}); var url=URL.createObjectURL(blob); var a=document.createElement('a');
    a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){URL.revokeObjectURL(url);},500);
  }
  function downloadRegistryJson(){
    var payload=registryExportPayload();
    downloadText('aq-component-registry-contracts.json', JSON.stringify(payload,null,2), 'application/json');
    status('Downloaded registry contracts JSON for developer handoff.');
  }
  function importRegistryPayload(payload){
    var incoming = payload && payload.contracts ? payload.contracts : (Array.isArray(payload) ? payload : []);
    if(!incoming.length) return 0;
    var existing=load();
    var builtTags={}; builtIns.forEach(function(b){ builtTags[b.tag]=true; });
    var added=0;
    incoming.forEach(function(c){
      if(!c || !c.tag || builtTags[c.tag]) return;
      var normalized={
        id:'aq-contract-imported-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),
        tag:c.tag,
        label:c.name || c.label || labelForTag(c.tag),
        source:c.source || c.importType || c.runtime || 'json-contract',
        library:c.sourceLibrary || c.library || detectLibrary(c.tag),
        markup:c.defaultMarkup || c.markup || ('<'+c.tag+'></'+c.tag+'>'),
        props:(c.props||c.attributes||[]).map(function(p){ return typeof p==='string'?{name:p,value:''}:{name:p.name||'', value:p.defaultValue!==undefined?p.defaultValue:(p.value!==undefined?p.value:'')}; }).filter(function(p){return p.name;}),
        slots:c.slots || [],
        events:c.events || []
      };
      existing.push(normalized); added++;
    });
    save(existing); render(); return added;
  }
  function openImportRegistryJson(){
    var input=document.createElement('input'); input.type='file'; input.accept='.json,application/json';
    input.addEventListener('change', function(){
      var file=input.files && input.files[0]; if(!file) return;
      var reader=new FileReader();
      reader.onload=function(){
        try { var count=importRegistryPayload(JSON.parse(reader.result)); status(count ? ('Imported '+count+' saved registry contract(s).') : 'No new custom contracts found in that registry JSON.'); }
        catch(e){ status('Could not read registry JSON.'); }
      };
      reader.readAsText(file);
    });
    input.click();
  }
  function clearSavedContracts(){
    var arr=load();
    if(!arr.length){ status('No saved custom registry contracts to clear.'); return; }
    if(!confirm('Clear saved custom registry contracts? Built-in Spectrum shortcuts will remain.')) return;
    save([]); render(); status('Cleared saved custom registry contracts. Built-ins remain.');
  }
  function contractMarkdown(contract){
    var c=contractExportShape(contract);
    var props=(c.props||[]).map(function(p){ return '- '+p.name+(p.defaultValue!==''&&p.defaultValue!==undefined?' = '+p.defaultValue:''); }).join('\n') || '- none detected';
    var slots=(c.slots||[]).join(', ') || 'none detected';
    return '# '+c.name+'\n\nTag: `'+c.tag+'`\n\nSource library: '+c.sourceLibrary+'\n\nImport mode: '+c.importMode+'\n\n## Default markup\n\n```html\n'+c.defaultMarkup+'\n```\n\n## Props / attributes\n'+props+'\n\n## Slots\n'+slots+'\n\n## Handoff note\n'+c.handoffNote+'\n';
  }
  function downloadContractMarkdown(contract){
    var safe=(contract.tag||contract.label||'registry-component').replace(/[^a-z0-9-]+/gi,'-').toLowerCase();
    downloadText(safe+'-contract.md', contractMarkdown(contract), 'text/markdown');
    status('Downloaded contract notes: '+(contract.tag||contract.label));
  }
  function addToCanvas(contract){
    if(contract && /^sl-/.test(String(contract.tag||''))) ensureShoelaceRuntime();
    if(contract.proxy){
      var target=$(contract.proxy);
      if(target){
        target.click();
        // Existing AQ Spectrum buttons add real editor items, but they do not
        // naturally know they came through Component Registry. Attach registry
        // metadata to the item that the editor just selected.
        setTimeout(function(){
          try {
            var item = (typeof window.getAQSelectedItem === 'function') ? window.getAQSelectedItem() : null;
            if(item){
              item.importSource = {
                kind:'component-registry-built-in',
                id:contract.id||contract.tag,
                tag:contract.tag,
                label:contract.label,
                title:contract.label,
                library:contract.library,
                registry:contractExportShape(contract)
              };
              item.__componentRegistryContract = contractExportShape(contract);
            }
          } catch(e){}
        }, 0);
        status('Added from registry: '+contract.label+'. Select it to edit in the right Properties panel.'); setTimeout(updateRegistryCanvasSummaryView, 0); setTimeout(aqUpdateRightRegistryPanel, 0);
        return;
      }
    }
    if(typeof window.addImportedHTMLSnippet === 'function'){
      window.addImportedHTMLSnippet(contract.markup, null, null, 'add registry component: '+contract.label, contract.label, {kind:'component-registry', id:contract.id||contract.tag, tag:contract.tag, label:contract.label, title:contract.label, library:contract.library, registry:contractExportShape(contract)});
      status('Added registry component to canvas: '+contract.tag+'. Select it to edit in the right Properties panel.'); setTimeout(updateRegistryCanvasSummaryView, 0); setTimeout(aqUpdateRightRegistryPanel, 0);
      return;
    }
    if(typeof window.addImportedHTML === 'function'){
      window.addImportedHTML(); status('Opened imported HTML placement.'); return;
    }
    var canvas=$('canvas');
    if(canvas){ var wrap=document.createElement('div'); wrap.className='aq-imported-canvas-item'; wrap.setAttribute('data-aq-imported-contract','true'); wrap.setAttribute('data-tag', contract.tag||'custom-element'); wrap.innerHTML=contract.markup; canvas.appendChild(wrap); status('Added visual fallback: '+(contract.tag||'custom')); }
  }

  function normalizeProps(contract){
    contract = contract || {};
    var seen={};
    var raw=[];
    if(Array.isArray(contract.props)) raw = raw.concat(contract.props);
    if(Array.isArray(contract.attributes)) raw = raw.concat(contract.attributes);
    if(contract.attrs && typeof contract.attrs === 'object'){
      Object.keys(contract.attrs).forEach(function(k){ raw.push({name:k, value:contract.attrs[k]}); });
    }
    // Safety net for common Spectrum tags. Some selected canvas items only keep
    // slot metadata, so merge the known preset props back in by tag.
    var preset = clonePreset(contract.tag || contract.name || '');
    if(preset && Array.isArray(preset.props)) raw = raw.concat(preset.props);
    return raw.map(function(p){
      if(typeof p==='string') return {name:p, value:''};
      return {name:p.name || p.attribute || p.attr || '', value:p.value === true ? true : (p.value != null ? p.value : (p.defaultValue != null ? p.defaultValue : ''))};
    }).filter(function(p){ if(!p.name || seen[p.name]) return false; seen[p.name]=true; return true; });
  }
  function innerTextFromMarkup(markup){
    var raw=String(markup||'');
    var m=raw.match(/^[\s\S]*?>\s*([\s\S]*?)\s*<\/\s*[a-z][a-z0-9-]*\s*>\s*$/i);
    if(!m) return '';
    return m[1].replace(/<[^>]+>/g,'').trim();
  }
  function composeMarkup(contract, values){
    values=values||{};
    var tag=String(values.tag || contract.tag || '').trim();
    if(!tag) return '';
    var attrs=normalizeProps(contract).map(function(p){
      var val = values['attr_'+p.name];
      if(val === undefined) val = p.value;
      if(val === false || val === null || val === undefined || String(val).trim()==='') return '';
      if(val === true || String(val)==='true') return ' '+p.name;
      return ' '+p.name+'="'+esc(String(val)).replace(/&quot;/g,'&quot;')+'"';
    }).join('');
    var slot = values.slotText !== undefined ? String(values.slotText) : innerTextFromMarkup(contract.markup);
    var selfClosing = !slot && /^<(sp-textfield|input|img|br|hr)\b/i.test(contract.markup||'');
    if(selfClosing && tag.indexOf('-')>-1) return '<'+tag+attrs+'></'+tag+'>';
    return '<'+tag+attrs+'>'+esc(slot)+'</'+tag+'>';
  }
  function rememberLastConfig(contract, markup){
    try { localStorage.setItem(LAST_CONFIG_KEY, JSON.stringify({tag:contract.tag, label:contract.label, markup:markup, at:Date.now()})); } catch(e){}
  }
  function openConfigure(contract, idx){
    var modal=document.createElement('div');
    modal.className='aq-registry-import-modal';
    var props=normalizeProps(contract);
    var propFields=props.map(function(p){ return '<label>'+esc(p.name)+'<input data-aq-config-attr="'+esc(p.name)+'" value="'+esc(p.value===true?'true':p.value)+'"></label>'; }).join('');
    var canUpdate = typeof idx === 'number' && idx >= builtIns.length;
    modal.innerHTML='<div class="aq-registry-import-dialog" role="dialog" aria-modal="true" aria-label="Configure Registry Component">'+
      '<h3>Configure Component</h3><div class="hint">Adjust the contract defaults before placing the component on the canvas.</div>'+
      '<div class="aq-registry-config-grid">'+
      '<label>Name<input id="aqCfgLabel" value="'+esc(contract.label||labelForTag(contract.tag))+'"></label>'+
      '<label>Tag<input id="aqCfgTag" value="'+esc(contract.tag||'')+'"></label>'+
      (propFields || '<div class="xsmall muted">No attributes detected yet. Paste richer markup through Import Component to capture props.</div>')+
      '<label>Default slot / label<textarea id="aqCfgSlot">'+esc(innerTextFromMarkup(contract.markup))+'</textarea></label>'+
      '</div><div class="aq-registry-config-preview" id="aqCfgPreview"></div>'+
      '<div class="aq-registry-config-actions"><button class="btn" id="aqCfgCancel" type="button">Cancel</button><button class="btn" id="aqCfgPreviewBtn" type="button">Refresh Preview</button>'+
      (canUpdate?'<button class="btn" id="aqCfgSave" type="button">Save Contract Defaults</button>':'')+
      '<button class="btn primary" id="aqCfgAdd" type="button">Add to Canvas</button></div></div>';
    document.body.appendChild(modal);
    function close(){ modal.remove(); }
    function values(){
      var v={ label:modal.querySelector('#aqCfgLabel').value, tag:modal.querySelector('#aqCfgTag').value, slotText:modal.querySelector('#aqCfgSlot').value };
      modal.querySelectorAll('[data-aq-config-attr]').forEach(function(el){ v['attr_'+el.getAttribute('data-aq-config-attr')]=el.value; });
      return v;
    }
    function markup(){ return composeMarkup(Object.assign({}, contract, {tag:values().tag}), values()); }
    function preview(){ modal.querySelector('#aqCfgPreview').textContent=markup(); }
    modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
    modal.querySelector('#aqCfgCancel').addEventListener('click', close);
    modal.querySelector('#aqCfgPreviewBtn').addEventListener('click', preview);
    modal.querySelector('#aqCfgAdd').addEventListener('click', function(){
      var html=markup();
      var label=values().label || contract.label || labelForTag(contract.tag);
      if(typeof window.addImportedHTMLSnippet === 'function'){
        window.addImportedHTMLSnippet(html, null, null, 'add configured registry component: '+label, label, {kind:'component-registry-configured', id:contract.id||values().tag, tag:values().tag, label:label, title:label, library:contract.library||detectLibrary(values().tag), registry:contractExportShape(Object.assign({}, contract, {tag:values().tag, label:label, markup:html}))});
        rememberLastConfig(contract, html); status('Added configured component: '+values().tag); close(); return;
      }
      addToCanvas(Object.assign({}, contract, {markup:html, label:label, proxy:null})); rememberLastConfig(contract, html); close();
    });
    var saveBtn=modal.querySelector('#aqCfgSave');
    if(saveBtn) saveBtn.addEventListener('click', function(){
      var arr=load(); var uidx=idx-builtIns.length; if(!arr[uidx]) return;
      arr[uidx].label=values().label; arr[uidx].tag=values().tag; arr[uidx].markup=markup();
      arr[uidx].props=props.map(function(p){ return {name:p.name, value:values()['attr_'+p.name]}; });
      save(arr); render(); showContract(arr[uidx]); status('Updated registry contract defaults: '+arr[uidx].tag); close();
    });
    preview(); setTimeout(function(){ var first=modal.querySelector('#aqCfgLabel'); if(first) first.focus(); },0);
  }

  function duplicateContract(idx){
    var arr=load(); var uidx=idx-builtIns.length; var item=arr[uidx];
    if(!item){ status('Only saved custom registry entries can be duplicated.'); return; }
    var copy=JSON.parse(JSON.stringify(item));
    copy.id='aq-contract-copy-'+Date.now();
    copy.label=(copy.label || labelForTag(copy.tag))+' Copy';
    arr.splice(uidx+1,0,copy); save(arr); render(); showContract(copy); status('Duplicated registry contract: '+copy.tag);
  }


  function normalizeContractForExport(contract){
    return {
      id: contract.id || ('selected-contract-' + Date.now()),
      name: contract.label || labelForTag(contract.tag) || 'Imported Component',
      tag: contract.tag || '',
      sourceLibrary: contract.library || detectLibrary(contract.tag || ''),
      defaultMarkup: contract.markup || composeMarkup(contract, {}),
      props: (contract.props || []).map(function(p){ return typeof p === 'string' ? {name:p} : p; }),
      slots: contract.slots || [],
      events: contract.events || [],
      notes: 'Exported from selected AQ Component Registry contract.'
    };
  }
  function downloadContractJson(contract){
    var payload = normalizeContractForExport(contract);
    downloadText('aq-selected-component-contract-'+(payload.tag||'component')+'.json', JSON.stringify(payload, null, 2), 'application/json');
    status('Downloaded selected contract JSON: '+(payload.tag||payload.name));
  }
  function copyContractJson(contract){
    var payload = normalizeContractForExport(contract);
    var text = JSON.stringify(payload, null, 2);
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).then(function(){ status('Copied selected contract JSON: '+(payload.tag||payload.name)); }, function(){ fallbackCopy(text, payload); });
    } else {
      fallbackCopy(text, payload);
    }
  }
  function fallbackCopy(text, payload){
    var ta=document.createElement('textarea');
    ta.value=text; ta.setAttribute('readonly',''); ta.style.position='fixed'; ta.style.left='-9999px';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); status('Copied selected contract JSON: '+(payload.tag||payload.name)); }
    catch(e){ status('Copy failed. Use Download Contract JSON instead.'); }
    ta.remove();
  }


  function aqPropKind(name){
    name=String(name||'').toLowerCase();
    if(/^(disabled|required|readonly|read-only|checked|selected|open|dismissable|error|no-divider|allow-multiple)$/.test(name)) return 'boolean';
    if(name==='variant') return 'variant';
    if(name==='size') return 'size';
    if(name==='treatment') return 'treatment';
    if(name==='tone' || name==='appearance') return 'tone';
    return 'text';
  }
  function aqOptionSelect(name, value, options){
    return '<select data-aq-live-attr="'+esc(name)+'">'+options.map(function(o){ return '<option value="'+esc(o)+'" '+(String(value)===String(o)?'selected':'')+'>'+esc(o)+'</option>'; }).join('')+'</select>';
  }
  function aqFriendlyPropLabel(name){
    var map={variant:'Style',size:'Size',treatment:'Treatment',disabled:'Disabled',label:'Label',placeholder:'Placeholder',value:'Value',required:'Required'};
    return map[name] || String(name||'').replace(/-/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();});
  }
  function aqLiveControlHtml(prop){
    var name=prop.name||'';
    var label=aqFriendlyPropLabel(name);
    var value=prop.value===true ? 'true' : (prop.value==null?'':String(prop.value));
    var kind=aqPropKind(name);
    if(kind==='boolean'){
      var checked=(value==='true' || value===true || value===name);
      return '<label class="aq-live-control aq-live-control-check"><span>'+esc(label)+'</span><input type="checkbox" data-aq-live-attr="'+esc(name)+'" '+(checked?'checked':'')+'></label>';
    }
    if(kind==='variant') return '<label class="aq-live-control"><span>'+esc(label)+'</span>'+aqOptionSelect(name, value||'primary', ['primary','success','neutral','warning','danger','text','secondary','negative'])+'</label>';
    if(kind==='size') return '<label class="aq-live-control"><span>'+esc(label)+'</span>'+aqOptionSelect(name, value||'medium', ['small','medium','large','s','m','l','xl'])+'</label>';
    if(kind==='treatment') return '<label class="aq-live-control"><span>'+esc(label)+'</span>'+aqOptionSelect(name, value||'fill', ['fill','outline'])+'</label>';
    if(kind==='tone') return '<label class="aq-live-control"><span>'+esc(label)+'</span>'+aqOptionSelect(name, value||'default', ['default','neutral','accent','positive','negative'])+'</label>';
    return '<label class="aq-live-control"><span>'+esc(label)+'</span><input data-aq-live-attr="'+esc(name)+'" value="'+esc(value)+'"></label>';
  }
  function aqBuildLiveControls(contract){
    var props=normalizeProps(contract);
    if(!props.length) return '<div class="xsmall muted">No contract props are available yet. Apply a preset or add props/attributes first.</div>';
    return props.map(aqLiveControlHtml).join('');
  }
  function aqReadLiveControlValues(host, contract){
    var values={ tag: (host.querySelector('#aqContractEditTag')||{}).value || contract.tag, slotText: (host.querySelector('#aqLiveSlotText')||{}).value || innerTextFromMarkup(contract.markup || contract.defaultMarkup || '') };
    host.querySelectorAll('[data-aq-live-attr]').forEach(function(el){
      var name=el.getAttribute('data-aq-live-attr');
      if(el.type==='checkbox') values['attr_'+name]=el.checked ? true : '';
      else values['attr_'+name]=el.value;
    });
    return values;
  }
  function aqApplyLiveControlsToSelected(host, contract){
    var item=selectedRegistryCanvasItem();
    if(!item){
      status('Select a canvas item before applying live property controls.');
      return;
    }
    var values = aqReadLiveControlValues(host, contract || {});
    var edited = contract || {};
    try {
      var propsText=(host.querySelector('#aqContractEditProps')||{}).value || '';
      var parsedProps=propsText.split(/\n+/).map(function(line){
        line=line.trim(); if(!line) return null;
        var eq=line.indexOf('=');
        if(eq<0) return {name:line, value:''};
        return {name:line.slice(0,eq).trim(), value:line.slice(eq+1).trim()};
      }).filter(function(p){ return p && p.name; });
      if(!parsedProps.length) parsedProps = normalizeProps(contract);
      edited=Object.assign({}, contract, {
        label:(host.querySelector('#aqContractEditName')||{}).value || contract.label || contract.name || labelForTag(contract.tag),
        tag:(host.querySelector('#aqContractEditTag')||{}).value || contract.tag || (item.importSource && item.importSource.tag) || '',
        library:(host.querySelector('#aqContractEditLibrary')||{}).value || contract.library || contract.sourceLibrary || (item.importSource && item.importSource.library) || detectLibrary(contract.tag),
        markup:(host.querySelector('#aqContractEditMarkup')||{}).value || contract.markup || contract.defaultMarkup || item.html || '',
        props:parsedProps,
        slots: contract.slots || [],
        events: contract.events || []
      });
    } catch(e){}

    if(/^sl-/.test(String(edited.tag||''))) ensureShoelaceRuntime();
    var markup=composeMarkup(edited, values);

    // Imported HTML registry components render from item.html.
    item.html=markup;

    // Built-in Spectrum registry shortcuts render from external-plugin props,
    // so update item.props as well. This is the key v1N2 fix.
    if(item.type === 'external-plugin'){
      item.props = Object.assign({}, item.props || {});
      if(values.slotText !== undefined && values.slotText !== '') item.props.label = values.slotText;
      Object.keys(values).forEach(function(key){
        if(key.indexOf('attr_') !== 0) return;
        var attr = key.slice(5);
        var val = values[key];
        if(val === '' || val === null || val === undefined){
          if(/^(disabled|required|readonly|checked|open)$/i.test(attr)) item.props[attr] = false;
          return;
        }
        if(val === true || val === 'true') item.props[attr] = true;
        else item.props[attr] = val;
      });
      // Spectrum button adapter uses label/variant/treatment/size/disabled.
      if(item.pluginId === 'spectrum-button' && !item.props.variant) item.props.variant = 'accent';
    }

    item.title=edited.label || item.title || labelForTag(edited.tag);
    item.importSource=item.importSource || {kind:'component-registry-selected'};
    item.importSource.kind=item.importSource.kind || 'component-registry-selected';
    item.importSource.tag=edited.tag;
    item.importSource.label=edited.label || item.importSource.label;
    item.importSource.title=edited.label || item.importSource.title;
    item.importSource.library=edited.library || item.importSource.library;
    item.importSource.registry=contractExportShape(Object.assign({}, edited, {markup:markup}));
    item.__componentRegistryContract=item.importSource.registry;
    try { if(typeof window.render==='function') window.render(); } catch(e){}
    // v1N4: avoid flashing/resetting the normal right panel after applying live controls.
    status('Applied settings to selected registry component: '+(edited.tag||item.title)); updateRegistryCanvasSummaryView(); setTimeout(aqUpdateRightRegistryPanel,0);
  }

  function showContract(contract, idx){
    var host=$('aqRegistryContractView');
    if(!host){
      var panel=$('aqRegistryPanel');
      host=document.createElement('div'); host.id='aqRegistryContractView'; host.className='aq-registry-contract-view';
      if(panel) panel.appendChild(host);
    }
    var props=(contract.props||[]).map(function(p){ return typeof p==='string'?{name:p,value:''}:p; });
    var propLines=props.map(function(p){ return (p.name||'')+(p.value!==undefined && p.value!=='' ? '=' + p.value : ''); }).join('\n');
    var sourceIndex = (typeof idx === 'number') ? idx : (typeof contract.__registryIndex === 'number' ? contract.__registryIndex : -1);
    host.setAttribute('data-registry-index', String(sourceIndex));
    host.innerHTML='<div class="aq-contract-heading">Component Contract</div>'+
      '<div class="aq-contract-summary-card"><div><strong>'+esc(contract.label||contract.name||labelForTag(contract.tag))+'</strong></div><div class="xsmall muted">Type: Imported Contract · Source: '+esc(contract.source||contract.library||detectLibrary(contract.tag))+' · Tag: '+esc(contract.tag||'')+' · Props: '+normalizeProps(contract).length+' · Slots: '+((contract.slots||[]).length)+'</div></div>'+
      '<div class="xsmall muted aq-basic-help">Select a registry component on the canvas, adjust the basic settings, then apply.</div>'+
      '<div class="aq-contract-preset-row aq-basic-preset-row">'+
        '<label>Quick preset<select id="aqContractPresetSelect">'+presetOptions(contract.tag||'')+'</select></label>'+
        '<button class="btn" id="aqApplyContractPresetBtn" type="button">Apply Preset</button>'+
      '</div>'+
      '<div class="aq-contract-live-panel aq-basic-settings-panel">'+
        '<div class="aq-contract-heading">Basic settings</div>'+ 
        '<label class="aq-live-control"><span>Text / label</span><input id="aqLiveSlotText" value="'+esc(innerTextFromMarkup(contract.markup||contract.defaultMarkup||''))+'"></label>'+ 
        '<div class="aq-live-controls-grid">'+aqBuildLiveControls(contract)+'</div>'+ 
        '<button class="btn primary" id="aqApplyLiveControlsBtn" type="button">Apply to Selected Component</button>'+ 
      '</div>'+ 
      '<details class="aq-registry-advanced">'+
        '<summary>Advanced contract details</summary>'+
        '<div class="xsmall muted">Edit the underlying contract only when you need props, slots, events, JSON, or handoff notes.</div>'+
        '<div class="aq-contract-edit-grid">'+
          '<label>Name<input id="aqContractEditName" value="'+esc(contract.label||contract.name||'')+'"></label>'+ 
          '<label>Tag<input id="aqContractEditTag" value="'+esc(contract.tag||'')+'"></label>'+ 
          '<label>Library<input id="aqContractEditLibrary" value="'+esc(contract.library||contract.sourceLibrary||'Custom')+'"></label>'+ 
          '<label>Default markup<textarea id="aqContractEditMarkup" spellcheck="false">'+esc(contract.markup||contract.defaultMarkup||'')+'</textarea></label>'+ 
          '<label>Props / attributes <span class="xsmall muted">one per line, name=value</span><textarea id="aqContractEditProps" spellcheck="false">'+esc(propLines)+'</textarea></label>'+ 
          '<label>Slots <span class="xsmall muted">comma separated</span><input id="aqContractEditSlots" value="'+esc((contract.slots||[]).join(', '))+'"></label>'+ 
          '<label>Events <span class="xsmall muted">comma separated</span><input id="aqContractEditEvents" value="'+esc((contract.events||[]).join(', '))+'"></label>'+ 
        '</div>'+
        '<div class="aq-contract-handoff"><strong>Handoff:</strong> source library + default markup will be included in registry JSON.</div>'+ 
        '<div class="aq-registry-mini-actions">'+
          '<button class="btn primary" id="aqSaveSelectedContractBtn" type="button">Save Contract Changes</button>'+ 
          '<button class="btn" id="aqCopySelectedContractBtn" type="button">Copy Contract JSON</button>'+ 
          '<button class="btn" id="aqDownloadSelectedContractJsonBtn" type="button">Download Contract JSON</button>'+ 
          '<button class="btn" id="aqDownloadSelectedContractBtn" type="button">Download Notes</button>'+ 
        '</div>'+
      '</details>';
    function readEditedContract(){
      var propsText=(host.querySelector('#aqContractEditProps')||{}).value || '';
      var parsedProps=propsText.split(/\n+/).map(function(line){
        line=line.trim(); if(!line) return null;
        var eq=line.indexOf('=');
        if(eq<0) return {name:line, value:''};
        return {name:line.slice(0,eq).trim(), value:line.slice(eq+1).trim()};
      }).filter(function(p){ return p && p.name; });
      var slotsText=(host.querySelector('#aqContractEditSlots')||{}).value || '';
      var eventsText=(host.querySelector('#aqContractEditEvents')||{}).value || '';
      return Object.assign({}, contract, {
        label:(host.querySelector('#aqContractEditName')||{}).value || contract.label || contract.name || labelForTag(contract.tag),
        tag:(host.querySelector('#aqContractEditTag')||{}).value || contract.tag,
        library:(host.querySelector('#aqContractEditLibrary')||{}).value || contract.library || contract.sourceLibrary || detectLibrary(contract.tag),
        markup:(host.querySelector('#aqContractEditMarkup')||{}).value || contract.markup || contract.defaultMarkup || '',
        props:parsedProps,
        slots:slotsText.split(',').map(function(s){return s.trim();}).filter(Boolean),
        events:eventsText.split(',').map(function(s){return s.trim();}).filter(Boolean)
      });
    }
    // v1N4: keep generated live controls from triggering the main editor/right-panel
    // delegated handlers while the user is only adjusting contract values locally.
    var livePanel = host.querySelector('.aq-contract-live-panel');
    if(livePanel){
      // v1O2: do not block the Apply button click. Earlier capture-level
      // click suppression prevented Basic settings from updating the canvas.
      ['input','change','mousedown','mouseup'].forEach(function(evtName){
        livePanel.addEventListener(evtName, function(evt){
          evt.stopPropagation();
        }, true);
      });
      livePanel.addEventListener('click', function(evt){
        if(evt.target && evt.target.closest && evt.target.closest('#aqApplyLiveControlsBtn')) return;
        evt.stopPropagation();
      }, false);
    }

    var applyPresetBtn=host.querySelector('#aqApplyContractPresetBtn');
    if(applyPresetBtn) applyPresetBtn.addEventListener('click', function(){
      var select=host.querySelector('#aqContractPresetSelect');
      var preset=clonePreset(select && select.value);
      if(!preset){ status('Choose a contract preset first.'); return; }
      var name=host.querySelector('#aqContractEditName'); if(name) name.value=preset.label||'';
      var tag=host.querySelector('#aqContractEditTag'); if(tag) tag.value=preset.tag||select.value||'';
      var lib=host.querySelector('#aqContractEditLibrary'); if(lib) lib.value=preset.library||'Spectrum';
      var markup=host.querySelector('#aqContractEditMarkup'); if(markup) markup.value=preset.markup||'';
      var propsBox=host.querySelector('#aqContractEditProps'); if(propsBox) propsBox.value=propLinesFromPreset(preset);
      var slotsBox=host.querySelector('#aqContractEditSlots'); if(slotsBox) slotsBox.value=(preset.slots||[]).join(', ');
      var eventsBox=host.querySelector('#aqContractEditEvents'); if(eventsBox) eventsBox.value=(preset.events||[]).join(', ');
      setTimeout(aqUpdateRightRegistryPanel,0); status('Applied preset for '+(preset.label||select.value)+'. Review, then Save Contract Changes if needed.');
    });
    var saveEditBtn=host.querySelector('#aqSaveSelectedContractBtn');
    if(saveEditBtn) saveEditBtn.addEventListener('click', function(){
      var edited=readEditedContract();
      var sourceIndex=Number(host.getAttribute('data-registry-index'));
      if(!isNaN(sourceIndex) && sourceIndex>=builtIns.length){
        var arr=load(); var uidx=sourceIndex-builtIns.length;
        if(arr[uidx]){
          arr[uidx]=Object.assign({}, arr[uidx], edited, {id:arr[uidx].id || edited.id});
          save(arr); render();
          contract=arr[uidx];
          showContract(contract, sourceIndex);
          status('Saved editable contract: '+(contract.tag||contract.label));
          return;
        }
      }
      // Built-in/selected canvas contracts cannot overwrite protected built-ins,
      // but the current panel/export values should use the edited contract.
      contract=edited;
      showContract(contract, sourceIndex);
      status('Updated contract panel values. Built-in shortcuts remain protected.');
    });
    var liveBtn=host.querySelector('#aqApplyLiveControlsBtn');
    if(liveBtn) liveBtn.addEventListener('click', function(evt){ if(evt){ evt.preventDefault(); evt.stopPropagation(); } aqApplyLiveControlsToSelected(host, readEditedContract()); });
    var copyBtn=host.querySelector('#aqCopySelectedContractBtn');
    if(copyBtn) copyBtn.addEventListener('click', function(){ copyContractJson(readEditedContract()); });
    var jsonBtn=host.querySelector('#aqDownloadSelectedContractJsonBtn');
    if(jsonBtn) jsonBtn.addEventListener('click', function(){ downloadContractJson(readEditedContract()); });
    var dl=host.querySelector('#aqDownloadSelectedContractBtn');
    if(dl) dl.addEventListener('click', function(){ downloadContractMarkdown(readEditedContract()); });
  }

  function selectedRegistryCanvasItem(){
    try {
      // Preferred path: ask the real editor for its selected item.
      // window.state is not public in AQ, so relying on it caused false
      // "No registry component selected" messages.
      if(typeof window.getAQSelectedItem === 'function'){
        var direct = window.getAQSelectedItem();
        if(direct) return direct;
      }
      // Fallback only: older builds may expose state publicly.
      if(window.state && window.state.selected && Array.isArray(window.state.sections)){
        var selectedId = window.state.selected.itemId || window.state.selected.id;
        for(var i=0;i<window.state.sections.length;i++){
          var items = window.state.sections[i].items || [];
          for(var j=0;j<items.length;j++){
            if(items[j].id === selectedId) return items[j];
          }
        }
      }
    } catch(e){}
    return null;
  }
  function showSelectedCanvasRegistryContract(){
    var item = selectedRegistryCanvasItem();
    if(!item || !item.importSource || String(item.importSource.kind||'').indexOf('component-registry') !== 0){
      var host=$('aqRegistryContractView');
      if(!host){
        var panel=$('aqRegistryPanel');
        host=document.createElement('div'); host.id='aqRegistryContractView'; host.className='aq-registry-contract-view';
        if(panel) panel.appendChild(host);
      }
      host.innerHTML='<div class="aq-contract-heading">Selected Canvas Contract</div>'+ 
        '<div class="aq-contract-empty"><strong>No registry component selected.</strong></div>'+ 
        '<div class="xsmall muted">First add a component from Component Registry to the canvas, select that canvas item, then click <strong>Update Settings from Selection</strong>.</div>';
      host.classList.add('aq-contract-flash');
      setTimeout(function(){ host.classList.remove('aq-contract-flash'); }, 900);
      if(host.scrollIntoView) host.scrollIntoView({block:'nearest'});
      status('Select a registry component on the canvas first.');
      return;
    }
    var registry = item.importSource.registry || null;
    var contract = registry ? {
      id: registry.id,
      tag: registry.tag || item.importSource.tag,
      label: registry.name || item.importSource.label || item.title,
      library: registry.sourceLibrary || item.importSource.library || detectLibrary(item.importSource.tag),
      markup: item.html || registry.defaultMarkup || '',
      props: registry.props || registry.attributes || [],
      attributes: registry.attributes || [],
      slots: registry.slots || [],
      events: registry.events || []
    } : toContract(item.html || '');
    // v1N3: when the selected canvas item carries only slot/default markup,
    // restore the expected editable props from the built-in/preset definition.
    var preset = clonePreset(contract.tag || '');
    if((!contract.props || !contract.props.length) && preset && preset.props){ contract.props = preset.props; }
    if((!contract.slots || !contract.slots.length) && preset && preset.slots){ contract.slots = preset.slots; }
    if((!contract.events || !contract.events.length) && preset && preset.events){ contract.events = preset.events; }
    showContract(contract);
    var host=$('aqRegistryContractView');
    if(host){
      host.classList.add('aq-contract-flash');
      setTimeout(function(){ host.classList.remove('aq-contract-flash'); }, 900);
      if(host.scrollIntoView) host.scrollIntoView({block:'nearest'});
    }
    status('Updated selected canvas contract: '+(contract.tag||item.title));
  }

  var aqRegistryCollapsedGroups = window.aqRegistryCollapsedGroups || (window.aqRegistryCollapsedGroups = {});

  function openRegistryPanel(){
    var panel=$('aqRegistryPanel');
    var toggle=$('aqRegistryToggleBtn');
    if(panel) panel.classList.remove('hidden');
    if(toggle){
      toggle.setAttribute('aria-expanded','true');
      var chev=toggle.querySelector('.template-chevron');
      if(chev) chev.textContent='▲';
    }
  }

  function render(){
    var list=$('aqRegistryList'); if(!list) return;
    var userContracts=load();
    var all=builtIns.concat(userContracts);
    var visible=all.map(function(c,i){ return {contract:c, index:i}; });
    if(!visible.length){
      list.innerHTML='<div class="aq-registry-empty">No additional components saved yet. Use Add a Component to import or add from a library.</div>';
      return;
    }
    var grouped={};
    visible.forEach(function(entry){
      var c=entry.contract;
      var group=(entry.index>=builtIns.length) ? 'Imported Contracts' : (c.library || 'Built-ins');
      if(!grouped[group]) grouped[group]=[];
      grouped[group].push(entry);
    });
    var html=[];
    Object.keys(grouped).forEach(function(group){
      // v2J: library groups behave like dropdowns and are collapsed by default.
      // A group is only open after the user explicitly opens it in this session.
      var collapsed=(aqRegistryCollapsedGroups[group] !== false);
      html.push('<button class="aq-registry-subhead" type="button" data-registry-group="'+esc(group)+'" aria-expanded="'+(collapsed?'false':'true')+'"><span>'+esc(group)+'</span><span class="aq-registry-group-count">'+grouped[group].length+'</span><span class="aq-registry-group-chevron">'+(collapsed?'▸':'▾')+'</span></button>');
      if(collapsed) return;
      grouped[group].forEach(function(entry){
        var c=entry.contract, i=entry.index;
        var isImported=i>=builtIns.length;
        var propsCount=normalizeProps(c).length;
        var slotsCount=(c.slots||[]).length;
        if(isImported){
          html.push('<div class="aq-registry-row aq-imported-contract-row" data-registry-index="'+i+'">'+
            '<button class="palette-item aq-registry-card aq-registry-contract" type="button" title="View contract: '+esc(c.label||labelForTag(c.tag))+'">'+
              '<span class="palette-icon">'+esc(c.icon||'🌐')+'</span>'+
              '<span class="aq-registry-card-text"><strong>'+esc(c.label||labelForTag(c.tag))+'</strong>'+
              '<small>Source: '+esc(c.source||c.library||detectLibrary(c.tag))+' · Tag: '+esc(c.tag||'')+' · Props: '+propsCount+' · Slots: '+slotsCount+'</small></span>'+ 
            '</button>'+
            '<button class="btn aq-registry-add" type="button">Add</button>'+
            '<button class="btn aq-registry-configure" type="button">Configure</button>'+
            '<button class="btn aq-registry-duplicate" type="button">Duplicate</button><button class="btn danger aq-registry-delete" type="button">Delete</button>'+
          '</div>');
        } else {
          html.push('<div class="aq-registry-row" data-registry-index="'+i+'">'+
            '<button class="palette-item aq-registry-add" type="button" title="Add '+esc(c.label||labelForTag(c.tag))+'"><span class="palette-icon">'+esc(c.icon||'⬒')+'</span><span>'+esc(c.label||labelForTag(c.tag))+'</span></button>'+
            '<button class="btn aq-registry-contract" type="button" title="View contract info">Info</button>'+
            '<button class="btn aq-registry-configure" type="button">Configure</button>'+
          '</div>');
        }
      });
    });
    list.innerHTML=html.join('');
    list.querySelectorAll('[data-registry-group]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var group=btn.getAttribute('data-registry-group');
        var isCollapsed=(aqRegistryCollapsedGroups[group] !== false);
        aqRegistryCollapsedGroups[group]=isCollapsed ? false : true;
        render();
      });
    });
    list.querySelectorAll('[data-registry-index]').forEach(function(row){
      var idx=Number(row.getAttribute('data-registry-index')); var contract=all[idx];
      row.querySelector('.aq-registry-add').addEventListener('click', function(){ addToCanvas(contract); });
      row.querySelector('.aq-registry-contract').addEventListener('click', function(){ showContract(contract, idx); setTimeout(aqUpdateRightRegistryPanel,0); status('Showing component info: '+contract.tag); });
      row.querySelector('.aq-registry-configure').addEventListener('click', function(){ openConfigure(contract, idx); });
      var dup=row.querySelector('.aq-registry-duplicate');
      if(dup) dup.addEventListener('click', function(){ duplicateContract(idx); });
      var del=row.querySelector('.aq-registry-delete');
      if(del) del.addEventListener('click', function(){ var arr=load(); arr.splice(idx-builtIns.length,1); save(arr); render(); status('Deleted registry contract.'); });
    });
  }
  function openImport(){
    var modal=document.createElement('div');
    modal.className='aq-registry-import-modal';
    modal.innerHTML='<div class="aq-registry-import-dialog" role="dialog" aria-modal="true" aria-label="Import Component">'+
      '<h3>Import Component</h3><div class="hint">Paste real component markup, customElements.define code, Storybook argTypes, or AQ contract JSON.</div>'+
      '<label for="aqImportType">Import Type</label>'+
      '<select id="aqImportType" style="width:100%;margin:4px 0 10px;">'+
        '<option value="web-component">Web Component</option>'+
        '<option value="spectrum">Spectrum</option>'+
        '<option value="storybook">Storybook</option>'+
        '<option value="json-contract">JSON Contract</option>'+
      '</select>'+
      '<label for="aqImportMarkup">Paste source / metadata</label>'+
      '<textarea id="aqImportMarkup" spellcheck="false">class AcmeButton extends HTMLElement {\n  static get observedAttributes() {\n    return [\'variant\', \'size\', \'disabled\'];\n  }\n}\ncustomElements.define(\'acme-button\', AcmeButton);</textarea>'+
      '<div class="aq-registry-import-actions"><button class="btn" id="aqImportCancel" type="button">Cancel</button><button class="btn" id="aqImportPreview" type="button">Parse Source</button><button class="btn primary" id="aqImportSave" type="button">Save Contract</button></div>'+
      '<label for="aqImportDetected">Generated normalized contract</label>'+
      '<pre id="aqImportDetected" class="aq-registry-detected" style="white-space:pre-wrap;max-height:220px;overflow:auto;"></pre></div>';
    document.body.appendChild(modal);
    function close(){ modal.remove(); }
    function draft(){ return toContract(modal.querySelector('#aqImportMarkup').value, modal.querySelector('#aqImportType').value); }
    function preview(){ var c=draft(); if(!c.tag){ status('Could not detect a tag from the pasted component.'); return; } modal.querySelector('#aqImportDetected').textContent=JSON.stringify(contractExportShape(c), null, 2); }
    modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
    modal.querySelector('#aqImportCancel').addEventListener('click', close);
    modal.querySelector('#aqImportPreview').addEventListener('click', preview);
    modal.querySelector('#aqImportSave').addEventListener('click', function(){
      var c=draft();
      if(!c.tag){ status('Could not detect a tag from the pasted component.'); return; }
      var arr=load();
      arr.push(c);
      save(arr);
      aqRegistryCollapsedGroups['Imported Contracts']=false;
      openRegistryPanel();
      render();
      openRegistryPanel();
      showContract(c, builtIns.length + arr.length - 1);
      status('Saved imported contract card under More Components → Imported Contracts: '+c.tag+' (persists after refresh).');
      close();
    });
    setTimeout(function(){ var t=$('aqImportMarkup'); if(t) { t.focus(); t.select(); } },0);
  }



  function aqRightPanelHost(){
    var candidates=[
      '#propertiesPanel',
      '#rightPanel',
      '#inspector',
      '.properties-panel',
      '.right-panel',
      '.inspector',
      '[data-panel="properties"]',
      '[data-testid="properties-panel"]'
    ];
    for(var i=0;i<candidates.length;i++){
      var el=document.querySelector(candidates[i]);
      if(el) return el;
    }
    // Fallback: use registry panel so the feature still remains reachable.
    return $('aqRegistryPanel');
  }

  function aqEnsureRightRegistryPanel(){
    var host=aqRightPanelHost();
    if(!host) return null;
    var panel=$('aqRightRegistryComponentPanel');
    if(!panel){
      panel=document.createElement('div');
      panel.id='aqRightRegistryComponentPanel';
      panel.className='aq-right-registry-panel';
      // Put it near the top of the properties area.
      if(host.firstChild) host.insertBefore(panel, host.firstChild);
      else host.appendChild(panel);
    }
    return panel;
  }

  function aqSelectedRegistryItemForRightPanel(){
    var item=selectedRegistryCanvasItem();
    if(item && item.importSource && String(item.importSource.kind||'').indexOf('component-registry')===0) return item;
    return null;
  }

  function aqContractFromSelectedItem(item){
    item=item||aqSelectedRegistryItemForRightPanel();
    if(!item) return null;
    var src=item.importSource || {};
    var reg=src.registry || item.__componentRegistryContract || {};
    var contract={
      id:reg.id || src.id || src.tag,
      tag:reg.tag || src.tag || '',
      label:reg.name || src.label || item.title || labelForTag(reg.tag || src.tag),
      library:reg.sourceLibrary || src.library || detectLibrary(reg.tag || src.tag),
      markup:item.html || reg.defaultMarkup || '',
      props:reg.props || reg.attributes || [],
      attributes:reg.attributes || [],
      slots:reg.slots || [],
      events:reg.events || []
    };
    var preset=clonePreset(contract.tag || '');
    if((!contract.props || !contract.props.length) && preset && preset.props) contract.props=preset.props;
    if((!contract.slots || !contract.slots.length) && preset && preset.slots) contract.slots=preset.slots;
    if((!contract.events || !contract.events.length) && preset && preset.events) contract.events=preset.events;
    return contract;
  }

  function aqRightControlHtml(prop){
    return aqLiveControlHtml(prop).replace(/data-aq-live-attr/g, 'data-aq-right-attr');
  }

  function aqReadRightControlValues(panel, contract){
    var values={tag: contract.tag, slotText:(panel.querySelector('#aqRightRegistryLabel')||{}).value || innerTextFromMarkup(contract.markup || contract.defaultMarkup || '')};
    panel.querySelectorAll('[data-aq-right-attr]').forEach(function(el){
      var name=el.getAttribute('data-aq-right-attr');
      if(el.type==='checkbox') values['attr_'+name]=el.checked ? true : '';
      else values['attr_'+name]=el.value;
    });
    return values;
  }

  function aqApplyRightPanelRegistrySettings(options){
    options=options||{};
    var item=aqSelectedRegistryItemForRightPanel();
    var panel=$('aqRightRegistryComponentPanel');
    if(!item || !panel){ status('Select a registry component first.'); return; }
    var contract=aqContractFromSelectedItem(item);
    if(!contract){ status('No registry contract found for selected component.'); return; }
    var values=aqReadRightControlValues(panel, contract);
    if(/^sl-/.test(String(contract.tag||''))) ensureShoelaceRuntime();
    var markup=composeMarkup(contract, values);
    item.html=markup;

    if(item.type === 'external-plugin'){
      item.props=Object.assign({}, item.props || {});
      if(values.slotText !== undefined && values.slotText !== '') item.props.label=values.slotText;
      Object.keys(values).forEach(function(key){
        if(key.indexOf('attr_') !== 0) return;
        var attr=key.slice(5);
        var val=values[key];
        if(val === '' || val === null || val === undefined){
          if(/^(disabled|required|readonly|checked|open)$/i.test(attr)) item.props[attr]=false;
          return;
        }
        if(val === true || val === 'true') item.props[attr]=true;
        else item.props[attr]=val;
      });
      if(item.pluginId === 'spectrum-button' && !item.props.variant) item.props.variant='primary';
    }

    item.title=contract.label || item.title || labelForTag(contract.tag);
    item.importSource=item.importSource || {kind:'component-registry'};
    item.importSource.registry=contractExportShape(Object.assign({}, contract, {markup:markup}));
    item.__componentRegistryContract=item.importSource.registry;

    try { if(typeof window.render==='function') window.render(); } catch(e){}
    if(!options.preservePanel) setTimeout(aqUpdateRightRegistryPanel, 0);
    status('Updated selected registry component from right panel.');
  }


  function aqResetRightPanelRegistryDefaults(){
    var item=aqSelectedRegistryItemForRightPanel();
    var panel=$('aqRightRegistryComponentPanel');
    if(!item || !panel){ status('Select a registry component first.'); return; }
    var contract=aqContractFromSelectedItem(item);
    if(!contract){ status('No registry contract found for selected component.'); return; }
    var preset=clonePreset(contract.tag || '');
    if(!preset){ status('No default preset found for '+(contract.tag||'selected component')+'.'); return; }
    // Preserve the currently selected canvas item, but restore the default contract markup/props.
    item.html=preset.markup || contract.markup || item.html || '';
    if(item.type === 'external-plugin'){
      item.props=Object.assign({}, item.props || {});
      normalizeProps(preset).forEach(function(p){
        if(!p || !p.name) return;
        item.props[p.name]=p.value;
      });
      var text=innerTextFromMarkup(preset.markup||'');
      if(text) item.props.label=text;
      if(item.pluginId === 'spectrum-button' && !item.props.variant) item.props.variant='primary';
    }
    item.importSource=item.importSource || {kind:'component-registry'};
    item.importSource.registry=contractExportShape(preset);
    item.__componentRegistryContract=item.importSource.registry;
    try { if(typeof window.render==='function') window.render(); } catch(e){}
    setTimeout(aqUpdateRightRegistryPanel, 0);
    status('Reset selected registry component to defaults.');
  }


  function aqRegistryDisplayNameFromItem(item, contract){
    contract=contract || aqContractFromSelectedItem(item) || {};
    return contract.label || (item && item.title) || labelForTag(contract.tag || (item && item.importSource && item.importSource.tag) || '');
  }

  function aqClearCanvasRegistryBadges(){
    document.querySelectorAll('.aq-canvas-registry-badge').forEach(function(el){ el.remove(); });
    document.querySelectorAll('.aq-registry-selected-outline').forEach(function(el){ el.classList.remove('aq-registry-selected-outline'); });
  }

  function aqFindCanvasElementForItem(item){
    if(!item) return null;
    var id=item.id || item.itemId;
    if(id){
      var selectors=[
        '[data-item-id="'+CSS.escape(String(id))+'"]',
        '[data-id="'+CSS.escape(String(id))+'"]',
        '#'+CSS.escape(String(id))
      ];
      for(var i=0;i<selectors.length;i++){
        try {
          var el=document.querySelector(selectors[i]);
          if(el) return el;
        } catch(e){}
      }
    }
    // Fallback: try selected visual affordances commonly used by editors.
    return document.querySelector('.selected,.is-selected,[aria-selected="true"],.canvas-item.selected,.node.selected');
  }

  function aqUpdateCanvasRegistryBadge(){
    aqClearCanvasRegistryBadges();
    var item=aqSelectedRegistryItemForRightPanel();
    if(!item) return;
    var el=aqFindCanvasElementForItem(item);
    if(!el || !el.getBoundingClientRect) return;
    el.classList.add('aq-registry-selected-outline');
    var rect=el.getBoundingClientRect();
    var badge=document.createElement('div');
    badge.className='aq-canvas-registry-badge';
    var contract=aqContractFromSelectedItem(item);
    badge.textContent=aqRegistryDisplayNameFromItem(item, contract);
    badge.style.left=Math.max(8, rect.left + window.scrollX) + 'px';
    badge.style.top=Math.max(8, rect.top + window.scrollY - 24) + 'px';
    document.body.appendChild(badge);
  }

  function aqUpdateRightRegistryPanel(){
    var panel=aqEnsureRightRegistryPanel();
    if(!panel) return;
    var item=aqSelectedRegistryItemForRightPanel();
    if(!item){
      panel.innerHTML='<div class="aq-right-registry-empty"><strong>Registry Component</strong><div class="xsmall muted">Select a registry Button or Text Field on the canvas to edit its basic settings here.</div></div>'; aqClearCanvasRegistryBadges();
      return;
    }
    var contract=aqContractFromSelectedItem(item);
    if(!contract){
      panel.innerHTML='<div class="aq-right-registry-empty"><strong>Registry Component</strong><div class="xsmall muted">No registry contract found.</div></div>';
      return;
    }
    var props=normalizeProps(contract);
    panel.innerHTML='<div class="aq-right-registry-heading">Registry Component</div>'+
      '<div class="aq-right-registry-meta aq-right-registry-identity"><div><strong>'+esc(contract.label||labelForTag(contract.tag))+'</strong></div><div><span>Type:</span> '+esc(labelForTag(contract.tag))+'</div><div><span>Source:</span> Component Registry · '+esc(contract.library||'Registry')+'</div><div><span>Tag:</span> <code>'+esc(contract.tag||'')+'</code></div></div>'+
      '<label class="aq-live-control"><span>Text / label</span><input id="aqRightRegistryLabel" value="'+esc(innerTextFromMarkup(contract.markup||contract.defaultMarkup||''))+'"></label>'+
      '<div class="aq-live-controls-grid aq-right-controls-grid">'+(props.length ? props.map(aqRightControlHtml).join('') : '<div class="xsmall muted">No basic settings available for this component.</div>')+'</div>'+
      '<label class="aq-right-auto-apply"><span>Auto apply changes</span><input type="checkbox" id="aqRightAutoApplyRegistrySettings" checked></label>'+
      '<div class="aq-right-registry-actions"><button class="btn primary" id="aqRightApplyRegistrySettingsBtn" type="button">Apply Changes</button><button class="btn" id="aqRightResetRegistryDefaultsBtn" type="button">Reset Defaults</button></div>'+
      '<details class="aq-right-registry-advanced"><summary>Advanced</summary><button class="btn" id="aqRightOpenRegistrySettingsBtn" type="button">Open Contract Details</button></details>';
    var apply=panel.querySelector('#aqRightApplyRegistrySettingsBtn');
    if(apply) apply.addEventListener('click', function(evt){ evt.preventDefault(); evt.stopPropagation(); aqApplyRightPanelRegistrySettings(); });
    var resetDefaults=panel.querySelector('#aqRightResetRegistryDefaultsBtn');
    if(resetDefaults) resetDefaults.addEventListener('click', function(evt){ evt.preventDefault(); evt.stopPropagation(); aqResetRightPanelRegistryDefaults(); });
    var autoTimer=null;
    function scheduleAutoApply(evt){
      var auto=panel.querySelector('#aqRightAutoApplyRegistrySettings');
      if(!auto || !auto.checked) return;
      if(evt && evt.target && evt.target.id==='aqRightAutoApplyRegistrySettings') return;
      clearTimeout(autoTimer);
      autoTimer=setTimeout(function(){ aqApplyRightPanelRegistrySettings({preservePanel:true}); }, 180);
    }
    panel.querySelectorAll('#aqRightRegistryLabel,[data-aq-right-attr]').forEach(function(ctrl){
      ctrl.addEventListener('change', scheduleAutoApply);
      ctrl.addEventListener('input', scheduleAutoApply);
    });
    var open=panel.querySelector('#aqRightOpenRegistrySettingsBtn');
    if(open) open.addEventListener('click', function(evt){ evt.preventDefault(); evt.stopPropagation(); showContract(contract); setTimeout(aqUpdateRightRegistryPanel,0); status('Opened advanced registry contract details.'); });
    ['mousedown','mouseup','click','input','change'].forEach(function(evtName){
      panel.addEventListener(evtName, function(evt){
        // Let native select option picking happen, but keep editor-level delegation quiet.
        evt.stopPropagation();
      }, false);
    });
    setTimeout(aqUpdateCanvasRegistryBadge, 0);
  }

  function aqEventInsideRegistryUi(evt){
    var t=evt && evt.target;
    return !!(t && t.closest && (t.closest('#aqRightRegistryComponentPanel') || t.closest('#aqRegistryPanel') || t.closest('.aq-registry-import-modal')));
  }
  function aqInstallRightPanelSelectionHooks(){
    // Do not refresh while the user is interacting with dropdowns/inputs.
    // That was closing right-panel selects before a selection could be made.
    document.addEventListener('click', function(evt){
      if(aqEventInsideRegistryUi(evt)) return;
      setTimeout(aqUpdateRightRegistryPanel, 0);
    }, false);
    document.addEventListener('focusin', function(evt){
      if(aqEventInsideRegistryUi(evt)) return;
      setTimeout(aqUpdateRightRegistryPanel, 0);
    }, false);
    document.addEventListener('keyup', function(evt){
      if(aqEventInsideRegistryUi(evt)) return;
      setTimeout(aqUpdateRightRegistryPanel, 0);
    }, false);
    window.addEventListener('scroll', function(){ setTimeout(aqUpdateCanvasRegistryBadge,0); }, true);
    window.addEventListener('resize', function(){ setTimeout(aqUpdateCanvasRegistryBadge,0); }, false);
  }

  function getRegistryCanvasItems(){
    var items=[];
    var seen={};
    function add(sectionName, item){
      if(!item) return;
      var key=item.id || item.itemId || item.html || JSON.stringify(item.importSource||{}) || Math.random();
      if(seen[key]) return;
      seen[key]=true;
      items.push({section:sectionName||'Canvas', item:item});
    }

    // Primary: AQ internal state, when available.
    try {
      if(window.state && Array.isArray(window.state.sections)){
        window.state.sections.forEach(function(section, sectionIndex){
          (section.items||[]).forEach(function(item){
            if(item && item.importSource && String(item.importSource.kind||'').indexOf('component-registry')===0){
              add(section.name||section.title||('Section '+(sectionIndex+1)), item);
            }
          });
        });
      }
    } catch(e){}

    // Secondary: currently selected item. Right-panel editing already relies on this path,
    // so include it even if the full state scan misses the item.
    try {
      var selected=aqSelectedRegistryItemForRightPanel();
      if(selected) add('Selected canvas item', selected);
    } catch(e){}

    // Fallback: DOM nodes added by imported HTML fallback.
    try {
      document.querySelectorAll('[data-aq-imported-contract="true"], .aq-imported-canvas-item').forEach(function(el){
        var tag=el.getAttribute('data-tag') || '';
        var html=el.innerHTML || '';
        if(!tag && html){
          var m=html.match(/<\s*([a-z][a-z0-9-]*)\b/i);
          tag=m && m[1] || '';
        }
        if(tag){
          add('Canvas DOM fallback', {
            id:el.id || ('dom-'+tag+'-'+items.length),
            title:labelForTag(tag),
            html:html,
            props:{},
            importSource:{
              kind:'component-registry-dom-fallback',
              tag:tag,
              label:labelForTag(tag),
              library:detectLibrary(tag),
              registry:contractExportShape(toContract(html || ('<'+tag+'></'+tag+'>')))
            }
          });
        }
      });
    } catch(e){}

    return items;
  }

  function aqRegistryAppliedProps(item, reg){
    var props=Object.assign({}, item && item.props ? item.props : {});
    if(reg && Array.isArray(reg.props)){
      reg.props.forEach(function(p){
        if(!p || !p.name) return;
        if(props[p.name] === undefined && p.defaultValue !== undefined) props[p.name]=p.defaultValue;
      });
    }
    return props;
  }

  function aqRegistryImportStatement(tag, library){
    tag=String(tag||'');
    library=String(library||'');
    if(/^sp-button$/.test(tag)) return "import '@spectrum-web-components/button/sp-button.js';";
    if(/^sp-textfield$/.test(tag)) return "import '@spectrum-web-components/textfield/sp-textfield.js';";
    if(/^sp-/.test(tag)) return "/* Load Spectrum Web Components module for "+tag+" */";
    if(/^sl-button$/.test(tag)) return "import 'https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.20.1/cdn/components/button/button.js';";
    if(/^sl-/.test(tag)) return "/* Load Shoelace theme + component module for "+tag+" */";
    return "/* Load/register custom element "+tag+" before rendering */";
  }

  function registryCanvasSummaryPayload(){
    var found=getRegistryCanvasItems();
    var items=found.map(function(entry, index){
      var item=entry.item || {};
      var src=item.importSource || {};
      var reg=src.registry || item.__componentRegistryContract || {};
      var tag=src.tag || reg.tag || '';
      var library=src.library || reg.sourceLibrary || '';
      var appliedProps=aqRegistryAppliedProps(item, reg);
      return {
        index:index+1,
        section:entry.section,
        componentType:'registry',
        title:item.title || src.title || src.label || reg.name || 'Registry component',
        tag:tag,
        sourceLibrary:library,
        importStatement:aqRegistryImportStatement(tag, library),
        appliedProps:appliedProps,
        defaultMarkup:item.html || reg.defaultMarkup || '',
        contract:{
          name:reg.name || src.label || item.title || '',
          runtime:reg.runtime || 'web-component',
          slots:reg.slots || [],
          events:reg.events || []
        },
        developerNote:'Placed from Component Registry. Load the source component library/module before rendering this tag in production.'
      };
    });
    return {
      exportType:'aq-current-composition-registry-summary',
      version:'1.1.0',
      generatedAt:new Date().toISOString(),
      count:items.length,
      libraries:items.reduce(function(acc,item){ var key=item.sourceLibrary||'Unknown'; acc[key]=(acc[key]||0)+1; return acc; }, {}),
      importStatements:items.map(function(item){ return item.importStatement; }).filter(function(v,i,a){ return v && a.indexOf(v)===i; }),
      items:items
    };
  }

  function downloadCurrentRegistrySummaryJson(){
    var payload=registryCanvasSummaryPayload();
    downloadText('aq-current-canvas-registry-summary.json', JSON.stringify(payload,null,2), 'application/json');
    status(payload.count ? ('Downloaded registry summary for '+payload.count+' canvas item(s).') : 'No registry components found on the canvas.');
  }

  function downloadCurrentRegistryHandoffNotes(){
    var payload=registryCanvasSummaryPayload();
    var lines=['# AQ Component Registry Handoff Notes','','Registry components on current canvas: '+payload.count,''];
    if(payload.importStatements && payload.importStatements.length){
      lines.push('## Required imports / registration');
      lines.push('');
      payload.importStatements.forEach(function(stmt){ lines.push('```js'); lines.push(stmt); lines.push('```'); });
      lines.push('');
    }
    if(!payload.count){
      lines.push('No registry components were found on the current canvas.');
    } else {
      payload.items.forEach(function(item){
        lines.push('## '+item.index+'. '+item.title);
        lines.push('');
        lines.push('- Section: '+item.section);
        lines.push('- Component type: '+item.componentType);
        lines.push('- Tag: `'+item.tag+'`');
        lines.push('- Source library: '+(item.sourceLibrary||'Unknown'));
        lines.push('- Import: `'+item.importStatement+'`');
        lines.push('- Applied props:');
        var props=item.appliedProps || {};
        var keys=Object.keys(props);
        if(keys.length){ keys.forEach(function(k){ lines.push('  - '+k+': `'+props[k]+'`'); }); }
        else { lines.push('  - none captured'); }
        if(item.defaultMarkup){
          lines.push('');
          lines.push('### Rendered/default markup');
          lines.push('```html');
          lines.push(item.defaultMarkup);
          lines.push('```');
        }
        lines.push('');
      });
    }
    downloadText('aq-current-canvas-registry-handoff.md', lines.join('\n'), 'text/markdown');
    status(payload.count ? ('Downloaded registry handoff notes for '+payload.count+' canvas item(s).') : 'No registry components found on the canvas.');
  }


  function validateRegistryHandoffPayload(){
    var payload=registryCanvasSummaryPayload();
    var issues=[];
    if(!payload.count){
      issues.push('No registry components found on canvas.');
    }
    (payload.items||[]).forEach(function(item){
      var label=item.title || item.tag || ('Item '+item.index);
      if(!item.tag) issues.push(label+': missing tag.');
      if(!item.sourceLibrary) issues.push(label+': missing source library.');
      if(!item.importStatement) issues.push(label+': missing import statement.');
      if(!item.defaultMarkup) issues.push(label+': missing default/rendered markup.');
    });
    return {payload:payload, issues:issues, ok:issues.length===0};
  }

  function showRegistryHandoffValidation(){
    var box=$('aqRegistryCanvasSummary');
    var result=validateRegistryHandoffPayload();
    if(!box) return;
    if(result.ok){
      box.innerHTML='<div class="aq-registry-validation-ok"><strong>Handoff check passed.</strong><div class="xsmall muted">'+result.payload.count+' registry component(s) ready for summary export.</div></div>';
    } else {
      box.innerHTML='<div class="aq-registry-validation-warn"><strong>Handoff check needs attention.</strong><ul>'+result.issues.map(function(i){return '<li>'+esc(i)+'</li>';}).join('')+'</ul></div>';
    }
    status(result.ok ? 'Registry handoff check passed.' : 'Registry handoff check found '+result.issues.length+' issue(s).');
  }

  function updateRegistryCanvasSummaryView(){
    var box=$('aqRegistryCanvasSummary');
    if(!box) return;
    var payload=registryCanvasSummaryPayload();
    if(!payload.count){
      box.innerHTML='<div class="xsmall muted">No registry components are currently on the canvas.</div>';
      return;
    }
    box.innerHTML='<div><strong>Current canvas registry items:</strong> '+payload.count+'</div>'+
      '<div class="xsmall muted">Export includes registry tag, library, import statement, and applied props.</div>'+
      '<ul>'+payload.items.map(function(item){ return '<li><code>'+esc(item.tag||'component')+'</code> · '+esc(item.title||'Registry component')+' · '+esc(item.sourceLibrary||'Library')+'</li>'; }).join('')+'</ul>';
  }

  function resetRegistryTestItems(){
    try {
      if(window.state && Array.isArray(window.state.sections)){
        var removed=0;
        window.state.sections.forEach(function(section){
          if(!section || !Array.isArray(section.items)) return;
          var before=section.items.length;
          section.items = section.items.filter(function(item){
            return !(item && item.importSource && String(item.importSource.kind||'').indexOf('component-registry')===0);
          });
          removed += before - section.items.length;
        });
        if(typeof window.render==='function') window.render();
        status(removed ? ('Removed '+removed+' registry test item(s) from canvas.') : 'No registry test items found on canvas.'); updateRegistryCanvasSummaryView();
        return;
      }
    } catch(e){}
    status('Reset could not access canvas items in this build. Use normal delete for selected registry items.');
  }

  ready(function(){
    var toggle=$('aqRegistryToggleBtn'); var panel=$('aqRegistryPanel');
    if(toggle && panel){ toggle.addEventListener('click', function(){
      panel.classList.toggle('hidden');
      var expanded=!panel.classList.contains('hidden');
      toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      var chev=toggle.querySelector('.template-chevron');
      if(chev) chev.textContent=expanded ? '▲' : '▼';
    }); }
    var importBtn=$('aqImportComponentBtn'); if(importBtn) importBtn.addEventListener('click', openImport);
    var downloadBtn=$('aqDownloadRegistryBtn'); if(downloadBtn) downloadBtn.addEventListener('click', downloadRegistryJson);
    var importJsonBtn=$('aqImportRegistryJsonBtn'); if(importJsonBtn) importJsonBtn.addEventListener('click', openImportRegistryJson);
    var clearBtn=$('aqClearSavedRegistryBtn'); if(clearBtn) clearBtn.addEventListener('click', clearSavedContracts);
    var panel=$('aqAdvancedRegistryHelperHost') || $('aqAdvancedToolsPanel') || $('aqRegistryPanel');
    if(panel && !$('aqResetRegistryTestBtn')){
      var helper=document.createElement('div');
      helper.className='aq-registry-selected-helper';
      helper.innerHTML='<div class="aq-registry-test-path"><strong>Registry workflow</strong><ol><li>Add Button or Text Field</li><li>Select it on the canvas</li><li>Edit it in the right Properties panel</li></ol></div>'+
        '<button class="btn" id="aqResetRegistryTestBtn" type="button">Reset Registry Test Items</button>'+
        '<details class="aq-registry-advanced aq-registry-summary-details"><summary>Current canvas handoff</summary>'+
        '<div id="aqRegistryCanvasSummary" class="aq-registry-canvas-summary"></div>'+
        '<div class="aq-registry-summary-actions"><button class="btn" id="aqRefreshRegistrySummaryBtn" type="button">Refresh Summary</button><button class="btn" id="aqValidateRegistryHandoffBtn" type="button">Validate Handoff</button><button class="btn" id="aqDownloadCurrentRegistrySummaryBtn" type="button">Download Summary JSON</button><button class="btn" id="aqDownloadCurrentRegistryNotesBtn" type="button">Download Handoff Notes</button></div></details>'+
        '<details class="aq-registry-advanced aq-registry-preset-details"><summary>Advanced presets</summary>'+
        '<div class="aq-contract-preset-row aq-contract-preset-row-always"><label>Contract preset<select id="aqQuickContractPresetSelect">'+presetOptions('')+'</select></label><button class="btn" id="aqQuickApplyContractPresetBtn" type="button">Apply Preset</button></div>'+
        '<div class="xsmall muted">Use this only when you want to inspect or start from a contract preset.</div></details>';
      panel.appendChild(helper);
    }
    var selectedContractBtn=$('aqShowSelectedRegistryContractBtn'); if(selectedContractBtn) selectedContractBtn.addEventListener('click', showSelectedCanvasRegistryContract);
    var resetTestBtn=$('aqResetRegistryTestBtn'); if(resetTestBtn) resetTestBtn.addEventListener('click', resetRegistryTestItems);
    var refreshSummaryBtn=$('aqRefreshRegistrySummaryBtn'); if(refreshSummaryBtn) refreshSummaryBtn.addEventListener('click', updateRegistryCanvasSummaryView);
    var validateHandoffBtn=$('aqValidateRegistryHandoffBtn'); if(validateHandoffBtn) validateHandoffBtn.addEventListener('click', showRegistryHandoffValidation);
    var summaryJsonBtn=$('aqDownloadCurrentRegistrySummaryBtn'); if(summaryJsonBtn) summaryJsonBtn.addEventListener('click', downloadCurrentRegistrySummaryJson);
    var summaryNotesBtn=$('aqDownloadCurrentRegistryNotesBtn'); if(summaryNotesBtn) summaryNotesBtn.addEventListener('click', downloadCurrentRegistryHandoffNotes);
    updateRegistryCanvasSummaryView();
    var quickPresetBtn=$('aqQuickApplyContractPresetBtn'); if(quickPresetBtn) quickPresetBtn.addEventListener('click', function(){
      var select=$('aqQuickContractPresetSelect');
      var tag=select && select.value;
      var preset=clonePreset(tag);
      if(!preset){ status('Choose a contract preset first.'); return; }
      showContract(Object.assign({tag:tag}, preset), -1);
      setTimeout(aqUpdateRightRegistryPanel,0); status('Applied preset: '+(preset.label||tag)+'. Review the editable contract panel, then save or download if needed.');
    });
    render();
    if(load().length){ aqRegistryCollapsedGroups['Imported Contracts']=false; openRegistryPanel(); render(); }
    aqInstallRightPanelSelectionHooks(); aqUpdateRightRegistryPanel(); status('More Components ready.');
    window.aqComponentRegistryRender=render;
    window.aqComponentRegistryExportPayload=registryExportPayload;
    window.aqComponentRegistryDownloadJson=downloadRegistryJson;
  });
})();
