/* Pattern Builder action wiring fallback: keeps the visible Pattern Builder controls functional even if internal app bindings change.
   2026-06-11 AP: Adds generated component library workflow: search, duplicate, export/import registry JSON, and single component download. */
(function(){
  var STORAGE_KEY = 'structuredUxPatternContracts.v1';
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>]/g, function(ch){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[ch]; }); }
  function escAttr(s){ return esc(s).replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
  function safeParse(v,f){ try { var x = JSON.parse(v); return x == null ? f : x; } catch(e){ return f; } }
  function getContracts(){ var list = safeParse(localStorage.getItem(STORAGE_KEY) || '[]', []); return Array.isArray(list) ? list : []; }
  function saveContracts(list){ localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.isArray(list) ? list : [], null, 2)); }
  var lastCapturedPatternId = localStorage.getItem(STORAGE_KEY + '.lastCapturedId') || '';
  function setLastCapturedPatternId(id){ lastCapturedPatternId = String(id || ''); try { localStorage.setItem(STORAGE_KEY + '.lastCapturedId', lastCapturedPatternId); } catch(e){} }
  function getLastCapturedContract(){ var contracts = getContracts(); return contracts.filter(function(item){ return item && item.id === lastCapturedPatternId; })[0] || contracts[0] || null; }
  function status(msg){ var el = document.getElementById('patternBuilderStatus'); if (el) el.textContent = msg || ''; }
  function uniquePatternId(contract){ var kind = contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag);
    var base = kind === 'spectrum-info-card' ? 'pattern-spectrum-info-card' : (kind === 'editor-hero' || kind === 'hero' || kind === 'hero-section' ? 'pattern-editor-hero' : 'pattern-spectrum-contact-section'); return base + '-' + Date.now() + '-' + Math.floor(Math.random() * 100000); }
  function nextPatternName(base, contracts){
    base = String(base || 'Spectrum Contact Section').trim() || 'Spectrum Contact Section';
    var names = contracts.map(function(item){ return String(item && item.name || ''); });
    if (names.indexOf(base) === -1) return base;
    var n = 2;
    while (names.indexOf(base + ' ' + n) !== -1) n += 1;
    return base + ' ' + n;
  }

  function slugifyWrapperTag(value, fallback){
    var raw = String(value || '').trim().toLowerCase();
    var safe = raw.replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    if (safe && safe.indexOf('-') !== -1 && /^[a-z][a-z0-9-]*-[a-z0-9-]*$/.test(safe)) return safe;
    return fallback || 'custom-pattern-component';
  }

  function titleToTag(title, fallback){
    var base = String(title || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (!base) return fallback || 'custom-pattern-component';
    if (base.indexOf('-') === -1) base += '-component';
    return slugifyWrapperTag(base, fallback || 'custom-pattern-component');
  }


  function splitCsv(value){
    return String(value || '').split(',').map(function(item){ return item.trim(); }).filter(Boolean);
  }

  function defaultContractPropsForBase(contract){
    var base = String(contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag) || '').trim();
    if (base === 'spectrum-contact-section') return ['eyebrow','heading','intro','nameLabel','emailLabel','messageLabel','buttonLabel'];
    if (base === 'spectrum-info-card') return ['eyebrow','heading','body','buttonLabel','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','mediaBehavior'];
    if (base === 'editor-hero' || base === 'hero' || base === 'hero-section') return ['heading','body','cta','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','overlayMode','overlayPosition'];
    return (contract && Array.isArray(contract.editableFields) && contract.editableFields.length) ? contract.editableFields.slice(0, 8) : ['heading','body','cta','imageSrc'];
  }

  function defaultSlotsForBase(contract){
    var base = String(contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag) || '').trim();
    if (base === 'spectrum-contact-section') return ['intro','form','actions'];
    if (base === 'spectrum-info-card') return ['media','content','actions'];
    if (base === 'editor-hero' || base === 'hero' || base === 'hero-section') return ['media','content','actions'];
    return ['content','actions'];
  }

  function contactContract(){
    return {
      id: 'pattern-spectrum-contact-section',
      name: 'Spectrum Contact Section',
      type: 'assembled-pattern-contract',
      sourceMode: 'assembled-from-linked-components',
      wrapperTag: 'spectrum-contact-section',
      patternComponent: 'spectrum-contact-section',
      sourceLibraries: [{ name: 'Adobe Spectrum Web Components', dependency: '@spectrum-web-components/bundle/elements.js' }],
      children: [
        { tag: 'sp-textfield', role: 'name field', editableProps: ['label','placeholder'] },
        { tag: 'sp-textfield', role: 'email field', editableProps: ['label','placeholder'] },
        { tag: 'sp-textfield', role: 'message field', editableProps: ['label','placeholder'] },
        { tag: 'sp-button', role: 'submit action', editableProps: ['variant','text'] }
      ],
      editableFields: ['eyebrow','heading','intro','nameLabel','emailLabel','messageLabel','buttonLabel','themeColor','themeScale'],
      layoutIntent: { desktop: 'two-column contact section', mobile: 'single-column stacked form', gap: 'system spacing' },
      responsiveIntent: 'Keep text and form side-by-side on wide screens; stack content before form on smaller screens.',
      accessibilityIntent: 'Each field requires a label; submit action remains keyboard reachable; section heading identifies the region.',
      savedAt: new Date().toISOString()
    };
  }

  function infoCardContract(){
    return {
      id: 'pattern-spectrum-info-card',
      name: 'Spectrum Info Card',
      type: 'assembled-pattern-contract',
      sourceMode: 'assembled-from-linked-components',
      wrapperTag: 'spectrum-info-card',
      patternComponent: 'spectrum-info-card',
      sourceLibraries: [{ name: 'Adobe Spectrum Web Components', dependency: '@spectrum-web-components/bundle/elements.js' }],
      children: [
        { tag: 'sp-theme', role: 'theme wrapper' },
        { tag: 'sp-button', role: 'card action', editableProps: ['variant','text'] }
      ],
      editableFields: ['eyebrow','heading','body','buttonLabel','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','mediaBehavior','themeColor','themeScale'],
      layoutIntent: { desktop: 'single-column information card with optional media', mobile: 'single-column information card', gap: 'system spacing' },
      responsiveIntent: 'Keep authored text and action grouped as a reusable content card.',
      accessibilityIntent: 'Card heading identifies the content; action remains keyboard reachable.',
      savedAt: new Date().toISOString()
    };
  }


  function normalizePropDefinitions(contract){
    var current = (contract && contract.contract && Array.isArray(contract.contract.exposedProps)) ? contract.contract.exposedProps : defaultContractPropsForBase(contract);
    var existing = (contract && contract.contract && Array.isArray(contract.contract.propDefinitions)) ? contract.contract.propDefinitions : [];
    return current.map(function(name){
      var found = existing.filter(function(item){ return item && item.name === name; })[0] || {};
      return {
        name: String(found.name || name || '').trim(),
        type: String(found.type || 'string').trim(),
        defaultValue: String(found.defaultValue == null ? '' : found.defaultValue).trim()
      };
    }).filter(function(item){ return item.name; });
  }

  function normalizeSlotDefinitions(contract){
    var current = (contract && contract.contract && Array.isArray(contract.contract.slots)) ? contract.contract.slots : defaultSlotsForBase(contract);
    var existing = (contract && contract.contract && Array.isArray(contract.contract.slotDefinitions)) ? contract.contract.slotDefinitions : [];
    return current.map(function(name){
      var found = existing.filter(function(item){ return item && item.name === name; })[0] || {};
      return {
        name: String(found.name || name || '').trim(),
        description: String(found.description == null ? '' : found.description).trim()
      };
    }).filter(function(item){ return item.name; });
  }

  function renderEditableContractDetails(c){
    if (!c) return '';
    // AG fix: always show an editable Contract Editor. Earlier builds only
    // rendered this area when c.contract already existed, which made captured
    // patterns look like there was no way to view or edit contract details.
    c.contract = c.contract || {
      componentName: c.wrapperName || c.name || (c.props && c.props.heading) || 'Pattern Component',
      tagName: c.wrapperTag || c.patternComponent || titleToTag(c.name || (c.props && c.props.heading) || 'pattern-component', 'custom-pattern-component'),
      description: c.description || '',
      exposedProps: defaultContractPropsForBase(c),
      slots: defaultSlotsForBase(c),
      events: []
    };
    var propDefs = normalizePropDefinitions(c);
    var slotDefs = normalizeSlotDefinitions(c);
    function propRow(item, i){
      return '<div class="row" style="grid-template-columns:1.15fr .8fr 1fr;gap:6px;margin-top:6px;">' +
        '<input aria-label="Property name" data-contract-prop-name value="' + escAttr(item.name || '') + '" placeholder="prop name">' +
        '<select aria-label="Property type" data-contract-prop-type>' +
          ['string','number','boolean','url','enum','object'].map(function(type){ return '<option value="' + escAttr(type) + '"' + (item.type === type ? ' selected' : '') + '>' + esc(type) + '</option>'; }).join('') +
        '</select>' +
        '<input aria-label="Property default" data-contract-prop-default value="' + escAttr(item.defaultValue || '') + '" placeholder="default">' +
      '</div>';
    }
    function slotRow(item, i){
      return '<div class="row" style="grid-template-columns:1fr 1.35fr;gap:6px;margin-top:6px;">' +
        '<input aria-label="Slot name" data-contract-slot-name value="' + escAttr(item.name || '') + '" placeholder="slot name">' +
        '<input aria-label="Slot description" data-contract-slot-description value="' + escAttr(item.description || '') + '" placeholder="description">' +
      '</div>';
    }
    return '<div class="group" data-contract-editor-panel style="margin-top:10px;padding:10px;border:2px solid var(--brand-soft);">' +
      '<div style="font-weight:900;margin-bottom:6px;">Editable Contract Details</div>' +
      '<div class="xsmall muted" style="margin-bottom:8px;">These fields describe the wrapper component that developers receive in export and handoff.</div>' +
      '<label style="margin-top:8px;">Component name</label>' +
      '<input data-contract-component-name value="' + escAttr(c.contract.componentName || c.wrapperName || c.name || '') + '" placeholder="Promo Card">' +
      '<label style="margin-top:8px;">Tag name</label>' +
      '<input data-contract-tag-name value="' + escAttr(c.contract.tagName || c.wrapperTag || '') + '" placeholder="promo-card-section">' +
      '<label style="margin-top:8px;">Description</label>' +
      '<textarea data-contract-description placeholder="Short developer-facing description" style="min-height:56px;">' + esc(c.contract.description || c.description || '') + '</textarea>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Properties</div>' +
      '<div class="xsmall muted">Name, type, and optional default value. Blank property names are ignored.</div>' +
      '<div data-contract-prop-list>' + (propDefs.length ? propDefs.map(propRow).join('') : propRow({name:'heading',type:'string',defaultValue:''},0)) + '</div>' +
      '<button class="btn" type="button" style="margin-top:8px;" data-contract-add-prop>Add Prop</button>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Slots</div>' +
      '<div class="xsmall muted">Slots describe replaceable regions such as media, content, or actions.</div>' +
      '<div data-contract-slot-list>' + (slotDefs.length ? slotDefs.map(slotRow).join('') : slotRow({name:'content',description:''},0)) + '</div>' +
      '<button class="btn" type="button" style="margin-top:8px;" data-contract-add-slot>Add Slot</button>' +
      '<button class="btn primary" type="button" style="margin-top:8px;" data-pattern-builder-save-contract-details="' + escAttr(c.id || '') + '">Save Contract Details</button>' +
    '</div>';
  }

  function collectRows(root, rowSelector, fieldSelectors){
    var rows = Array.from(root.querySelectorAll(rowSelector));
    return rows.map(function(row){
      var out = {};
      Object.keys(fieldSelectors).forEach(function(key){
        var el = row.querySelector(fieldSelectors[key]);
        out[key] = el ? String(el.value || '').trim() : '';
      });
      return out;
    });
  }

  function saveContractDetails(id, cardEl){
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    if (index < 0) { status('Pattern contract not found.'); return false; }
    var c = contracts[index];
    c.contract = c.contract || {};
    var componentName = cardEl.querySelector('[data-contract-component-name]')?.value || c.name || 'Pattern Component';
    var tagName = cardEl.querySelector('[data-contract-tag-name]')?.value || c.wrapperTag || c.patternComponent || 'custom-pattern-component';
    var description = cardEl.querySelector('[data-contract-description]')?.value || '';
    tagName = slugifyWrapperTag(tagName, titleToTag(componentName, c.wrapperTag || 'custom-pattern-component'));
    var propRows = collectRows(cardEl, '[data-contract-prop-list] .row', {
      name: '[data-contract-prop-name]',
      type: '[data-contract-prop-type]',
      defaultValue: '[data-contract-prop-default]'
    }).filter(function(item){ return item.name; });
    var slotRows = collectRows(cardEl, '[data-contract-slot-list] .row', {
      name: '[data-contract-slot-name]',
      description: '[data-contract-slot-description]'
    }).filter(function(item){ return item.name; });
    c.name = String(componentName || '').trim() || c.name || 'Pattern Component';
    c.wrapperName = c.name;
    c.wrapperTag = tagName;
    c.description = String(description || '').trim();
    c.generatedWrapperContract = true;
    c.updatedAt = new Date().toISOString();
    c.contract.componentName = c.name;
    c.contract.tagName = tagName;
    c.contract.description = c.description;
    c.contract.exposedProps = propRows.map(function(item){ return item.name; });
    c.contract.propDefinitions = propRows;
    c.contract.slots = slotRows.map(function(item){ return item.name; });
    c.contract.slotDefinitions = slotRows;
    c.contract.events = c.contract.events || [];
    c.props = c.props || {};
    c.props.__wrapperTag = tagName;
    c.props.__wrapperName = c.name;
    c.props.__wrapperDescription = c.description;
    c.props.__contractProps = c.contract.exposedProps.join(',');
    c.props.__contractSlots = c.contract.slots.join(',');
    c.props.__contractDescription = c.description;
    contracts[index] = c;
    saveContracts(contracts);
    try { if (window.patternBuilderApplyContractToSelectedDirect) window.patternBuilderApplyContractToSelectedDirect(c); } catch (err) { console.warn('Apply saved contract details to selected item failed:', err); }
    render();
    try { populateStandaloneContractEditor(c.id); } catch (err) {}
    status('Saved editable contract details for <' + tagName + '>. Export metadata applied to the selected canvas item.');
    return true;
  }

  function addEditablePropRow(cardEl){
    var list = cardEl && cardEl.querySelector('[data-contract-prop-list]');
    if (!list) return;
    var wrap = document.createElement('div');
    wrap.className = 'row';
    wrap.style.cssText = 'grid-template-columns:1.15fr .8fr 1fr;gap:6px;margin-top:6px;';
    wrap.innerHTML = '<input aria-label="Property name" data-contract-prop-name placeholder="prop name"><select aria-label="Property type" data-contract-prop-type><option>string</option><option>number</option><option>boolean</option><option>url</option><option>enum</option><option>object</option></select><input aria-label="Property default" data-contract-prop-default placeholder="default">';
    list.appendChild(wrap);
  }

  function addEditableSlotRow(cardEl){
    var list = cardEl && cardEl.querySelector('[data-contract-slot-list]');
    if (!list) return;
    var wrap = document.createElement('div');
    wrap.className = 'row';
    wrap.style.cssText = 'grid-template-columns:1fr 1.35fr;gap:6px;margin-top:6px;';
    wrap.innerHTML = '<input aria-label="Slot name" data-contract-slot-name placeholder="slot name"><input aria-label="Slot description" data-contract-slot-description placeholder="description">';
    list.appendChild(wrap);
  }



  function normalizeInspectorList(value){
    if (!value) return [];
    if (Array.isArray(value)) return value.map(function(item){
      if (item && typeof item === 'object') return item.name || item.slot || item.label || JSON.stringify(item);
      return String(item || '');
    }).filter(Boolean);
    return String(value || '').split(',').map(function(item){ return item.trim(); }).filter(Boolean);
  }

  function renderGeneratedComponentInspector(contract){
    if (!contract) {
      return '<div class="group" data-generated-component-inspector style="margin:10px 0 12px;padding:10px;border:1px solid var(--border);background:var(--panel);">' +
        '<div style="font-weight:900;margin-bottom:4px;">Component Inspector</div>' +
        '<div class="xsmall muted">Click Inspect on a generated component to review its contract details.</div>' +
      '</div>';
    }
    var tag = (contract.contract && contract.contract.tagName) || contract.wrapperTag || contract.patternComponent || 'generated-component';
    var name = (contract.contract && contract.contract.componentName) || contract.wrapperName || contract.name || tag;
    var desc = (contract.contract && contract.contract.description) || contract.description || 'No description provided.';
    var props = normalizeInspectorList((contract.contract && (contract.contract.propDefinitions || contract.contract.exposedProps)) || contract.props?.__contractProps);
    var slots = normalizeInspectorList((contract.contract && (contract.contract.slotDefinitions || contract.contract.slots)) || contract.props?.__contractSlots);
    var children = Array.isArray(contract.children) ? contract.children.map(function(child){ return child.name || child.label || child.role || child.tag || 'Component'; }).filter(Boolean) : [];
    var saved = contract.savedAt ? new Date(contract.savedAt).toLocaleString() : 'Not recorded';
    var updated = contract.updatedAt ? new Date(contract.updatedAt).toLocaleString() : '';
    return '<div class="group" data-generated-component-inspector data-inspecting-generated-component="' + escAttr(contract.id || '') + '" style="margin:10px 0 12px;padding:10px;border:2px solid var(--brand);background:var(--panel);">' +
      '<div style="font-weight:900;margin-bottom:4px;">Component Inspector</div>' +
      '<div class="xsmall muted"><strong>Name:</strong> ' + esc(name) + '</div>' +
      '<div class="xsmall muted"><strong>Tag:</strong> <code>&lt;' + esc(tag) + '&gt;</code></div>' +
      '<div class="xsmall muted"><strong>Description:</strong> ' + esc(desc) + '</div>' +
      '<div class="xsmall muted"><strong>Props:</strong> ' + esc(props.length ? props.join(', ') : 'None listed') + '</div>' +
      '<div class="xsmall muted"><strong>Slots:</strong> ' + esc(slots.length ? slots.join(', ') : 'None listed') + '</div>' +
      (children.length ? '<div class="xsmall muted"><strong>Captured children:</strong> ' + esc(children.join(', ')) + '</div>' : '') +
      '<div class="xsmall muted"><strong>Saved:</strong> ' + esc(saved) + (updated ? ' · <strong>Updated:</strong> ' + esc(updated) : '') + '</div>' +
      '<div class="row" style="margin-top:8px;grid-template-columns:1fr 1fr;gap:6px;">' +
        '<button class="btn" type="button" data-generated-component-edit="' + escAttr(contract.id || '') + '">Edit Contract</button>' +
        '<button class="btn primary" type="button" data-generated-component-tray-add="' + escAttr(contract.id || '') + '">Add to Canvas</button>' +
      '</div>' +
    '</div>';
  }

  function getInspectedGeneratedComponentId(){
    return window.__patternBuilderInspectedGeneratedComponentId || '';
  }

  function setInspectedGeneratedComponentId(id){
    window.__patternBuilderInspectedGeneratedComponentId = id || '';
  }



  function getGeneratedComponentDisplayName(c){
    return (c && c.contract && c.contract.componentName) || c.wrapperName || c.name || (c && c.wrapperTag) || 'Generated Component';
  }

  function getGeneratedComponentTag(c){
    return (c && c.contract && c.contract.tagName) || c.wrapperTag || c.patternComponent || 'generated-component';
  }

  function getGeneratedComponentDescription(c){
    return (c && c.contract && c.contract.description) || c.description || '';
  }

  function normalizeGeneratedComponentForExport(c){
    var propDefs = (c && c.contract && Array.isArray(c.contract.propDefinitions)) ? c.contract.propDefinitions : normalizePropDefinitions(c || {});
    var slotDefs = (c && c.contract && Array.isArray(c.contract.slotDefinitions)) ? c.contract.slotDefinitions : normalizeSlotDefinitions(c || {});
    return {
      id: c && c.id || '',
      componentName: getGeneratedComponentDisplayName(c),
      tagName: getGeneratedComponentTag(c),
      description: getGeneratedComponentDescription(c),
      type: c && c.type || 'generated-wrapper-contract',
      sourcePatternName: c && c.name || '',
      wrapperTag: c && c.wrapperTag || getGeneratedComponentTag(c),
      patternComponent: c && c.patternComponent || '',
      generatedWrapperContract: !!(c && c.generatedWrapperContract),
      props: propDefs,
      propNames: propDefs.map(function(item){ return item.name; }).filter(Boolean),
      slots: slotDefs,
      slotNames: slotDefs.map(function(item){ return item.name; }).filter(Boolean),
      children: Array.isArray(c && c.children) ? c.children : [],
      sourceLibraries: Array.isArray(c && c.sourceLibraries) ? c.sourceLibraries : [],
      layoutIntent: c && c.layoutIntent || null,
      responsiveIntent: c && c.responsiveIntent || '',
      accessibilityIntent: c && c.accessibilityIntent || '',
      savedAt: c && c.savedAt || '',
      updatedAt: c && c.updatedAt || ''
    };
  }

  function generatedComponentRegistryPayload(){
    var generated = getGeneratedContracts().map(normalizeGeneratedComponentForExport);
    return {
      schema: 'structured-ux.generated-component-registry.v1',
      exportedAt: new Date().toISOString(),
      count: generated.length,
      components: generated
    };
  }

  function downloadTextFile(filename, text, mime){
    var blob = new Blob([text], { type: mime || 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 500);
  }

  window.patternBuilderExportGeneratedRegistry = function(){
    var payload = generatedComponentRegistryPayload();
    downloadTextFile('generated-component-registry.json', JSON.stringify(payload, null, 2), 'application/json');
    status('Downloaded generated-component-registry.json with ' + payload.count + ' generated component(s).');
  };

  window.patternBuilderDownloadGeneratedComponent = function(id){
    var c = getContracts().filter(function(item){ return item && item.id === id; })[0] || null;
    if (!c) { status('Generated component not found.'); return false; }
    var payload = {
      schema: 'structured-ux.generated-component.v1',
      exportedAt: new Date().toISOString(),
      component: normalizeGeneratedComponentForExport(c),
      sourceContract: c
    };
    var tag = getGeneratedComponentTag(c).replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'generated-component';
    downloadTextFile(tag + '.component-contract.json', JSON.stringify(payload, null, 2), 'application/json');
    status('Downloaded contract JSON for <' + getGeneratedComponentTag(c) + '>.');
    return true;
  };

  window.patternBuilderDuplicateGeneratedComponent = function(id){
    var contracts = getContracts();
    var source = contracts.filter(function(item){ return item && item.id === id; })[0] || null;
    if (!source) { status('Generated component not found.'); return false; }
    var copy = JSON.parse(JSON.stringify(source));
    copy.id = uniquePatternId(copy);
    var baseName = getGeneratedComponentDisplayName(source) + ' Copy';
    copy.name = nextPatternName(baseName, contracts);
    copy.wrapperName = copy.name;
    copy.generatedWrapperContract = true;
    copy.savedAt = new Date().toISOString();
    copy.updatedAt = copy.savedAt;
    var baseTag = getGeneratedComponentTag(source).replace(/-copy(?:-\d+)?$/,'') + '-copy';
    var existingTags = contracts.map(function(item){ return getGeneratedComponentTag(item); });
    var tag = slugifyWrapperTag(baseTag, 'custom-pattern-copy');
    var n = 2;
    while (existingTags.indexOf(tag) !== -1) { tag = slugifyWrapperTag(baseTag + '-' + n, 'custom-pattern-copy'); n += 1; }
    copy.wrapperTag = tag;
    copy.patternComponent = tag;
    copy.contract = copy.contract || {};
    copy.contract.componentName = copy.name;
    copy.contract.tagName = tag;
    copy.props = copy.props || {};
    copy.props.__wrapperTag = tag;
    copy.props.__wrapperName = copy.name;
    contracts.unshift(copy);
    saveContracts(contracts);
    setLastCapturedPatternId(copy.id);
    setInspectedGeneratedComponentId(copy.id);
    render();
    populateStandaloneContractEditor(copy.id);
    status('Duplicated generated component as <' + tag + '>.');
    return true;
  };

  window.patternBuilderImportGeneratedRegistryFile = function(file){
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(){
      try {
        var payload = JSON.parse(String(reader.result || '{}'));
        var incoming = [];
        if (Array.isArray(payload.components)) incoming = payload.components;
        else if (payload.component) incoming = [payload.component];
        else if (Array.isArray(payload.contracts)) incoming = payload.contracts;
        if (!incoming.length) { status('No components found in registry JSON.'); return; }
        var contracts = getContracts();
        var imported = 0;
        incoming.forEach(function(comp){
          var tag = slugifyWrapperTag(comp.tagName || comp.wrapperTag || comp.tag || comp.name, 'imported-generated-component');
          var name = comp.componentName || comp.name || tag;
          var exists = contracts.some(function(item){ return getGeneratedComponentTag(item) === tag; });
          var finalTag = tag;
          var suffix = 2;
          while (exists) {
            finalTag = slugifyWrapperTag(tag + '-' + suffix, tag + '-' + suffix);
            exists = contracts.some(function(item){ return getGeneratedComponentTag(item) === finalTag; });
            suffix += 1;
          }
          var propDefs = Array.isArray(comp.props) ? comp.props : (Array.isArray(comp.propDefinitions) ? comp.propDefinitions : []);
          var slotDefs = Array.isArray(comp.slots) ? comp.slots : (Array.isArray(comp.slotDefinitions) ? comp.slotDefinitions : []);
          propDefs = propDefs.map(function(item){ return typeof item === 'string' ? { name:item, type:'string', defaultValue:'' } : item; }).filter(function(item){ return item && item.name; });
          slotDefs = slotDefs.map(function(item){ return typeof item === 'string' ? { name:item, description:'' } : item; }).filter(function(item){ return item && item.name; });
          var contract = {
            id: 'imported-generated-' + Date.now() + '-' + Math.floor(Math.random()*100000),
            name: nextPatternName(name, contracts),
            type: 'generated-wrapper-contract',
            sourceMode: 'imported-generated-registry',
            generatedWrapperContract: true,
            wrapperName: name,
            wrapperTag: finalTag,
            patternComponent: finalTag,
            description: comp.description || '',
            contract: {
              componentName: name,
              tagName: finalTag,
              description: comp.description || '',
              exposedProps: propDefs.map(function(item){ return item.name; }),
              propDefinitions: propDefs,
              slots: slotDefs.map(function(item){ return item.name; }),
              slotDefinitions: slotDefs,
              events: []
            },
            children: Array.isArray(comp.children) ? comp.children : [],
            editableFields: propDefs.map(function(item){ return item.name; }),
            props: {
              __wrapperTag: finalTag,
              __wrapperName: name,
              __wrapperDescription: comp.description || '',
              __contractProps: propDefs.map(function(item){ return item.name; }).join(','),
              __contractSlots: slotDefs.map(function(item){ return item.name; }).join(','),
              __contractDescription: comp.description || ''
            },
            savedAt: new Date().toISOString()
          };
          contracts.unshift(contract);
          imported += 1;
        });
        saveContracts(contracts);
        render();
        populateStandaloneContractEditor();
        status('Imported ' + imported + ' generated component contract(s).');
      } catch (err) {
        console.warn('Generated component registry import failed', err);
        status('Could not import registry JSON. Check that it is a valid generated-component registry file.');
      }
    };
    reader.readAsText(file);
  };

  function renderGeneratedComponentRegistry(contracts){
    var generated = (contracts || []).filter(function(c){
      return c && (c.generatedWrapperContract || c.wrapperTag || (c.contract && c.contract.tagName));
    });
    if (!generated.length) {
      return '<div class="group" data-generated-component-registry style="margin:0 0 12px;padding:10px;border:1px solid var(--border);background:var(--soft);">' +
        '<div style="font-weight:900;margin-bottom:4px;">Generated Components</div>' +
        '<div class="xsmall muted">No generated wrapper components yet. Capture a pattern, then generate a wrapper contract.</div>' +
      '</div>';
    }
    var filter = String(window.__generatedComponentRegistryFilter || '').toLowerCase().trim();
    var filtered = generated.filter(function(c){
      if (!filter) return true;
      var haystack = [getGeneratedComponentDisplayName(c), getGeneratedComponentTag(c), getGeneratedComponentDescription(c), ((c.contract && Array.isArray(c.contract.exposedProps)) ? c.contract.exposedProps.join(' ') : ''), ((c.contract && Array.isArray(c.contract.slots)) ? c.contract.slots.join(' ') : '')].join(' ').toLowerCase();
      return haystack.indexOf(filter) !== -1;
    });
    var rows = filtered.map(function(c){
      var tag = getGeneratedComponentTag(c);
      var name = getGeneratedComponentDisplayName(c);
      var desc = getGeneratedComponentDescription(c);
      var props = (c.contract && Array.isArray(c.contract.exposedProps)) ? c.contract.exposedProps : [];
      var slots = (c.contract && Array.isArray(c.contract.slots)) ? c.contract.slots : [];
      return '<div data-generated-component-row="' + escAttr(c.id || '') + '" style="border:1px solid var(--border);border-radius:10px;padding:8px;margin-top:8px;background:var(--panel);">' +
        '<div style="font-weight:900;">' + esc(name) + '</div>' +
        '<div class="xsmall muted"><strong>Tag:</strong> <code>&lt;' + esc(tag) + '&gt;</code></div>' +
        (desc ? '<div class="xsmall muted"><strong>Description:</strong> ' + esc(desc) + '</div>' : '') +
        (props.length ? '<div class="xsmall muted"><strong>Props:</strong> ' + esc(props.join(', ')) + '</div>' : '') +
        (slots.length ? '<div class="xsmall muted"><strong>Slots:</strong> ' + esc(slots.join(', ')) + '</div>' : '') +
        '<div class="row" style="margin-top:8px;grid-template-columns:1fr 1fr 1fr;gap:6px;">' +
          '<button class="btn" type="button" data-generated-component-inspect="' + escAttr(c.id || '') + '">Inspect</button>' +
          '<button class="btn" type="button" data-generated-component-edit="' + escAttr(c.id || '') + '">Edit</button>' +
          '<button class="btn primary" type="button" data-generated-component-tray-add="' + escAttr(c.id || '') + '">Add</button>' +
        '</div>' +
        '<div class="row" style="margin-top:6px;grid-template-columns:1fr 1fr 1fr;gap:6px;">' +
          '<button class="btn" type="button" data-generated-component-duplicate="' + escAttr(c.id || '') + '">Duplicate</button>' +
          '<button class="btn" type="button" data-generated-component-download="' + escAttr(c.id || '') + '">JSON</button>' +
          '<button class="btn danger" type="button" data-generated-component-delete="' + escAttr(c.id || '') + '">Delete</button>' +
        '</div>' +
      '</div>';
    }).join('');
    var inspectedId = getInspectedGeneratedComponentId();
    var inspected = generated.filter(function(item){ return item && item.id === inspectedId; })[0] || null;
    return '<div class="group" data-generated-component-registry style="margin:0 0 12px;padding:10px;border:2px solid var(--brand-soft);background:var(--soft);">' +
      '<div style="font-weight:900;margin-bottom:4px;">Generated Components</div>' +
      '<div class="xsmall muted">' + generated.length + ' generated component(s)' + (filter ? ' · ' + filtered.length + ' shown' : '') + '. Use these as reusable frozen components, or export/import the registry for developer handoff.</div>' +
      '<div class="row" style="grid-template-columns:1fr 1fr;gap:6px;margin-top:8px;">' +
        '<input type="search" data-generated-component-filter value="' + escAttr(window.__generatedComponentRegistryFilter || '') + '" placeholder="Search generated components" aria-label="Search generated components">' +
        '<button class="btn primary" type="button" data-generated-registry-export>Export Registry JSON</button>' +
      '</div>' +
      '<div class="row" style="grid-template-columns:1fr 1fr;gap:6px;margin-top:6px;">' +
        '<button class="btn" type="button" data-generated-registry-import>Import Registry JSON</button>' +
        '<button class="btn" type="button" data-generated-registry-clear-filter>Clear Search</button>' +
      '</div>' +
      '<input type="file" accept="application/json,.json" data-generated-registry-import-file hidden>' +
      renderGeneratedComponentInspector(inspected) +
      (rows || '<div class="xsmall muted" style="margin-top:8px;">No generated components match the current search.</div>') +
    '</div>';
  }



  function getGeneratedContracts(){
    return getContracts().filter(function(c){
      return c && (c.generatedWrapperContract || c.wrapperTag || (c.contract && c.contract.tagName));
    });
  }

  function renderGeneratedComponentsTray(){
    var panel = document.getElementById('componentsPanel');
    if (!panel) return;
    var existing = document.getElementById('generatedComponentsTrayGroup');
    var generated = getGeneratedContracts();
    if (!generated.length) {
      if (existing) existing.remove();
      return;
    }
    if (!existing) {
      existing = document.createElement('div');
      existing.id = 'generatedComponentsTrayGroup';
      existing.className = 'group';
      existing.style.marginTop = '12px';
      existing.style.border = '1px solid var(--border)';
      existing.style.background = 'var(--soft)';
      panel.appendChild(existing);
    }
    var buttons = generated.map(function(c){
      var tag = (c.contract && c.contract.tagName) || c.wrapperTag || c.patternComponent || 'generated-component';
      var label = (c.contract && c.contract.componentName) || c.wrapperName || c.name || tag;
      var desc = (c.contract && c.contract.description) || c.description || 'Generated wrapper component';
      return '<button class="palette-item" type="button" draggable="true" data-generated-component-tray-add="' + escAttr(c.id || '') + '" title="Add generated component to canvas">' +
        '<span class="palette-icon">⬢</span>' + esc(label) +
        '<span class="xsmall muted" style="display:block;margin-top:4px;">&lt;' + esc(tag) + '&gt;</span>' +
        (desc ? '<span class="xsmall muted" style="display:block;margin-top:2px;">' + esc(desc) + '</span>' : '') +
      '</button>';
    }).join('');
    existing.innerHTML = '<h4 style="margin:0 0 6px;">Generated Components</h4>' +
      '<div class="hint" style="margin-bottom:8px;">Click or drag these generated wrapper components onto the canvas.</div>' + buttons;
  }

  function bindGeneratedComponentsTray(){
    if (window.__generatedComponentsTrayBound) return;
    window.__generatedComponentsTrayBound = true;
    document.addEventListener('click', function(e){
      var btn = e.target && e.target.closest ? e.target.closest('[data-generated-component-tray-add]') : null;
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      var id = btn.getAttribute('data-generated-component-tray-add') || '';
      if (id && window.patternBuilderAddSavedToCanvas) {
        window.patternBuilderAddSavedToCanvas(id);
        status('Added generated component to canvas.');
      }
    }, true);
    document.addEventListener('dragstart', function(e){
      var btn = e.target && e.target.closest ? e.target.closest('[data-generated-component-tray-add]') : null;
      if (!btn) return;
      var id = btn.getAttribute('data-generated-component-tray-add') || '';
      if (!id) return;
      try {
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('text/plain', 'generated-contract:' + id);
        e.dataTransfer.setData('application/x-generated-component-contract', id);
        window.__draggingGeneratedComponentContractId = id;
      } catch(err) {}
    }, true);
    document.addEventListener('dragend', function(){ window.__draggingGeneratedComponentContractId = null; }, true);
    document.addEventListener('dragover', function(e){
      var canvas = document.getElementById('canvas');
      if (!canvas || !canvas.contains(e.target)) return;
      var id = window.__draggingGeneratedComponentContractId || '';
      try {
        var payload = e.dataTransfer ? (e.dataTransfer.getData('text/plain') || '') : '';
        if (!id && payload.indexOf('generated-contract:') === 0) id = payload.slice('generated-contract:'.length);
      } catch(err) {}
      if (!id) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    }, true);
    document.addEventListener('drop', function(e){
      var canvas = document.getElementById('canvas');
      if (!canvas || !canvas.contains(e.target)) return;
      var id = window.__draggingGeneratedComponentContractId || '';
      try {
        var payload = e.dataTransfer ? (e.dataTransfer.getData('text/plain') || '') : '';
        if (!id && payload.indexOf('generated-contract:') === 0) id = payload.slice('generated-contract:'.length);
      } catch(err) {}
      if (!id) return;
      e.preventDefault();
      e.stopPropagation();
      window.__draggingGeneratedComponentContractId = null;
      if (window.patternBuilderAddSavedToCanvas) {
        window.patternBuilderAddSavedToCanvas(id);
        status('Dropped generated component onto canvas.');
      }
    }, true);
  }

  function render(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl) return;
    var contracts = getContracts();
    if (!contracts.length) { listEl.innerHTML = '<div class="muted">No saved pattern contracts yet.</div>'; return; }
    function childDisplayName(child, index, contract){
      var props = contract && contract.props ? contract.props : {};
      if (child && child.name) return child.name;
      if (child && child.label) return child.label;
      if (child && child.role) {
        if (child.role === 'name field') return props.nameLabel || 'Name field';
        if (child.role === 'email field') return props.emailLabel || 'Email field';
        if (child.role === 'message field') return props.messageLabel || 'Message field';
        if (child.role === 'submit action') return props.buttonLabel || 'Submit button';
        return child.role;
      }
      if (props) {
        if (index === 0 && props.nameLabel) return props.nameLabel;
        if (index === 1 && props.emailLabel) return props.emailLabel;
        if (index === 2 && props.messageLabel) return props.messageLabel;
        if (index === 3 && props.buttonLabel) return props.buttonLabel;
      }
      return child && child.tag ? child.tag : 'Component';
    }

    function inferChildren(contract){
      if (contract && Array.isArray(contract.children) && contract.children.length) return contract.children;
      var props = contract && contract.props ? contract.props : {};
      if ((contract && (contract.wrapperTag || contract.patternComponent)) === 'spectrum-info-card') {
        return [
          { tag: 'sp-theme', role: 'theme wrapper', name: 'Spectrum theme' },
          ...(props.imageSrc ? [{ tag: 'img', role: 'card media', name: props.imageAlt || 'Card image' }] : []),
          { tag: 'sp-button', role: 'card action', name: props.buttonLabel || 'Card action' }
        ];
      }
      var baseKind = contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag);
      if (baseKind === 'editor-hero' || baseKind === 'hero' || baseKind === 'hero-section') {
        return [
          ...(props.imageSrc ? [{ tag: 'img', role: 'hero media', name: props.imageAlt || 'Hero image' }] : []),
          { tag: 'editor-hero', role: 'hero content', name: props.heading || 'Hero content' }
        ];
      }
      return [
        { tag: 'sp-textfield', role: 'name field', name: props.nameLabel || 'Name field' },
        { tag: 'sp-textfield', role: 'email field', name: props.emailLabel || 'Email field' },
        { tag: 'sp-textfield', role: 'message field', name: props.messageLabel || 'Message field' },
        { tag: 'sp-button', role: 'submit action', name: props.buttonLabel || 'Submit button' }
      ];
    }

    var generatedRegistryHtml = renderGeneratedComponentRegistry(contracts);
    var savedPatternCardsHtml = contracts.map(function(c, index){
      var childList = inferChildren(c);
      var children = childList.map(function(child, childIndex){ return childDisplayName(child, childIndex, c); }).join(', ');
      var saved = c.savedAt ? new Date(c.savedAt).toLocaleString() : '';
      var wrapperTag = c.wrapperTag || c.patternComponent || 'spectrum-contact-section';
      return '<div class="pattern-builder-contract-card" data-pattern-contract-card="' + escAttr(c.id || '') + '" style="border:1px solid var(--border);border-radius:12px;padding:10px;margin:8px 0;background:var(--panel);">' +
        '<strong>' + esc(c.name || c.props?.heading || 'Pattern contract') + '</strong>' +
        '<div class="xsmall muted">' + esc(c.type || 'pattern') + '</div>' +
        '<div class="xsmall muted"><strong>Exports as:</strong> <code>&lt;' + esc(wrapperTag) + '&gt;</code></div>' +
        ((c.contract && c.contract.description) ? '<div class="xsmall muted"><strong>Description:</strong> ' + esc(c.contract.description) + '</div>' : '') +
        ((c.contract && Array.isArray(c.contract.exposedProps) && c.contract.exposedProps.length) ? '<div class="xsmall muted"><strong>Props:</strong> ' + esc(c.contract.exposedProps.join(', ')) + '</div>' : '') +
        ((c.contract && Array.isArray(c.contract.slots) && c.contract.slots.length) ? '<div class="xsmall muted"><strong>Slots:</strong> ' + esc(c.contract.slots.join(', ')) + '</div>' : '') +
        '<div class="xsmall muted"><strong>Includes:</strong> ' + esc(children) + '</div>' +
        renderEditableContractDetails(c) +
        (saved ? '<div class="xsmall muted">Saved: ' + esc(saved) + '</div>' : '') +
        '<button class="btn primary" type="button" style="margin-top:8px;" data-pattern-builder-add-saved="' + escAttr(c.id || '') + '">Add saved pattern to canvas</button>' +
        '<button class="btn" type="button" style="margin-top:8px;" data-pattern-builder-generate-wrapper="' + escAttr(c.id || '') + '">Edit Wrapper Contract</button>' +
        '<div class="row" style="margin-top:8px;">' +
          '<button class="btn" type="button" data-pattern-builder-rename="' + escAttr(c.id || '') + '">Rename</button>' +
          '<button class="btn danger" type="button" data-pattern-builder-delete="' + escAttr(c.id || '') + '">Delete</button>' +
        '</div>' +
      '</div>';
    }).join('');
    listEl.innerHTML = generatedRegistryHtml + savedPatternCardsHtml;
    renderGeneratedComponentsTray();
  }

  function saveNewContract(contract){
    var contracts = getContracts();
    contract = contract || contactContract();

    // Multi-pattern behavior: each Capture/Save creates a separate library item.
    // Older builds used one fixed id and overwrote the previous pattern. This keeps
    // every captured assembly available as Pattern A, Pattern B, Pattern C, etc.
    contract.id = uniquePatternId(contract);
    contract.name = nextPatternName(contract.name || 'Spectrum Contact Section', contracts);
    contract.savedAt = new Date().toISOString();

    contracts.unshift(contract);
    saveContracts(contracts);
    setLastCapturedPatternId(contract.id);
    render();
    return contract;
  }

  window.patternBuilderAddContact = function(){
    if (window.patternBuilderAddContactDirect) { window.patternBuilderAddContactDirect(); status('Added Contact Section to canvas.'); return; }
    var btn = document.getElementById('leftSpectrumContactSectionPlugin');
    if (btn) { btn.click(); status('Clicked the existing Adobe Spectrum Contact Section palette action.'); }
    else status('Could not find the Contact Section palette action.');
  };

  window.patternBuilderSaveContact = function(){
    var contract = (window.patternBuilderCaptureSelectedPatternDirect && window.patternBuilderCaptureSelectedPatternDirect()) || (window.patternBuilderCaptureSelectedContactDirect && window.patternBuilderCaptureSelectedContactDirect()) || contactContract();
    saveNewContract(contract);
    status(contract.props ? 'Saved selected Contact Section edits as a new reusable pattern.' : 'Saved Contact Section as a new reusable pattern.');
  };

  window.patternBuilderCaptureSelected = function(){
    var before = getContracts().length;
    window.patternBuilderSaveContact();
    var latest = getLastCapturedContract();
    if (latest) status('Captured the current assembly as a new reusable pattern: ' + (latest.name || 'Pattern') + '. You can now generate a wrapper contract from it.');
    else status('Capture did not create a saved pattern. Select a canvas assembly and try again.');
  };

  window.patternBuilderAddSavedToCanvas = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || contracts[0] || null;
    if (!contract) { status('No saved pattern contract was found. Capture the Contact Section first.'); return false; }

    if (typeof window.patternBuilderAddPatternDirect === 'function') {
      var added = window.patternBuilderAddPatternDirect(contract);
      if (added) { status('Added saved pattern to canvas.'); return true; }
    }

    var btn = document.getElementById('leftSpectrumContactSectionPlugin');
    if (btn) { btn.click(); status('Added saved pattern to canvas using the palette fallback.'); return true; }
    status('Could not find the Contact Section action to add the saved pattern.');
    return false;
  };

  window.patternBuilderRenameContract = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || null;
    if (!contract) { status('Pattern contract not found.'); return false; }
    var next = prompt('Rename saved pattern:', contract.name || 'Pattern contract');
    if (next == null) return false;
    next = String(next).trim();
    if (!next) { status('Rename cancelled: pattern name cannot be blank.'); return false; }
    contract.name = next;
    contract.updatedAt = new Date().toISOString();
    saveContracts(contracts);
    render();
    status('Renamed saved pattern to "' + next + '".');
    return true;
  };

  function cloneContractForWrapper(contract){
    return JSON.parse(JSON.stringify(contract || {}));
  }

  function applyWrapperPrompts(contract, opts){
    opts = opts || {};
    contract = cloneContractForWrapper(contract);
    var basePattern = contract.patternComponent || contract.basePatternComponent || contract.wrapperTag || 'spectrum-contact-section';
    var defaultName = contract.wrapperName || contract.name || (contract.props && contract.props.heading) || 'Custom Pattern Component';
    var wrapperName = prompt('Wrapper component name:', defaultName);
    if (wrapperName == null) return null;
    wrapperName = String(wrapperName).trim();
    if (!wrapperName) { status('Wrapper name cannot be blank.'); return null; }
    var suggestedTag = titleToTag(wrapperName, basePattern || 'custom-pattern-component');
    var priorCustomTag = contract.wrapperTag && contract.wrapperTag !== basePattern ? contract.wrapperTag : '';
    var wrapperTag = prompt('Custom element tag name. Must include a hyphen:', priorCustomTag || suggestedTag);
    if (wrapperTag == null) return null;
    wrapperTag = slugifyWrapperTag(wrapperTag, suggestedTag);
    if (!wrapperTag || wrapperTag.indexOf('-') === -1) { status('Wrapper tag must include a hyphen, like hero-banner.'); return null; }
    var description = prompt('Short description for developer handoff:', contract.description || (contract.contract && contract.contract.description) || ('Generated wrapper for ' + wrapperName));
    if (description == null) description = contract.description || (contract.contract && contract.contract.description) || '';

    var currentExposedProps = (contract.contract && Array.isArray(contract.contract.exposedProps) && contract.contract.exposedProps.length)
      ? contract.contract.exposedProps
      : defaultContractPropsForBase(contract);
    var exposedPropsText = prompt('Exposed properties, comma-separated:', currentExposedProps.join(', '));
    if (exposedPropsText == null) exposedPropsText = currentExposedProps.join(', ');
    var exposedProps = splitCsv(exposedPropsText);

    var currentSlots = (contract.contract && Array.isArray(contract.contract.slots) && contract.contract.slots.length)
      ? contract.contract.slots
      : defaultSlotsForBase(contract);
    var slotsText = prompt('Slots, comma-separated:', currentSlots.join(', '));
    if (slotsText == null) slotsText = currentSlots.join(', ');
    var slots = splitCsv(slotsText);

    // Preserve the base pattern renderer, but let the exported custom element tag be designer-controlled.
    contract.basePatternComponent = basePattern;
    contract.patternComponent = basePattern === 'spectrum-info-card' ? 'spectrum-info-card' : (basePattern === 'spectrum-contact-section' ? 'spectrum-contact-section' : (basePattern === 'editor-hero' || basePattern === 'hero' || basePattern === 'hero-section' ? 'editor-hero' : basePattern));
    contract.wrapperTag = wrapperTag;
    contract.wrapperName = wrapperName;
    contract.name = wrapperName;
    contract.description = String(description || '').trim();
    contract.generatedWrapperContract = true;
    contract.updatedAt = new Date().toISOString();
    contract.savedAt = contract.savedAt || new Date().toISOString();
    contract.editableFields = contract.editableFields || [];
    contract.exportIntent = 'Export this saved pattern as a custom web component wrapper using the designer-specified tag.';
    contract.props = contract.props || {};
    contract.props.__wrapperTag = wrapperTag;
    contract.props.__wrapperName = wrapperName;
    contract.props.__wrapperDescription = contract.description;
    contract.contract = {
      componentName: wrapperName,
      tagName: wrapperTag,
      description: contract.description,
      exposedProps: exposedProps,
      slots: slots,
      events: []
    };
    contract.props.__contractProps = exposedProps.join(',');
    contract.props.__contractSlots = slots.join(',');
    contract.props.__contractDescription = contract.description;
    if (opts.newId) contract.id = uniquePatternId(contract);
    return contract;
  }

  window.patternBuilderGenerateWrapperContract = function(id){
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    var savedContract = index >= 0 ? contracts[index] : null;
    if (!savedContract) { status('Pattern contract not found.'); return false; }

    // AB fix: a button inside a saved pattern card must use THAT saved pattern only.
    // It must not silently reuse the first/demo pattern or a stale canvas selection.
    var updated = applyWrapperPrompts(savedContract, { newId: false });
    if (!updated) return false;
    contracts[index] = updated;
    saveContracts(contracts);
    render();
    status('Generated wrapper contract from saved pattern "' + (updated.name || 'Pattern') + '": <' + updated.wrapperTag + '>.');
    return true;
  };

  window.patternBuilderGenerateWrapperFromSelected = function(){
    var selectedContract = null;
    try {
      if (typeof window.patternBuilderCaptureSelectedPatternDirect === 'function') {
        selectedContract = window.patternBuilderCaptureSelectedPatternDirect();
      }
    } catch (err) { selectedContract = null; }

    // AC fix: if the button loses the canvas selection, use the most recently captured
    // saved pattern instead of falling back to stale/demo data. This supports the
    // designer workflow: Capture Selected Assembly -> Generate Wrapper From Selected.
    if (!selectedContract || !selectedContract.props) {
      selectedContract = getLastCapturedContract();
    }

    if (!selectedContract || !selectedContract.props) {
      status('Select and capture the canvas component/pattern first, then generate the wrapper.');
      return false;
    }

    var generated = applyWrapperPrompts(selectedContract, { newId: true });
    if (!generated) return false;
    var contracts = getContracts();
    contracts.unshift(generated);
    saveContracts(contracts);
    setLastCapturedPatternId(generated.id);
    render();
    status('Generated wrapper contract from the captured/selected assembly: <' + generated.wrapperTag + '>.');
    return true;
  };

  window.patternBuilderDeleteContract = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || null;
    if (!contract) { status('Pattern contract not found.'); return false; }
    if (!confirm('Delete saved pattern "' + (contract.name || 'Pattern contract') + '"?')) return false;
    saveContracts(contracts.filter(function(item){ return item && item.id !== id; }));
    render();
    status('Deleted saved pattern.');
    return true;
  };


  function ensureStandaloneContractEditorPanel(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl) return null;
    var panel = document.getElementById('patternBuilderContractEditorPanel');
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = 'patternBuilderContractEditorPanel';
    panel.className = 'group pattern-builder-workflow';
    panel.style.marginTop = '12px';
    panel.style.border = '2px solid var(--brand)';
    panel.innerHTML = '' +
      '<h4 style="margin:0 0 8px;">Contract Editor</h4>' +
      '<div class="hint">Select a saved pattern, then edit the wrapper contract metadata developers will see in export and handoff.</div>' +
      '<label>Saved pattern</label>' +
      '<select id="patternContractEditorSelect"></select>' +
      '<label style="margin-top:8px;">Component name</label>' +
      '<input id="patternContractEditorName" placeholder="Hero Banner">' +
      '<label style="margin-top:8px;">Tag name</label>' +
      '<input id="patternContractEditorTag" placeholder="hero-banner-section">' +
      '<label style="margin-top:8px;">Description</label>' +
      '<textarea id="patternContractEditorDescription" placeholder="Short developer-facing description" style="min-height:56px;"></textarea>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Properties</div>' +
      '<div class="xsmall muted">One property per row: name, type, default value.</div>' +
      '<div id="patternContractEditorProps"></div>' +
      '<button class="btn" type="button" id="patternContractEditorAddProp" style="margin-top:8px;">Add Property</button>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Slots</div>' +
      '<div class="xsmall muted">One slot per row: slot name and description.</div>' +
      '<div id="patternContractEditorSlots"></div>' +
      '<button class="btn" type="button" id="patternContractEditorAddSlot" style="margin-top:8px;">Add Slot</button>' +
      '<button class="btn primary" type="button" id="patternContractEditorSave" style="margin-top:10px;">Save Contract Details</button>' +
      '<div class="xsmall muted" id="patternContractEditorStatus" style="margin-top:8px;">Ready.</div>';
    listEl.insertAdjacentElement('afterend', panel);
    bindStandaloneContractEditorPanel(panel);
    return panel;
  }

  function editorSelectValue(){
    var el = document.getElementById('patternContractEditorSelect');
    return el ? el.value : '';
  }

  function addEditorPropRow(item){
    var root = document.getElementById('patternContractEditorProps');
    if (!root) return;
    item = item || { name:'', type:'string', defaultValue:'' };
    var row = document.createElement('div');
    row.className = 'row';
    row.style.gridTemplateColumns = '1.15fr .8fr 1fr auto';
    row.style.gap = '6px';
    row.style.marginTop = '6px';
    row.innerHTML = '' +
      '<input data-standalone-prop-name placeholder="prop name" value="' + escAttr(item.name || '') + '">' +
      '<select data-standalone-prop-type>' + ['string','number','boolean','url','enum','object'].map(function(type){ return '<option value="' + escAttr(type) + '"' + (item.type === type ? ' selected' : '') + '>' + esc(type) + '</option>'; }).join('') + '</select>' +
      '<input data-standalone-prop-default placeholder="default" value="' + escAttr(item.defaultValue || '') + '">' +
      '<button class="btn danger" type="button" data-standalone-remove-row style="width:auto;padding:6px 8px;">×</button>';
    root.appendChild(row);
  }

  function addEditorSlotRow(item){
    var root = document.getElementById('patternContractEditorSlots');
    if (!root) return;
    item = item || { name:'', description:'' };
    var row = document.createElement('div');
    row.className = 'row';
    row.style.gridTemplateColumns = '1fr 1.35fr auto';
    row.style.gap = '6px';
    row.style.marginTop = '6px';
    row.innerHTML = '' +
      '<input data-standalone-slot-name placeholder="slot name" value="' + escAttr(item.name || '') + '">' +
      '<input data-standalone-slot-description placeholder="description" value="' + escAttr(item.description || '') + '">' +
      '<button class="btn danger" type="button" data-standalone-remove-row style="width:auto;padding:6px 8px;">×</button>';
    root.appendChild(row);
  }

  function populateStandaloneContractEditor(selectedId){
    ensureStandaloneContractEditorPanel();
    var contracts = getContracts();
    var select = document.getElementById('patternContractEditorSelect');
    if (!select) return;
    var currentId = selectedId || select.value || (contracts[0] && contracts[0].id) || '';
    select.innerHTML = contracts.length
      ? contracts.map(function(c){ return '<option value="' + escAttr(c.id || '') + '"' + ((c.id || '') === currentId ? ' selected' : '') + '>' + esc(c.name || c.wrapperName || c.wrapperTag || 'Pattern') + '</option>'; }).join('')
      : '<option value="">No saved patterns yet</option>';
    var c = contracts.filter(function(item){ return item && item.id === (select.value || currentId); })[0] || null;
    var statusEl = document.getElementById('patternContractEditorStatus');
    var propsRoot = document.getElementById('patternContractEditorProps');
    var slotsRoot = document.getElementById('patternContractEditorSlots');
    if (!c) {
      ['patternContractEditorName','patternContractEditorTag','patternContractEditorDescription'].forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
      if (propsRoot) propsRoot.innerHTML = '';
      if (slotsRoot) slotsRoot.innerHTML = '';
      if (statusEl) statusEl.textContent = 'Capture a pattern first.';
      return;
    }
    var contract = c.contract || {};
    var nameEl = document.getElementById('patternContractEditorName');
    var tagEl = document.getElementById('patternContractEditorTag');
    var descEl = document.getElementById('patternContractEditorDescription');
    if (nameEl) nameEl.value = contract.componentName || c.wrapperName || c.name || c.props?.heading || 'Pattern Component';
    if (tagEl) tagEl.value = contract.tagName || c.wrapperTag || c.patternComponent || titleToTag(c.name || c.props?.heading || 'pattern-component', 'custom-pattern-component');
    if (descEl) descEl.value = contract.description || c.description || '';
    if (propsRoot) propsRoot.innerHTML = '';
    normalizePropDefinitions(c).forEach(addEditorPropRow);
    if (propsRoot && !propsRoot.children.length) addEditorPropRow({name:'heading', type:'string', defaultValue:''});
    if (slotsRoot) slotsRoot.innerHTML = '';
    normalizeSlotDefinitions(c).forEach(addEditorSlotRow);
    if (slotsRoot && !slotsRoot.children.length) addEditorSlotRow({name:'content', description:''});
    if (statusEl) statusEl.textContent = 'Editing: ' + (c.name || 'Pattern');
  }

  function saveStandaloneContractEditor(){
    var id = editorSelectValue();
    if (!id) { status('Capture a pattern first.'); return false; }
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    if (index < 0) { status('Pattern contract not found.'); return false; }
    var c = contracts[index];
    var componentName = (document.getElementById('patternContractEditorName')?.value || '').trim() || c.name || 'Pattern Component';
    var tagName = titleToTag((document.getElementById('patternContractEditorTag')?.value || '').trim() || componentName, 'custom-pattern-component');
    var description = (document.getElementById('patternContractEditorDescription')?.value || '').trim();
    var propDefs = Array.from(document.querySelectorAll('#patternContractEditorProps .row')).map(function(row){
      return {
        name: (row.querySelector('[data-standalone-prop-name]')?.value || '').trim(),
        type: (row.querySelector('[data-standalone-prop-type]')?.value || 'string').trim(),
        defaultValue: (row.querySelector('[data-standalone-prop-default]')?.value || '').trim()
      };
    }).filter(function(item){ return item.name; });
    var slotDefs = Array.from(document.querySelectorAll('#patternContractEditorSlots .row')).map(function(row){
      return {
        name: (row.querySelector('[data-standalone-slot-name]')?.value || '').trim(),
        description: (row.querySelector('[data-standalone-slot-description]')?.value || '').trim()
      };
    }).filter(function(item){ return item.name; });
    c.generatedWrapperContract = true;
    c.wrapperName = componentName;
    c.wrapperTag = tagName;
    c.patternComponent = tagName;
    c.description = description;
    c.contract = c.contract || {};
    c.contract.componentName = componentName;
    c.contract.tagName = tagName;
    c.contract.description = description;
    c.contract.exposedProps = propDefs.map(function(item){ return item.name; });
    c.contract.propDefinitions = propDefs;
    c.contract.slots = slotDefs.map(function(item){ return item.name; });
    c.contract.slotDefinitions = slotDefs;
    c.props = c.props || {};
    c.props.__wrapperTag = tagName;
    c.props.__wrapperName = componentName;
    c.props.__wrapperDescription = description;
    c.props.__contractProps = c.contract.exposedProps.join(',');
    c.props.__contractSlots = c.contract.slots.join(',');
    c.props.__contractDescription = description;
    c.savedAt = new Date().toISOString();
    contracts[index] = c;
    saveContracts(contracts);
    try { if (window.patternBuilderApplyContractToSelectedDirect) window.patternBuilderApplyContractToSelectedDirect(c); } catch (err) { console.warn('Apply standalone contract details to selected item failed:', err); }
    render();
    populateStandaloneContractEditor(id);
    status('Saved editable contract details for <' + tagName + '>. Export metadata applied to the selected canvas item.');
    return true;
  }

  function bindStandaloneContractEditorPanel(panel){
    if (!panel || panel.dataset.contractEditorBound === 'true') return;
    panel.dataset.contractEditorBound = 'true';
    panel.addEventListener('change', function(e){
      if (e.target && e.target.id === 'patternContractEditorSelect') populateStandaloneContractEditor(e.target.value);
    });
    panel.addEventListener('click', function(e){
      var removeBtn = e.target && e.target.closest ? e.target.closest('[data-standalone-remove-row]') : null;
      if (removeBtn) { e.preventDefault(); removeBtn.closest('.row')?.remove(); return; }
      if (e.target && e.target.id === 'patternContractEditorAddProp') { e.preventDefault(); addEditorPropRow(); return; }
      if (e.target && e.target.id === 'patternContractEditorAddSlot') { e.preventDefault(); addEditorSlotRow(); return; }
      if (e.target && e.target.id === 'patternContractEditorSave') { e.preventDefault(); saveStandaloneContractEditor(); return; }
    });
  }

  function bindSavedPatternCardButtons(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl || listEl.dataset.pbSavedDelegated === 'true') return;
    listEl.dataset.pbSavedDelegated = 'true';
    listEl.addEventListener('click', function(e){
      var generatedInspectBtn = e.target && e.target.closest ? e.target.closest('[data-generated-component-inspect]') : null;
      var generatedEditBtn = e.target && e.target.closest ? e.target.closest('[data-generated-component-edit]') : null;
      var generatedDeleteBtn = e.target && e.target.closest ? e.target.closest('[data-generated-component-delete]') : null;
      var generatedDuplicateBtn = e.target && e.target.closest ? e.target.closest('[data-generated-component-duplicate]') : null;
      var generatedDownloadBtn = e.target && e.target.closest ? e.target.closest('[data-generated-component-download]') : null;
      var generatedRegistryExportBtn = e.target && e.target.closest ? e.target.closest('[data-generated-registry-export]') : null;
      var generatedRegistryImportBtn = e.target && e.target.closest ? e.target.closest('[data-generated-registry-import]') : null;
      var generatedRegistryClearFilterBtn = e.target && e.target.closest ? e.target.closest('[data-generated-registry-clear-filter]') : null;
      var addBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-add-saved]') : null;
      var renameBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-rename]') : null;
      var wrapperBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-generate-wrapper]') : null;
      var deleteBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-delete]') : null;
      var saveDetailsBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-save-contract-details]') : null;
      var addPropBtn = e.target && e.target.closest ? e.target.closest('[data-contract-add-prop]') : null;
      var addSlotBtn = e.target && e.target.closest ? e.target.closest('[data-contract-add-slot]') : null;
      var btn = generatedInspectBtn || generatedEditBtn || generatedDeleteBtn || generatedDuplicateBtn || generatedDownloadBtn || generatedRegistryExportBtn || generatedRegistryImportBtn || generatedRegistryClearFilterBtn || addBtn || renameBtn || wrapperBtn || deleteBtn || saveDetailsBtn || addPropBtn || addSlotBtn;
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      var cardEl = btn.closest('[data-pattern-contract-card]');
      if (generatedInspectBtn) {
        var inspectId = generatedInspectBtn.getAttribute('data-generated-component-inspect') || '';
        setInspectedGeneratedComponentId(inspectId);
        render();
        status('Inspecting generated component contract.');
        return;
      }
      if (generatedEditBtn) {
        var editId = generatedEditBtn.getAttribute('data-generated-component-edit') || '';
        populateStandaloneContractEditor(editId);
        var panel = ensureStandaloneContractEditorPanel();
        try { panel && panel.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (err) { panel && panel.scrollIntoView(); }
        status('Editing generated component contract. Update details, then click Save Contract Details.');
        return;
      }
      if (generatedDeleteBtn) {
        var deleteId = generatedDeleteBtn.getAttribute('data-generated-component-delete') || '';
        var contractsForDelete = getContracts();
        var deleteContract = contractsForDelete.filter(function(item){ return item && item.id === deleteId; })[0] || null;
        if (!deleteContract) { status('Generated component contract not found.'); return; }
        if (!confirm('Delete generated component "' + (deleteContract.contract?.componentName || deleteContract.wrapperName || deleteContract.name || deleteContract.wrapperTag || 'Component') + '"? This removes its saved pattern contract from the library.')) return;
        saveContracts(contractsForDelete.filter(function(item){ return item && item.id !== deleteId; }));
        render();
        populateStandaloneContractEditor();
        status('Deleted generated component contract.');
        return;
      }
      if (generatedDuplicateBtn) {
        window.patternBuilderDuplicateGeneratedComponent(generatedDuplicateBtn.getAttribute('data-generated-component-duplicate') || '');
        return;
      }
      if (generatedDownloadBtn) {
        window.patternBuilderDownloadGeneratedComponent(generatedDownloadBtn.getAttribute('data-generated-component-download') || '');
        return;
      }
      if (generatedRegistryExportBtn) {
        window.patternBuilderExportGeneratedRegistry();
        return;
      }
      if (generatedRegistryImportBtn) {
        var input = listEl.querySelector('[data-generated-registry-import-file]');
        if (input) input.click();
        return;
      }
      if (generatedRegistryClearFilterBtn) {
        window.__generatedComponentRegistryFilter = '';
        render();
        status('Cleared generated component search.');
        return;
      }
      if (addBtn) window.patternBuilderAddSavedToCanvas(addBtn.getAttribute('data-pattern-builder-add-saved') || '');
      if (renameBtn) window.patternBuilderRenameContract(renameBtn.getAttribute('data-pattern-builder-rename') || '');
      if (wrapperBtn) window.patternBuilderGenerateWrapperContract(wrapperBtn.getAttribute('data-pattern-builder-generate-wrapper') || '');
      if (deleteBtn) window.patternBuilderDeleteContract(deleteBtn.getAttribute('data-pattern-builder-delete') || '');
      if (saveDetailsBtn) saveContractDetails(saveDetailsBtn.getAttribute('data-pattern-builder-save-contract-details') || '', cardEl);
      if (addPropBtn) addEditablePropRow(cardEl);
      if (addSlotBtn) addEditableSlotRow(cardEl);
    }, true);
    listEl.addEventListener('input', function(e){
      if (e.target && e.target.matches && e.target.matches('[data-generated-component-filter]')) {
        window.__generatedComponentRegistryFilter = e.target.value || '';
        render();
      }
    });
    listEl.addEventListener('change', function(e){
      if (e.target && e.target.matches && e.target.matches('[data-generated-registry-import-file]')) {
        var file = e.target.files && e.target.files[0];
        window.patternBuilderImportGeneratedRegistryFile(file);
        e.target.value = '';
      }
    });
  }

  window.patternBuilderDownloadContracts = function(){
    var contracts = getContracts();
    var blob = new Blob([JSON.stringify({ version: 'pattern-contracts.v1', contracts: contracts }, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'pattern-contracts.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 500);
    status('Downloaded pattern-contracts.json.');
  };

  function bind(){
    var captureBtn = document.getElementById('patternBuilderCaptureSelectedBtn');
    if (captureBtn && !document.getElementById('patternBuilderGenerateSelectedWrapperBtn')) {
      var selectedWrapperBtn = document.createElement('button');
      selectedWrapperBtn.className = 'btn';
      selectedWrapperBtn.type = 'button';
      selectedWrapperBtn.id = 'patternBuilderGenerateSelectedWrapperBtn';
      selectedWrapperBtn.style.marginTop = '8px';
      selectedWrapperBtn.textContent = 'Generate Wrapper / Contract Editor';
      captureBtn.insertAdjacentElement('afterend', selectedWrapperBtn);
    }
    [['patternBuilderAddContactBtn', window.patternBuilderAddContact], ['patternBuilderSaveContactBtn', window.patternBuilderSaveContact], ['patternBuilderCaptureSelectedBtn', window.patternBuilderCaptureSelected], ['patternBuilderGenerateSelectedWrapperBtn', window.patternBuilderGenerateWrapperFromSelected], ['patternBuilderDownloadContractsBtn', window.patternBuilderDownloadContracts]].forEach(function(pair){
      var el = document.getElementById(pair[0]);
      if (el && el.dataset.pbFallbackBound !== 'true') { el.dataset.pbFallbackBound = 'true'; el.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); pair[1](); }, true); }
    });
    render();
    bindSavedPatternCardButtons();
    bindGeneratedComponentsTray();
    renderGeneratedComponentsTray();
    populateStandaloneContractEditor();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();

/* AQ workflow simplification: progressive disclosure for Pattern Builder and Generated Components. */
(function installPatternWorkflowSimplifierAQ(){
  if (window.__patternWorkflowSimplifierAQInstalled) return;
  window.__patternWorkflowSimplifierAQInstalled = true;

  function simplifyPatternBuilderPanel(){
    var panel = document.querySelector('[data-left-panel="pattern-builder"]');
    if (!panel) return;

    var groups = panel.querySelectorAll('.pattern-builder-workflow');
    if (groups[0] && !groups[0].dataset.aqStarterWrapped) {
      groups[0].dataset.aqStarterWrapped = 'true';
      groups[0].style.opacity = '.92';
      groups[0].style.borderStyle = 'dashed';
      var h4 = groups[0].querySelector('h4');
      if (h4) h4.textContent = 'Optional starter';
      var hint = groups[0].querySelector('.hint');
      if (hint) hint.textContent = 'Use this only when you want the sample Contact Section. Most of the time, build or select your own assembly on the canvas.';
    }

    if (groups[1] && !groups[1].dataset.aqPrimaryAction) {
      groups[1].dataset.aqPrimaryAction = 'true';
      groups[1].style.border = '2px solid var(--brand)';
      var capture = groups[1].querySelector('#patternBuilderCaptureSelectedBtn');
      if (capture) {
        capture.classList.add('primary');
        capture.textContent = 'Save Selected as Pattern';
      }
      var saveContact = groups[1].querySelector('#patternBuilderSaveContactBtn');
      if (saveContact) {
        saveContact.textContent = 'Save Sample Contact Pattern';
        saveContact.style.display = 'none';
      }
      var status = groups[1].querySelector('#patternBuilderStatus');
      if (status) status.textContent = 'Select something on the canvas, then save it as a reusable pattern.';
    }
  }

  function wrapAdvancedRegistryControls(registry){
    if (!registry || registry.dataset.aqSimplified === 'true') return;
    registry.dataset.aqSimplified = 'true';

    var title = registry.querySelector('div[style*="font-weight:900"]');
    if (title && title.textContent.trim() === 'Generated Components') {
      title.textContent = 'Generated Components';
    }

    var rows = registry.querySelectorAll('[data-generated-component-row]');
    rows.forEach(function(row){
      if (row.dataset.aqRowSimplified === 'true') return;
      row.dataset.aqRowSimplified = 'true';
      row.classList.add('generated-component-card-compact');

      var inspect = row.querySelector('[data-generated-component-inspect]');
      var edit = row.querySelector('[data-generated-component-edit]');
      var add = row.querySelector('[data-generated-component-tray-add]');
      var dup = row.querySelector('[data-generated-component-duplicate]');
      var json = row.querySelector('[data-generated-component-download]');
      var del = row.querySelector('[data-generated-component-delete]');

      if (add) add.textContent = 'Add to Canvas';
      if (edit) edit.textContent = 'Edit Contract';
      if (del) del.textContent = 'Delete';

      var simple = document.createElement('div');
      simple.className = 'pattern-builder-simple-actions';
      [add, edit].forEach(function(btn){ if (btn) simple.appendChild(btn); });

      var adv = document.createElement('details');
      adv.className = 'pattern-builder-advanced-details';
      adv.innerHTML = '<summary>Advanced tools</summary>';
      var advGrid = document.createElement('div');
      advGrid.className = 'pattern-builder-simple-actions';
      [inspect, dup, json, del].forEach(function(btn){ if (btn) advGrid.appendChild(btn); });
      adv.appendChild(advGrid);

      var oldRows = row.querySelectorAll('.row');
      oldRows.forEach(function(r){ if (!r.contains(simple) && !r.contains(adv)) r.remove(); });
      row.appendChild(simple);
      row.appendChild(adv);
    });

    var filter = registry.querySelector('[data-generated-component-filter]');
    var exportBtn = registry.querySelector('[data-generated-registry-export]');
    var importBtn = registry.querySelector('[data-generated-registry-import]');
    var clearBtn = registry.querySelector('[data-generated-registry-clear-filter]');
    var advancedTop = document.createElement('details');
    advancedTop.className = 'pattern-builder-advanced-details';
    advancedTop.innerHTML = '<summary>Registry import/export and search</summary>';
    var topGrid = document.createElement('div');
    topGrid.style.display = 'grid';
    topGrid.style.gridTemplateColumns = '1fr';
    topGrid.style.gap = '6px';
    topGrid.style.marginTop = '8px';
    [filter, exportBtn, importBtn, clearBtn].forEach(function(node){ if (node) topGrid.appendChild(node); });
    if (topGrid.childNodes.length) {
      advancedTop.appendChild(topGrid);
      var firstRow = registry.querySelector('.row');
      if (firstRow) firstRow.remove();
      var secondRow = registry.querySelector('.row');
      if (secondRow) secondRow.remove();
      var hiddenInput = registry.querySelector('[data-generated-registry-import-file]');
      registry.insertBefore(advancedTop, hiddenInput || registry.children[2] || null);
      if (hiddenInput) advancedTop.appendChild(hiddenInput);
    }
  }

  function simplifyGeneratedComponentsTray(){
    var tray = document.getElementById('generatedComponentsTrayGroup');
    if (!tray || tray.dataset.aqSimplified === 'true') return;
    tray.dataset.aqSimplified = 'true';
    var hint = tray.querySelector('.hint');
    if (hint) hint.textContent = 'Reusable components you generated from saved patterns. Click one to add it to the canvas.';
  }

  function simplifyAll(){
    try { simplifyPatternBuilderPanel(); } catch (e) {}
    try { simplifyGeneratedComponentsTray(); } catch (e) {}
    document.querySelectorAll('[data-generated-component-registry]').forEach(wrapAdvancedRegistryControls);
  }

  document.addEventListener('DOMContentLoaded', simplifyAll);
  setTimeout(simplifyAll, 250);
  setTimeout(simplifyAll, 900);
  var observer = new MutationObserver(function(){ setTimeout(simplifyAll, 0); });
  observer.observe(document.documentElement, { childList:true, subtree:true });
})();
