STEP15A adds Design System token controls for Raw HTML / My Web Components.
Open index.html, save a Raw HTML component, then use Design System > My Web Components — Tokens.
