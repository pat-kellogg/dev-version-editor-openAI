(function(){
  'use strict';
  var BUILD='AQ-CONICAL-V2 STEP12 PROMOTION WIZARD V1';
  if(window.__aqPromotionWizardV1Installed) return;
  window.__aqPromotionWizardV1Installed=true;

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function clone(o){try{return JSON.parse(JSON.stringify(o));}catch(e){return null;}}
  function st(){try{return window.state || (typeof state!=='undefined'?state:null);}catch(e){return null;}}
  function toast(msg){try{if(typeof window.showToast==='function') window.showToast(msg);}catch(e){} var s=document.getElementById('aqV2PatternBuilderMiniStatus'); if(s) s.textContent=msg;}
  function contracts(){return (window.AQ_COMPONENT_CONTRACTS_V1 && window.AQ_COMPONENT_CONTRACTS_V1.contracts) || {};}
  function contractFor(type){var c=contracts(); type=String(type||'').toLowerCase(); if(c[type]) return c[type]; if(type==='stack') return c.container; if(type==='html' || type==='native') return c.html; return null;}
  function selectedSection(){
    var s=st(); if(!s || !Array.isArray(s.sections)) return null;
    var sel=s.selected || window.selected || {};
    if(sel.sectionId) return s.sections.find(function(x){return x && x.id===sel.sectionId;}) || null;
    if(sel.itemId) return s.sections.find(function(sec){return sec && JSON.stringify(sec.items||[]).indexOf('"'+sel.itemId+'"')>-1;}) || null;
    return null;
  }
  function walk(node,out,depth){
    if(!node || depth>20) return;
    ['items','children'].forEach(function(k){
      var list=Array.isArray(node[k])?node[k]:[];
      list.forEach(function(item,i){ if(!item) return; out.push({item:item,depth:depth,index:i,parent:node}); walk(item,out,depth+1); });
    });
  }
  function itemType(item){
    var t=String(item && (item.type || item.componentType || item.componentTag || item.pluginId || item.tag || '') || '').toLowerCase();
    if(t.indexOf('hero')>-1) return 'hero';
    if(t.indexOf('form')>-1 || t.indexOf('contact')>-1) return 'form';
    if(t.indexOf('card')>-1) return 'card';
    if(t.indexOf('button')>-1 || t==='btn') return 'button';
    if(t.indexOf('image')>-1 || t==='img') return 'image';
    if(t.indexOf('text')>-1 || /^h[1-6]$/.test(t) || t==='p' || t==='paragraph') return 'text';
    if(t.indexOf('menu')>-1 || t.indexOf('nav')>-1) return 'menu';
    if(t.indexOf('container')>-1 || t.indexOf('stack')>-1 || t.indexOf('div')>-1 || t.indexOf('section')>-1) return 'container';
    return t || 'unknown';
  }
  function analyze(section){
    var flat=[]; walk(section,flat,1);
    var counts={}; var ready=0, partial=0, unknown=0, warnings=[];
    flat.forEach(function(x){ var type=itemType(x.item); counts[type]=(counts[type]||0)+1; var c=contractFor(type); if(!c){unknown++; warnings.push('No contract found for '+type+' item.');} else if(c.status==='export-ready'){ready++;} else if(c.status==='partial'){partial++; (c.knownGaps||[]).slice(0,1).forEach(function(g){warnings.push(c.name+': '+g);});} });
    var suggested='aq-component-section';
    if(counts.hero) suggested='aq-hero-section';
    else if(counts.form) suggested='aq-contact-panel';
    else if(counts.card && flat.length<=3) suggested='aq-feature-card';
    else if(counts.card && flat.length>3) suggested='aq-feature-grid';
    else if(counts.menu) suggested='aq-nav-section';
    var score=Math.max(35, Math.min(100, 100 - partial*8 - unknown*18 - (warnings.length>4?10:0)));
    return {flat:flat,counts:counts,ready:ready,partial:partial,unknown:unknown,warnings:warnings,suggested:suggested,score:score};
  }
  function validTag(v){return /^[a-z][a-z0-9]*(-[a-z0-9]+)+$/.test(String(v||'').trim());}
  function css(){
    if(document.getElementById('aq-promotion-wizard-v1-style')) return;
    var s=document.createElement('style'); s.id='aq-promotion-wizard-v1-style'; s.textContent='\
      .aq-promo-btn{width:100%;margin-top:8px}.aq-promo-modal{position:fixed;inset:0;z-index:1000000;background:rgba(15,23,42,.45);display:none;align-items:center;justify-content:center;padding:22px}.aq-promo-modal[aria-hidden="false"]{display:flex}.aq-promo-dialog{width:min(980px,94vw);max-height:88vh;overflow:auto;background:#fff;color:#0f172a;border:1px solid #dbe4ee;border-radius:18px;box-shadow:0 24px 70px rgba(15,23,42,.28)}.aq-promo-head{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;padding:18px 20px;border-bottom:1px solid #e2e8f0}.aq-promo-title{font-weight:900;font-size:18px}.aq-promo-sub{font-size:13px;color:#64748b;margin-top:4px}.aq-promo-body{padding:18px 20px;display:grid;gap:14px}.aq-promo-steps{display:flex;gap:8px;flex-wrap:wrap}.aq-promo-step{padding:6px 10px;border-radius:999px;background:#f1f5f9;color:#475569;font-size:12px;font-weight:800}.aq-promo-step.active{background:#eef2ff;color:#3730a3}.aq-promo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.aq-promo-card{border:1px solid #dbe4ee;border-radius:14px;padding:14px;background:#fff}.aq-promo-card h4{margin:0 0 8px;font-size:15px}.aq-promo-meter{height:10px;background:#e2e8f0;border-radius:999px;overflow:hidden}.aq-promo-meter>span{display:block;height:100%;background:#4f46e5}.aq-promo-list{margin:8px 0 0;padding-left:18px;color:#475569;font-size:12px}.aq-promo-table{width:100%;border-collapse:collapse;font-size:13px}.aq-promo-table th,.aq-promo-table td{padding:9px 8px;border-bottom:1px solid #e2e8f0;text-align:left;vertical-align:top}.aq-promo-table th{font-size:11px;text-transform:uppercase;color:#64748b;letter-spacing:.04em}.aq-promo-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#f1f5f9;border-radius:6px;padding:1px 5px}.aq-promo-note{padding:12px 14px;border:1px solid #bfdbfe;background:#eff6ff;border-radius:12px;color:#1e3a8a;font-size:13px;line-height:1.45}.aq-promo-actions{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #e2e8f0}.aq-promo-actions .right{display:flex;gap:8px;flex-wrap:wrap}.aq-promo-input{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:10px;padding:10px 12px;font:inherit}.aq-promo-warn{color:#92400e}.aq-promo-ok{color:#166534}.aq-promo-badge{display:inline-flex;padding:3px 8px;border-radius:999px;background:#f1f5f9;color:#334155;font-weight:800;font-size:11px;margin:2px 4px 2px 0}';
    document.head.appendChild(s);
  }
  function modal(){
    css(); var m=document.getElementById('aqPromotionWizardV1Modal'); if(m) return m;
    m=document.createElement('div'); m.id='aqPromotionWizardV1Modal'; m.className='aq-promo-modal'; m.setAttribute('aria-hidden','true');
    m.innerHTML='<div class="aq-promo-dialog" role="dialog" aria-modal="true" aria-labelledby="aqPromotionWizardTitle"><div class="aq-promo-head"><div><div class="aq-promo-title" id="aqPromotionWizardTitle">AQ Promotion Wizard</div><div class="aq-promo-sub">Analyze selected pattern against AQ Component Contract v1 before promoting it to a native Web Component.</div></div><button class="btn" type="button" id="aqPromoCloseBtn">Close</button></div><div class="aq-promo-body" id="aqPromoBody"></div><div class="aq-promo-actions"><button class="btn" type="button" id="aqPromoBackBtn">Back</button><div class="right"><button class="btn" type="button" id="aqPromoContractBtn">Open Contract Registry</button><button class="btn primary" type="button" id="aqPromoNextBtn">Next</button></div></div></div>';
    document.body.appendChild(m); m.addEventListener('click',function(e){if(e.target===m) close();});
    m.querySelector('#aqPromoCloseBtn').addEventListener('click',close);
    m.querySelector('#aqPromoBackBtn').addEventListener('click',function(){go(step-1);});
    m.querySelector('#aqPromoNextBtn').addEventListener('click',function(){ if(step<3) go(step+1); else finish(); });
    m.querySelector('#aqPromoContractBtn').addEventListener('click',function(){ if(window.AQ_COMPONENT_CONTRACTS_V1 && window.AQ_COMPONENT_CONTRACTS_V1.open) window.AQ_COMPONENT_CONTRACTS_V1.open(); });
    return m;
  }
  var current=null, analysis=null, step=0;
  function steps(){return '<div class="aq-promo-steps"><span class="aq-promo-step '+(step===0?'active':'')+'">1 Analyze</span><span class="aq-promo-step '+(step===1?'active':'')+'">2 Contracts</span><span class="aq-promo-step '+(step===2?'active':'')+'">3 Name/API</span><span class="aq-promo-step '+(step===3?'active':'')+'">4 Promote</span></div>';}
  function render(){
    var body=modal().querySelector('#aqPromoBody'); var a=analysis;
    if(!current){body.innerHTML='<div class="aq-promo-note"><strong>No selected section.</strong><br>Select a top-level section on the canvas, then open the Promotion Wizard.</div>'; return;}
    if(step===0){
      body.innerHTML=steps()+'<div class="aq-promo-note"><strong>'+esc(BUILD)+'</strong><br>Selected pattern: <span class="aq-promo-code">'+esc(current.title||current.name||current.id||'section')+'</span>. Suggested custom element: <span class="aq-promo-code">&lt;'+esc(a.suggested)+'&gt;</span>.</div><div class="aq-promo-grid"><section class="aq-promo-card"><h4>Promotion readiness</h4><div class="aq-promo-meter"><span style="width:'+a.score+'%"></span></div><p><strong>'+a.score+'/100</strong> based on registered contracts, partial components, and unknown components.</p></section><section class="aq-promo-card"><h4>Detected components</h4>'+Object.keys(a.counts).sort().map(function(k){return '<span class="aq-promo-badge">'+esc(k)+': '+a.counts[k]+'</span>';}).join('')+'</section><section class="aq-promo-card"><h4>Summary</h4><p>'+a.ready+' export-ready · '+a.partial+' partial · '+a.unknown+' unknown</p></section></div>';
    } else if(step===1){
      var rows=Object.keys(a.counts).sort().map(function(k){var c=contractFor(k); return '<tr><td><strong>'+esc(k)+'</strong><br><small>'+esc(a.counts[k])+' instance(s)</small></td><td>'+(c?esc(c.name):'No contract')+'</td><td>'+(c?esc(c.status):'unknown')+'</td><td>'+(c?'<span class="aq-promo-code">'+esc(c.renderer)+'</span>':'—')+'</td><td>'+(c?esc((c.knownGaps||[]).join('; ')||'none listed'):'Needs contract before high-fidelity export')+'</td></tr>';}).join('');
      body.innerHTML=steps()+'<div class="aq-promo-note"><strong>Contract check.</strong><br>The exporter should use certified renderers where contracts exist and visible fallback where they do not.</div><table class="aq-promo-table"><thead><tr><th>Type</th><th>Contract</th><th>Status</th><th>Renderer</th><th>Known gaps</th></tr></thead><tbody>'+rows+'</tbody></table>';
    } else if(step===2){
      body.innerHTML=steps()+'<div class="aq-promo-note"><strong>Name the component.</strong><br>Use a semantic custom-element tag. It must include a hyphen, such as <span class="aq-promo-code">aq-feature-card</span>.</div><div class="aq-promo-grid"><section class="aq-promo-card"><h4>Component tag</h4><input class="aq-promo-input" id="aqPromoTagInput" value="'+esc(a.suggested)+'"><p id="aqPromoTagStatus" class="aq-promo-ok">Valid custom element name.</p></section><section class="aq-promo-card"><h4>Public surface</h4><ul class="aq-promo-list"><li>Shadow DOM wrapper</li><li>Default slot</li><li>CSS parts from registered contracts</li><li>Token CSS variables from registered contracts</li><li>Contract JSON embedded in export</li></ul></section></div>';
      setTimeout(function(){var input=document.getElementById('aqPromoTagInput'), status=document.getElementById('aqPromoTagStatus'); if(input){input.addEventListener('input',function(){var ok=validTag(input.value); status.textContent=ok?'Valid custom element name.':'Needs lowercase custom element name with a hyphen.'; status.className=ok?'aq-promo-ok':'aq-promo-warn';}); input.focus(); input.select();}},0);
    } else {
      var warnings=(a.warnings||[]).slice(0,8);
      body.innerHTML=steps()+'<div class="aq-promo-note"><strong>Ready to promote.</strong><br>The wizard will hand off to the existing certified Web Component exporter so we do not break the proven STEP10B path.</div><div class="aq-promo-grid"><section class="aq-promo-card"><h4>What will happen</h4><ul class="aq-promo-list"><li>Use semantic tag name</li><li>Use component renderer registry</li><li>Use AQ Component Contract v1 metadata</li><li>Generate standalone native Web Component HTML</li></ul></section><section class="aq-promo-card"><h4>Warnings</h4>'+(warnings.length?'<ul class="aq-promo-list">'+warnings.map(function(w){return '<li>'+esc(w)+'</li>';}).join('')+'</ul>':'<p class="aq-promo-ok">No major contract warnings.</p>')+'</section></div>';
    }
    var back=document.getElementById('aqPromoBackBtn'), next=document.getElementById('aqPromoNextBtn'); if(back) back.disabled=step===0; if(next) next.textContent=step<3?'Next':'Promote / Export';
  }
  function go(n){step=Math.max(0,Math.min(3,n)); render();}
  function open(){current=clone(selectedSection()); if(current) analysis=analyze(current); else analysis=null; step=0; modal().setAttribute('aria-hidden','false'); render(); toast(BUILD+' opened.');}
  function close(){var m=document.getElementById('aqPromotionWizardV1Modal'); if(m) m.setAttribute('aria-hidden','true');}
  function finish(){
    var input=document.getElementById('aqPromoTagInput'); var tag=input && input.value ? input.value.trim() : (analysis && analysis.suggested) || '';
    if(tag && !validTag(tag)){window.alert('Use a valid lowercase custom element name with a hyphen, like aq-feature-card.'); go(2); return;}
    close();
    var exportBtn=document.getElementById('aqV2ExportSelectedWebComponentBtn');
    if(exportBtn){ toast('Promotion Wizard approved. Continue with the Web Component export prompt. Suggested tag: '+tag); exportBtn.click(); }
    else window.alert('The Web Component export button was not found. Reopen Advanced Tools → Pattern Builder and try again.');
  }
  function inject(){
    css(); var mini=document.getElementById('aqV2PatternBuilderMini'); if(!mini) return false;
    if(!document.getElementById('aqPromotionWizardV1OpenBtn')){
      var b=document.createElement('button'); b.id='aqPromotionWizardV1OpenBtn'; b.type='button'; b.className='btn primary aq-promo-btn'; b.textContent='Promote Selected to Web Component'; b.title='STEP12: analyze contracts before Web Component promotion.'; b.addEventListener('click',function(e){e.preventDefault(); e.stopPropagation(); open();});
      var exportBtn=document.getElementById('aqV2ExportSelectedWebComponentBtn');
      if(exportBtn && exportBtn.parentNode===mini) mini.insertBefore(b,exportBtn); else {var status=document.getElementById('aqV2PatternBuilderMiniStatus'); if(status&&status.parentNode===mini) mini.insertBefore(b,status); else mini.appendChild(b);}
    }
    var s=document.getElementById('aqV2PatternBuilderMiniStatus'); if(s) s.textContent=BUILD+' ready.';
    return true;
  }
  window.AQ_PROMOTION_WIZARD_V1={build:BUILD,open:open,analyze:function(){var sec=selectedSection(); return sec?analyze(sec):null;}};
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){inject(); setTimeout(inject,600);}); else {inject(); setTimeout(inject,600);} 
})();
