(function(){
  'use strict';
  const ROLES=['surface.default','surface.accent','text.primary','text.muted','link.color','radius.default','spacing.sm','spacing.md','spacing.lg','font.family.base','font.family.heading','font.size.base','font.size.heading','font.weight.base','font.weight.heading','line.height.base','border.width','border.style','border.color','focus.width','focus.color','focus.offset','state.hover.surface','state.active.surface','state.disabled.opacity','control.height','control.padding.x','control.padding.y','elevation.default'];
  const BASE_TOKENS={
    'surface.default':'#ffffff','surface.accent':'#2563eb','text.primary':'#0f172a','text.muted':'#475569',
    'radius.default':'16px','spacing.sm':'8px','spacing.md':'16px','spacing.lg':'24px',
    'font.family.base':'Inter, system-ui, -apple-system, Segoe UI, sans-serif','font.family.heading':'Inter, system-ui, -apple-system, Segoe UI, sans-serif',
    'font.size.base':'16px','font.size.heading':'24px','font.weight.base':'400','font.weight.heading':'700','line.height.base':'1.5',
    'border.width':'1px','border.style':'solid','border.color':'#d7dde6',
    'focus.width':'3px','focus.color':'#2563eb','focus.offset':'2px',
    'link.color':'#2563eb','state.hover.surface':'#1d4ed8','state.active.surface':'#1e40af','state.disabled.opacity':'0.5',
    'control.height':'40px','control.padding.x':'16px','control.padding.y':'10px',
    'elevation.default':'0 4px 12px rgba(15,23,42,.12)'
  };
  const TEMPLATES={
    'AQ Default':{...BASE_TOKENS},
    'Brand':{...BASE_TOKENS,'surface.default':'#b91c1c','surface.accent':'#4f46e5','text.primary':'#ffffff','text.muted':'#ffffff','radius.default':'0px','spacing.md':'24px','spacing.lg':'32px','state.hover.surface':'#4338ca','state.active.surface':'#3730a3'},
    'Ocean Test':{...BASE_TOKENS,'surface.default':'#006D77','surface.accent':'#FF5DA2','text.primary':'#FFF4A3','text.muted':'#FFFFFF','radius.default':'20px','spacing.sm':'10px','spacing.md':'24px','spacing.lg':'36px','state.hover.surface':'#e84b91','state.active.surface':'#c93678'},
    'Shock Test':{...BASE_TOKENS,'surface.default':'#3B0A45','surface.accent':'#39FF14','text.primary':'#FFFFFF','text.muted':'#FFFFFF','radius.default':'0px','spacing.sm':'12px','spacing.md':'32px','spacing.lg':'48px','state.hover.surface':'#2ee60f','state.active.surface':'#25bd0c'},
    'Minimal Test':{...BASE_TOKENS,'surface.default':'#FFFFFF','surface.accent':'#E5E7EB','text.primary':'#111827','text.muted':'#4B5563','radius.default':'4px','spacing.md':'16px','spacing.lg':'24px','state.hover.surface':'#d1d5db','state.active.surface':'#9ca3af','elevation.default':'none'}
  };
  let selectedId='', draft=null;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slug=s=>String(s||'design-system').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  function registry(){return window.AQDesignSystemRegistry}
  function uniqueId(name){let base=slug(name),id=base,n=2;while(registry().has(id))id=base+'-'+n++;return id}
  function semanticTokens(system){
    if(!system)return {...TEMPLATES['AQ Default']};
    if(system.id==='aq-default')return {...TEMPLATES['AQ Default']};
    if(system.id==='brand-default')return {...TEMPLATES.Brand};
    const map=(system.metadata&&system.metadata.semanticMapping)||{};
    const out={}; ROLES.forEach(r=>out[r]=(system.tokens||{})[map[r]||r]);
    return Object.assign({...TEMPLATES['AQ Default']},Object.fromEntries(Object.entries(out).filter(([,v])=>v!==undefined)));
  }
  function install(){
    const anchor=document.getElementById('designSystemImportGroup'); if(!anchor||document.getElementById('aqDesignSystemBuilder'))return;
    const box=document.createElement('div'); box.className='group aq-ds-builder'; box.id='aqDesignSystemBuilder';
    box.innerHTML='<div class="aq-ds-builder-head"><div><strong>Design System Workspace</strong><div class="xsmall muted">Add, edit, duplicate, delete, or select the system AQ will apply to newly created components.</div></div><div class="aq-ds-builder-actions"><button class="btn primary" id="aqDsNew" type="button">Add Design System</button></div></div><div class="aq-ds-workspace-status xsmall muted" id="aqDsWorkspaceStatus" aria-live="polite"></div><div class="aq-ds-builder-layout"><div class="aq-ds-builder-list" id="aqDsList"></div><div class="aq-ds-builder-editor" id="aqDsEditor"><div class="aq-ds-builder-empty">Select a design system to review its properties, or add a new one.</div></div></div>';
    anchor.parentNode.insertBefore(box,anchor); document.getElementById('aqDsNew').onclick=newFlow; renderList();
  }
  function renderList(){
    const el=document.getElementById('aqDsList'); if(!el||!registry())return;
    const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';
    const systems=registry().list();
    el.innerHTML=systems.map(s=>'<button type="button" data-id="'+esc(s.id)+'" class="'+(s.id===selectedId?'is-selected ':'')+(s.id===active?'is-active':'')+'"><strong>'+esc(s.name)+'</strong><div class="xsmall muted">'+(s.builtIn?'Built in':'Custom')+' · Version '+esc(s.version||'1.0.0')+'</div><div class="aq-ds-list-status">'+(s.id===active?'Used for new components':'Available')+'</div></button>').join('');
    el.querySelectorAll('button').forEach(b=>b.onclick=()=>selectSystem(b.dataset.id));
    const activeSystem=systems.find(s=>s.id===active);
    const status=document.getElementById('aqDsWorkspaceStatus');
    if(status)status.innerHTML='<strong>Currently selected for new components:</strong> '+esc(activeSystem?activeSystem.name:'AQ Default');
  }
  function defaultProfile(system){const m=system&&system.metadata||{},profiles=Array.isArray(m.profiles)?m.profiles:[];return profiles[0]||{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'}}
  function selectSystem(id){const s=registry().get(id);if(!s)return;const profile=defaultProfile(s);selectedId=id;draft={id:s.id,name:s.name,version:s.version||'1.0.0',description:(s.metadata&&s.metadata.description)||'',builtIn:s.builtIn,tokens:semanticTokens(s),baseTokens:((s.metadata&&s.metadata.baseTokens)||semanticTokens(s)),metadata:{...(s.metadata||{})},profile:{...profile}};renderList();renderEditor()}
  function newFlow(){
    const choices=Object.keys(TEMPLATES).concat(registry().list().filter(s=>!s.builtIn).map(s=>s.name));
    const previous=document.getElementById('aqDsNewDialog');
    if(previous)previous.remove();
    const dialog=document.createElement('dialog');
    dialog.id='aqDsNewDialog';
    dialog.className='aq-ds-new-dialog';
    dialog.innerHTML='<form method="dialog" class="aq-ds-new-dialog-card"><div class="aq-ds-new-dialog-head"><div><strong>New Design System</strong><div class="xsmall muted">Choose a starting point, then name your system.</div></div><button class="btn" value="cancel" type="submit" aria-label="Close">Close</button></div><label class="aq-ds-builder-field"><span>Start from</span><select id="aqDsBaseChoice">'+choices.map(x=>'<option value="'+esc(x)+'">'+esc(x)+'</option>').join('')+'</select></label><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsNewName" type="text" value="My Design System" autocomplete="off"></label><div class="aq-ds-new-dialog-actions"><button class="btn" value="cancel" type="submit">Cancel</button><button class="btn primary" id="aqDsCreateNew" value="default" type="button">Create</button></div></form>';
    document.body.appendChild(dialog);
    const select=dialog.querySelector('#aqDsBaseChoice');
    const nameInput=dialog.querySelector('#aqDsNewName');
    const create=dialog.querySelector('#aqDsCreateNew');
    const syncCreateState=()=>{create.disabled=!nameInput.value.trim();};
    nameInput.addEventListener('input',syncCreateState);
    create.addEventListener('click',()=>{
      const choice=select.value;
      let tokens=TEMPLATES[choice];
      if(!tokens){const existing=registry().list().find(s=>s.name.toLowerCase()===String(choice).toLowerCase());tokens=semanticTokens(existing)}
      tokens={...(tokens||TEMPLATES['AQ Default'])};
      const name=nameInput.value.trim();
      if(!name){nameInput.focus();return}
      selectedId='';draft={id:uniqueId(name),name,version:'1.0.0',description:'',builtIn:false,isNew:true,tokens,baseTokens:{...tokens},metadata:{},profile:{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'}};
      dialog.close();dialog.remove();renderList();renderEditor();
    });
    dialog.addEventListener('close',()=>dialog.remove(),{once:true});
    syncCreateState();
    dialog.showModal();
    setTimeout(()=>nameInput.select(),0);
  }
  function field(label,key,type='text',options={}){
    const value=draft.tokens[key]??BASE_TOKENS[key]??'';
    if(type==='color')return '<label class="aq-ds-builder-field"><span>'+label+'</span><div class="aq-ds-color-row"><input data-token="'+key+'" type="text" value="'+esc(value)+'"><input data-color="'+key+'" type="color" value="'+esc(/^#[0-9a-f]{6}$/i.test(value)?value:'#000000')+'"></div></label>';
    if(type==='number'){
      const unit=options.unit??'px', numeric=parseFloat(value);
      return '<label class="aq-ds-builder-field"><span>'+label+'</span><div class="aq-ds-number-row"><input data-number-token="'+key+'" data-unit="'+esc(unit)+'" type="number" value="'+esc(Number.isFinite(numeric)?numeric:(options.value??0))+'" min="'+esc(options.min??0)+'" max="'+esc(options.max??200)+'" step="'+esc(options.step??1)+'"><span>'+esc(options.label??unit)+'</span></div></label>';
    }
    if(type==='select')return '<label class="aq-ds-builder-field"><span>'+label+'</span><select data-token="'+key+'">'+(options.values||[]).map(x=>'<option value="'+esc(x.value??x)+'" '+(String(x.value??x)===String(value)?'selected':'')+'>'+esc(x.label??x)+'</option>').join('')+'</select></label>';
    return '<label class="aq-ds-builder-field"><span>'+label+'</span><input data-token="'+key+'" type="text" value="'+esc(value)+'"></label>';
  }
  function renderEditor(){
    const el=document.getElementById('aqDsEditor');if(!el||!draft)return;
    draft.tokens=Object.assign({...BASE_TOKENS},draft.tokens||{});
    const editable=!draft.builtIn;
    const activeId=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';
    const isActive=draft.id===activeId;
    const fonts=[
      {label:'Inter / system UI',value:'Inter, system-ui, -apple-system, Segoe UI, sans-serif'},
      {label:'Arial',value:'Arial, Helvetica, sans-serif'},
      {label:'Helvetica',value:'Helvetica Neue, Helvetica, Arial, sans-serif'},
      {label:'Georgia',value:'Georgia, Times New Roman, serif'},
      {label:'Times New Roman',value:'Times New Roman, Times, serif'},
      {label:'Verdana',value:'Verdana, Geneva, sans-serif'},
      {label:'Trebuchet MS',value:'Trebuchet MS, Arial, sans-serif'},
      {label:'Monospace',value:'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'}
    ];
    el.innerHTML='<div class="aq-ds-editor-heading"><div><strong>'+esc(draft.name)+'</strong><div class="xsmall muted">'+(draft.builtIn?'Built-in system':'Custom design system')+'</div></div><span class="aq-ds-readiness">Ready</span></div>'+
      '<div class="aq-ds-builder-grid"><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsName" type="text" value="'+esc(draft.name)+'" '+(!editable?'disabled':'')+'></label><label class="aq-ds-builder-field"><span>Version</span><input id="aqDsVersion" type="text" value="'+esc(draft.version)+'" '+(!editable?'disabled':'')+'></label></div>'+
      '<label class="aq-ds-builder-field" style="margin-top:10px"><span>Description</span><textarea id="aqDsDescription" rows="2" '+(!editable?'disabled':'')+'>'+esc(draft.description)+'</textarea></label>'+
      '<h4>Design System Profile</h4><div class="aq-ds-builder-grid"><label class="aq-ds-builder-field"><span>Profile name</span><input id="aqDsProfileName" type="text" value="'+esc(draft.profile.name)+'" '+(!editable?'disabled':'')+'></label><label class="aq-ds-builder-field"><span>Density</span><select id="aqDsProfileDensity" '+(!editable?'disabled':'')+'><option value="compact" '+(draft.profile.density==='compact'?'selected':'')+'>Compact</option><option value="comfortable" '+(draft.profile.density==='comfortable'?'selected':'')+'>Comfortable</option><option value="spacious" '+(draft.profile.density==='spacious'?'selected':'')+'>Spacious</option></select></label><label class="aq-ds-builder-field"><span>Typography scale</span><select id="aqDsProfileType" '+(!editable?'disabled':'')+'><option value="compact" '+(draft.profile.typographyScale==='compact'?'selected':'')+'>Compact</option><option value="standard" '+(draft.profile.typographyScale==='standard'?'selected':'')+'>Standard</option><option value="large" '+(draft.profile.typographyScale==='large'?'selected':'')+'>Large</option></select></label><label class="aq-ds-builder-field"><span>Corner treatment</span><select id="aqDsProfileCorners" '+(!editable?'disabled':'')+'><option value="system" '+(draft.profile.cornerTreatment==='system'?'selected':'')+'>Use system radius</option><option value="square" '+(draft.profile.cornerTreatment==='square'?'selected':'')+'>Square</option><option value="rounded" '+(draft.profile.cornerTreatment==='rounded'?'selected':'')+'>Rounded</option></select></label></div>'+
      '<label class="aq-ds-builder-field" style="margin-top:10px"><span>Profile description</span><textarea id="aqDsProfileDescription" rows="2" '+(!editable?'disabled':'')+'>'+esc(draft.profile.description)+'</textarea></label>'+
      '<h4>Core colors</h4><div class="aq-ds-builder-grid">'+field('Surface','surface.default','color')+field('Accent / action','surface.accent','color')+field('Primary text','text.primary','color')+field('Muted text','text.muted','color')+field('Link color','link.color','color')+'</div>'+
      '<h4>Typography</h4><div class="aq-ds-builder-grid">'+field('Body font family','font.family.base','select',{values:fonts})+field('Heading font family','font.family.heading','select',{values:fonts})+field('Body font size','font.size.base','number',{min:10,max:32,step:1,unit:'px'})+field('Heading font size','font.size.heading','number',{min:14,max:72,step:1,unit:'px'})+field('Body font weight','font.weight.base','number',{min:100,max:900,step:100,unit:'',label:''})+field('Heading font weight','font.weight.heading','number',{min:100,max:900,step:100,unit:'',label:''})+field('Line height','line.height.base','number',{min:.8,max:3,step:.1,unit:'',label:''})+'</div>'+
      '<h4>Borders and corners</h4><div class="aq-ds-builder-grid">'+field('Border width','border.width','number',{min:0,max:12,step:1,unit:'px'})+field('Border style','border.style','select',{values:['solid','dashed','dotted','double','none']})+field('Border color','border.color','color')+field('Corner radius','radius.default','number',{min:0,max:64,step:1,unit:'px'})+'</div>'+
      '<h4>Focus styling</h4><div class="aq-ds-builder-grid">'+field('Focus ring width','focus.width','number',{min:0,max:12,step:1,unit:'px'})+field('Focus ring color','focus.color','color')+field('Focus ring offset','focus.offset','number',{min:-8,max:16,step:1,unit:'px'})+'</div>'+
      '<h4>Component states</h4><div class="aq-ds-builder-grid">'+field('Hover surface','state.hover.surface','color')+field('Active surface','state.active.surface','color')+field('Disabled opacity','state.disabled.opacity','number',{min:0,max:1,step:.05,unit:'',label:''})+'</div>'+
      '<h4>Control sizing</h4><div class="aq-ds-builder-grid">'+field('Control height','control.height','number',{min:24,max:80,step:1,unit:'px'})+field('Horizontal padding','control.padding.x','number',{min:0,max:48,step:1,unit:'px'})+field('Vertical padding','control.padding.y','number',{min:0,max:32,step:1,unit:'px'})+'</div>'+
      '<h4>Spacing and elevation</h4><div class="aq-ds-builder-grid">'+field('Small spacing','spacing.sm','number',{min:0,max:64,step:1,unit:'px'})+field('Medium spacing','spacing.md','number',{min:0,max:96,step:1,unit:'px'})+field('Large spacing','spacing.lg','number',{min:0,max:128,step:1,unit:'px'})+field('Elevation shadow','elevation.default')+'</div>'+
      '<div class="aq-ds-builder-preview" id="aqDsPreview" tabindex="0"><div class="aq-ds-preview-eyebrow">Profile Preview</div><h3>Professional Plan</h3><p class="muted">A governed component using this design system.</p><a class="aq-ds-preview-link" href="#">View plan details</a><div class="aq-ds-preview-price">$49 <span class="muted">per month</span></div><div class="aq-ds-preview-actions"><button type="button">Default</button><button class="is-hover" type="button">Hover</button><button class="is-active" type="button">Active</button><button type="button" disabled>Disabled</button></div></div>'+
      '<div class="aq-ds-builder-footer"><button class="btn '+(isActive?'':'primary')+'" id="aqDsActivate" type="button" '+(isActive?'disabled aria-pressed="true"':'')+'>'+(isActive?'Selected for New Components':'Use for New Components')+'</button>'+(editable?'<button class="btn primary" id="aqDsSave" type="button">Save Changes</button><button class="btn" id="aqDsReset" type="button">Reset to Base</button><button class="btn" id="aqDsDuplicate" type="button">Duplicate</button><button class="btn" id="aqDsExport" type="button">Export JSON</button>'+(draft.isNew?'':'<button class="btn" id="aqDsDelete" type="button">Delete</button>'):'<button class="btn" id="aqDsDuplicate" type="button">Duplicate</button>')+'</div>';
    el.querySelectorAll('[data-token]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.token]=i.value;const c=el.querySelector('[data-color="'+i.dataset.token+'"]');if(c&&/^#[0-9a-f]{6}$/i.test(i.value))c.value=i.value;preview()}});
    el.querySelectorAll('[data-number-token]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{const unit=i.dataset.unit||'';draft.tokens[i.dataset.numberToken]=i.value+unit;preview()}});
    el.querySelectorAll('[data-color]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.color]=i.value;el.querySelector('[data-token="'+i.dataset.color+'"]').value=i.value;preview()}});
    if(editable){document.getElementById('aqDsSave').onclick=save;document.getElementById('aqDsReset').onclick=()=>{draft.tokens={...draft.baseTokens};renderEditor()};document.getElementById('aqDsExport').onclick=exportJson;if(!draft.isNew)document.getElementById('aqDsDelete').onclick=remove}
    const activate=document.getElementById('aqDsActivate');if(activate&&!isActive)activate.onclick=()=>{if(draft.isNew){alert('Save this design system before selecting it.');return}if(window.AQActiveDesignSystem&&window.AQActiveDesignSystem.setActiveSystem){window.AQActiveDesignSystem.setActiveSystem(draft.id,{source:'design-system-workspace'});renderList();renderEditor();}};
    document.getElementById('aqDsDuplicate').onclick=duplicate;preview();
  }
  function preview(){
    const p=document.getElementById('aqDsPreview');if(!p)return;const t=draft.tokens;
    p.style.setProperty('--aq-preview-surface',t['surface.default']);p.style.setProperty('--aq-preview-accent',t['surface.accent']);p.style.setProperty('--aq-preview-hover',t['state.hover.surface']);p.style.setProperty('--aq-preview-active',t['state.active.surface']);p.style.setProperty('--aq-preview-primary',t['text.primary']);p.style.setProperty('--aq-preview-muted',t['text.muted']);p.style.setProperty('--aq-preview-link',t['link.color']||t['surface.accent']);p.style.setProperty('--aq-preview-radius',t['radius.default']);p.style.setProperty('--aq-preview-font',t['font.family.base']);p.style.setProperty('--aq-preview-heading-font',t['font.family.heading']);p.style.setProperty('--aq-preview-font-size',t['font.size.base']);p.style.setProperty('--aq-preview-heading-size',t['font.size.heading']);p.style.setProperty('--aq-preview-font-weight',t['font.weight.base']);p.style.setProperty('--aq-preview-heading-weight',t['font.weight.heading']);p.style.setProperty('--aq-preview-line-height',t['line.height.base']);p.style.setProperty('--aq-preview-border-width',t['border.width']);p.style.setProperty('--aq-preview-border-style',t['border.style']);p.style.setProperty('--aq-preview-border-color',t['border.color']);p.style.setProperty('--aq-preview-focus-width',t['focus.width']);p.style.setProperty('--aq-preview-focus-color',t['focus.color']);p.style.setProperty('--aq-preview-focus-offset',t['focus.offset']);p.style.setProperty('--aq-preview-disabled-opacity',t['state.disabled.opacity']);p.style.setProperty('--aq-preview-control-height',t['control.height']);p.style.setProperty('--aq-preview-control-padding-x',t['control.padding.x']);p.style.setProperty('--aq-preview-control-padding-y',t['control.padding.y']);p.style.setProperty('--aq-preview-elevation',t['elevation.default']);p.style.padding=t['spacing.md'];
  }
  function payload(){const profile={id:(draft.profile&&draft.profile.id)||'default',name:(document.getElementById('aqDsProfileName')||{}).value?.trim()||'Default',description:(document.getElementById('aqDsProfileDescription')||{}).value?.trim()||'',density:(document.getElementById('aqDsProfileDensity')||{}).value||'comfortable',typographyScale:(document.getElementById('aqDsProfileType')||{}).value||'standard',cornerTreatment:(document.getElementById('aqDsProfileCorners')||{}).value||'system'};return{id:draft.id,name:document.getElementById('aqDsName').value.trim(),version:document.getElementById('aqDsVersion').value.trim()||'1.0.0',tokens:{...draft.tokens},metadata:{...(draft.metadata||{}),description:document.getElementById('aqDsDescription').value.trim(),baseTokens:{...draft.baseTokens},profiles:[profile],defaultProfileId:profile.id}}}
  function save(){try{const data=payload();let rec;if(draft.isNew)rec=registry().importFromObject(data,{fallbackName:data.name+'.json'});else rec=registry().replaceImported(draft.id,data,{useImportedName:true});selectedId=rec.id;draft.isNew=false;selectSystem(rec.id);if(window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId&&window.AQActiveDesignSystem.getActiveId()===rec.id)window.AQActiveDesignSystem.setActiveSystem(rec.id,{source:'design-system-editor-save'});if(typeof window.renderImportedDesignSystemRegistry==='function')window.renderImportedDesignSystemRegistry();alert('Design system saved.')}catch(e){alert('Could not save: '+e.message)}}
  function duplicate(){
    const name=window.prompt('Name the duplicate:',draft.name+' Copy');
    if(!name||!name.trim())return;
    try{
      const originalId=draft.id;
      const originalRecord=registry().get(originalId);
      if(!originalRecord)throw new Error('The original design system could not be found.');
      const source=payload();
      const copyName=name.trim();
      const copyProfile={...((source.metadata&&Array.isArray(source.metadata.profiles)&&source.metadata.profiles[0])||draft.profile||{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'})};
      const copyId=uniqueId(copyName+'-copy');
      if(copyId===originalId)throw new Error('AQ could not create a separate identity for the duplicate.');
      const copy={
        id:copyId,
        name:copyName,
        version:source.version||'1.0.0',
        tokens:{...(source.tokens||draft.tokens)},
        metadata:{...(source.metadata||{}),description:(source.metadata&&source.metadata.description)||draft.description||'',baseTokens:{...(source.tokens||draft.tokens)},profiles:[copyProfile],defaultProfileId:copyProfile.id||'default',duplicatedFromId:originalId,duplicatedAt:new Date().toISOString()}
      };
      const rec=registry().importFromObject(copy,{fallbackName:copyName+'.json'});
      if(!registry().has(originalId)){
        registry().importFromObject(originalRecord,{fallbackName:originalRecord.name+'.json'});
      }
      if(!registry().has(originalId)||!registry().has(rec.id)||rec.id===originalId){
        throw new Error('Duplicate integrity check failed; both systems were not preserved.');
      }
      if(typeof window.renderImportedDesignSystemRegistry==='function')window.renderImportedDesignSystemRegistry();
      selectedId=rec.id;
      selectSystem(rec.id);
      alert('Design system duplicated and saved. The original was preserved.');
    }catch(e){alert('Could not duplicate: '+e.message)}
  }
  function exportJson(){const data=payload();const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=slug(data.name)+'-'+data.version+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
  function remove(){if(!confirm('Delete '+draft.name+'?'))return;const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'';if(active===draft.id){alert('Activate another system before deleting this one.');return}registry().remove(draft.id);selectedId='';draft=null;renderList();document.getElementById('aqDsEditor').innerHTML='<div class="aq-ds-builder-empty">Select a design system or create a new one.</div>'}
  document.addEventListener('DOMContentLoaded',()=>{install();const btn=document.getElementById('designSystemBtn');if(btn)btn.addEventListener('click',()=>setTimeout(()=>{install();renderList();if(!selectedId&&registry()){const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';selectSystem(active);}},0));});
})();
