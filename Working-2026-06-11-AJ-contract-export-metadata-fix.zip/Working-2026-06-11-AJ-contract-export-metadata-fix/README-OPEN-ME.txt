Open index.html with app.js, styles.css, pattern-builder-fallback.js, example-callout-card.js, and component-contracts-sidecar.json in the same folder.

This X build starts from W and only fixes the external Info Card image URL field paste/focus behavior.
