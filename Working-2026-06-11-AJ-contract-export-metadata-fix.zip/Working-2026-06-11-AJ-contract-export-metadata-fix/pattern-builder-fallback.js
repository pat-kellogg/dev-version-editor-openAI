/* Pattern Builder action wiring fallback: keeps the visible Pattern Builder controls functional even if internal app bindings change.
   2026-06-11 Z: Adds basic designer-generated wrapper contract controls. */
(function(){
  var STORAGE_KEY = 'structuredUxPatternContracts.v1';
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>]/g, function(ch){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[ch]; }); }
  function escAttr(s){ return esc(s).replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
  function safeParse(v,f){ try { var x = JSON.parse(v); return x == null ? f : x; } catch(e){ return f; } }
  function getContracts(){ var list = safeParse(localStorage.getItem(STORAGE_KEY) || '[]', []); return Array.isArray(list) ? list : []; }
  function saveContracts(list){ localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.isArray(list) ? list : [], null, 2)); }
  var lastCapturedPatternId = localStorage.getItem(STORAGE_KEY + '.lastCapturedId') || '';
  function setLastCapturedPatternId(id){ lastCapturedPatternId = String(id || ''); try { localStorage.setItem(STORAGE_KEY + '.lastCapturedId', lastCapturedPatternId); } catch(e){} }
  function getLastCapturedContract(){ var contracts = getContracts(); return contracts.filter(function(item){ return item && item.id === lastCapturedPatternId; })[0] || contracts[0] || null; }
  function status(msg){ var el = document.getElementById('patternBuilderStatus'); if (el) el.textContent = msg || ''; }
  function uniquePatternId(contract){ var kind = contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag);
    var base = kind === 'spectrum-info-card' ? 'pattern-spectrum-info-card' : (kind === 'editor-hero' || kind === 'hero' || kind === 'hero-section' ? 'pattern-editor-hero' : 'pattern-spectrum-contact-section'); return base + '-' + Date.now() + '-' + Math.floor(Math.random() * 100000); }
  function nextPatternName(base, contracts){
    base = String(base || 'Spectrum Contact Section').trim() || 'Spectrum Contact Section';
    var names = contracts.map(function(item){ return String(item && item.name || ''); });
    if (names.indexOf(base) === -1) return base;
    var n = 2;
    while (names.indexOf(base + ' ' + n) !== -1) n += 1;
    return base + ' ' + n;
  }

  function slugifyWrapperTag(value, fallback){
    var raw = String(value || '').trim().toLowerCase();
    var safe = raw.replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    if (safe && safe.indexOf('-') !== -1 && /^[a-z][a-z0-9-]*-[a-z0-9-]*$/.test(safe)) return safe;
    return fallback || 'custom-pattern-component';
  }

  function titleToTag(title, fallback){
    var base = String(title || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (!base) return fallback || 'custom-pattern-component';
    if (base.indexOf('-') === -1) base += '-component';
    return slugifyWrapperTag(base, fallback || 'custom-pattern-component');
  }


  function splitCsv(value){
    return String(value || '').split(',').map(function(item){ return item.trim(); }).filter(Boolean);
  }

  function defaultContractPropsForBase(contract){
    var base = String(contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag) || '').trim();
    if (base === 'spectrum-contact-section') return ['eyebrow','heading','intro','nameLabel','emailLabel','messageLabel','buttonLabel'];
    if (base === 'spectrum-info-card') return ['eyebrow','heading','body','buttonLabel','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','mediaBehavior'];
    if (base === 'editor-hero' || base === 'hero' || base === 'hero-section') return ['heading','body','cta','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','overlayMode','overlayPosition'];
    return (contract && Array.isArray(contract.editableFields) && contract.editableFields.length) ? contract.editableFields.slice(0, 8) : ['heading','body','cta','imageSrc'];
  }

  function defaultSlotsForBase(contract){
    var base = String(contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag) || '').trim();
    if (base === 'spectrum-contact-section') return ['intro','form','actions'];
    if (base === 'spectrum-info-card') return ['media','content','actions'];
    if (base === 'editor-hero' || base === 'hero' || base === 'hero-section') return ['media','content','actions'];
    return ['content','actions'];
  }

  function contactContract(){
    return {
      id: 'pattern-spectrum-contact-section',
      name: 'Spectrum Contact Section',
      type: 'assembled-pattern-contract',
      sourceMode: 'assembled-from-linked-components',
      wrapperTag: 'spectrum-contact-section',
      patternComponent: 'spectrum-contact-section',
      sourceLibraries: [{ name: 'Adobe Spectrum Web Components', dependency: '@spectrum-web-components/bundle/elements.js' }],
      children: [
        { tag: 'sp-textfield', role: 'name field', editableProps: ['label','placeholder'] },
        { tag: 'sp-textfield', role: 'email field', editableProps: ['label','placeholder'] },
        { tag: 'sp-textfield', role: 'message field', editableProps: ['label','placeholder'] },
        { tag: 'sp-button', role: 'submit action', editableProps: ['variant','text'] }
      ],
      editableFields: ['eyebrow','heading','intro','nameLabel','emailLabel','messageLabel','buttonLabel','themeColor','themeScale'],
      layoutIntent: { desktop: 'two-column contact section', mobile: 'single-column stacked form', gap: 'system spacing' },
      responsiveIntent: 'Keep text and form side-by-side on wide screens; stack content before form on smaller screens.',
      accessibilityIntent: 'Each field requires a label; submit action remains keyboard reachable; section heading identifies the region.',
      savedAt: new Date().toISOString()
    };
  }

  function infoCardContract(){
    return {
      id: 'pattern-spectrum-info-card',
      name: 'Spectrum Info Card',
      type: 'assembled-pattern-contract',
      sourceMode: 'assembled-from-linked-components',
      wrapperTag: 'spectrum-info-card',
      patternComponent: 'spectrum-info-card',
      sourceLibraries: [{ name: 'Adobe Spectrum Web Components', dependency: '@spectrum-web-components/bundle/elements.js' }],
      children: [
        { tag: 'sp-theme', role: 'theme wrapper' },
        { tag: 'sp-button', role: 'card action', editableProps: ['variant','text'] }
      ],
      editableFields: ['eyebrow','heading','body','buttonLabel','imageSrc','imageAlt','mediaPosition','imageFit','mediaHeight','mediaBehavior','themeColor','themeScale'],
      layoutIntent: { desktop: 'single-column information card with optional media', mobile: 'single-column information card', gap: 'system spacing' },
      responsiveIntent: 'Keep authored text and action grouped as a reusable content card.',
      accessibilityIntent: 'Card heading identifies the content; action remains keyboard reachable.',
      savedAt: new Date().toISOString()
    };
  }


  function normalizePropDefinitions(contract){
    var current = (contract && contract.contract && Array.isArray(contract.contract.exposedProps)) ? contract.contract.exposedProps : defaultContractPropsForBase(contract);
    var existing = (contract && contract.contract && Array.isArray(contract.contract.propDefinitions)) ? contract.contract.propDefinitions : [];
    return current.map(function(name){
      var found = existing.filter(function(item){ return item && item.name === name; })[0] || {};
      return {
        name: String(found.name || name || '').trim(),
        type: String(found.type || 'string').trim(),
        defaultValue: String(found.defaultValue == null ? '' : found.defaultValue).trim()
      };
    }).filter(function(item){ return item.name; });
  }

  function normalizeSlotDefinitions(contract){
    var current = (contract && contract.contract && Array.isArray(contract.contract.slots)) ? contract.contract.slots : defaultSlotsForBase(contract);
    var existing = (contract && contract.contract && Array.isArray(contract.contract.slotDefinitions)) ? contract.contract.slotDefinitions : [];
    return current.map(function(name){
      var found = existing.filter(function(item){ return item && item.name === name; })[0] || {};
      return {
        name: String(found.name || name || '').trim(),
        description: String(found.description == null ? '' : found.description).trim()
      };
    }).filter(function(item){ return item.name; });
  }

  function renderEditableContractDetails(c){
    if (!c) return '';
    // AG fix: always show an editable Contract Editor. Earlier builds only
    // rendered this area when c.contract already existed, which made captured
    // patterns look like there was no way to view or edit contract details.
    c.contract = c.contract || {
      componentName: c.wrapperName || c.name || (c.props && c.props.heading) || 'Pattern Component',
      tagName: c.wrapperTag || c.patternComponent || titleToTag(c.name || (c.props && c.props.heading) || 'pattern-component', 'custom-pattern-component'),
      description: c.description || '',
      exposedProps: defaultContractPropsForBase(c),
      slots: defaultSlotsForBase(c),
      events: []
    };
    var propDefs = normalizePropDefinitions(c);
    var slotDefs = normalizeSlotDefinitions(c);
    function propRow(item, i){
      return '<div class="row" style="grid-template-columns:1.15fr .8fr 1fr;gap:6px;margin-top:6px;">' +
        '<input aria-label="Property name" data-contract-prop-name value="' + escAttr(item.name || '') + '" placeholder="prop name">' +
        '<select aria-label="Property type" data-contract-prop-type>' +
          ['string','number','boolean','url','enum','object'].map(function(type){ return '<option value="' + escAttr(type) + '"' + (item.type === type ? ' selected' : '') + '>' + esc(type) + '</option>'; }).join('') +
        '</select>' +
        '<input aria-label="Property default" data-contract-prop-default value="' + escAttr(item.defaultValue || '') + '" placeholder="default">' +
      '</div>';
    }
    function slotRow(item, i){
      return '<div class="row" style="grid-template-columns:1fr 1.35fr;gap:6px;margin-top:6px;">' +
        '<input aria-label="Slot name" data-contract-slot-name value="' + escAttr(item.name || '') + '" placeholder="slot name">' +
        '<input aria-label="Slot description" data-contract-slot-description value="' + escAttr(item.description || '') + '" placeholder="description">' +
      '</div>';
    }
    return '<div class="group" data-contract-editor-panel style="margin-top:10px;padding:10px;border:2px solid var(--brand-soft);">' +
      '<div style="font-weight:900;margin-bottom:6px;">Editable Contract Details</div>' +
      '<div class="xsmall muted" style="margin-bottom:8px;">These fields describe the wrapper component that developers receive in export and handoff.</div>' +
      '<label style="margin-top:8px;">Component name</label>' +
      '<input data-contract-component-name value="' + escAttr(c.contract.componentName || c.wrapperName || c.name || '') + '" placeholder="Promo Card">' +
      '<label style="margin-top:8px;">Tag name</label>' +
      '<input data-contract-tag-name value="' + escAttr(c.contract.tagName || c.wrapperTag || '') + '" placeholder="promo-card-section">' +
      '<label style="margin-top:8px;">Description</label>' +
      '<textarea data-contract-description placeholder="Short developer-facing description" style="min-height:56px;">' + esc(c.contract.description || c.description || '') + '</textarea>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Properties</div>' +
      '<div class="xsmall muted">Name, type, and optional default value. Blank property names are ignored.</div>' +
      '<div data-contract-prop-list>' + (propDefs.length ? propDefs.map(propRow).join('') : propRow({name:'heading',type:'string',defaultValue:''},0)) + '</div>' +
      '<button class="btn" type="button" style="margin-top:8px;" data-contract-add-prop>Add Prop</button>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Slots</div>' +
      '<div class="xsmall muted">Slots describe replaceable regions such as media, content, or actions.</div>' +
      '<div data-contract-slot-list>' + (slotDefs.length ? slotDefs.map(slotRow).join('') : slotRow({name:'content',description:''},0)) + '</div>' +
      '<button class="btn" type="button" style="margin-top:8px;" data-contract-add-slot>Add Slot</button>' +
      '<button class="btn primary" type="button" style="margin-top:8px;" data-pattern-builder-save-contract-details="' + escAttr(c.id || '') + '">Save Contract Details</button>' +
    '</div>';
  }

  function collectRows(root, rowSelector, fieldSelectors){
    var rows = Array.from(root.querySelectorAll(rowSelector));
    return rows.map(function(row){
      var out = {};
      Object.keys(fieldSelectors).forEach(function(key){
        var el = row.querySelector(fieldSelectors[key]);
        out[key] = el ? String(el.value || '').trim() : '';
      });
      return out;
    });
  }

  function saveContractDetails(id, cardEl){
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    if (index < 0) { status('Pattern contract not found.'); return false; }
    var c = contracts[index];
    c.contract = c.contract || {};
    var componentName = cardEl.querySelector('[data-contract-component-name]')?.value || c.name || 'Pattern Component';
    var tagName = cardEl.querySelector('[data-contract-tag-name]')?.value || c.wrapperTag || c.patternComponent || 'custom-pattern-component';
    var description = cardEl.querySelector('[data-contract-description]')?.value || '';
    tagName = slugifyWrapperTag(tagName, titleToTag(componentName, c.wrapperTag || 'custom-pattern-component'));
    var propRows = collectRows(cardEl, '[data-contract-prop-list] .row', {
      name: '[data-contract-prop-name]',
      type: '[data-contract-prop-type]',
      defaultValue: '[data-contract-prop-default]'
    }).filter(function(item){ return item.name; });
    var slotRows = collectRows(cardEl, '[data-contract-slot-list] .row', {
      name: '[data-contract-slot-name]',
      description: '[data-contract-slot-description]'
    }).filter(function(item){ return item.name; });
    c.name = String(componentName || '').trim() || c.name || 'Pattern Component';
    c.wrapperName = c.name;
    c.wrapperTag = tagName;
    c.description = String(description || '').trim();
    c.generatedWrapperContract = true;
    c.updatedAt = new Date().toISOString();
    c.contract.componentName = c.name;
    c.contract.tagName = tagName;
    c.contract.description = c.description;
    c.contract.exposedProps = propRows.map(function(item){ return item.name; });
    c.contract.propDefinitions = propRows;
    c.contract.slots = slotRows.map(function(item){ return item.name; });
    c.contract.slotDefinitions = slotRows;
    c.contract.events = c.contract.events || [];
    c.props = c.props || {};
    c.props.__wrapperTag = tagName;
    c.props.__wrapperName = c.name;
    c.props.__wrapperDescription = c.description;
    c.props.__contractProps = c.contract.exposedProps.join(',');
    c.props.__contractSlots = c.contract.slots.join(',');
    c.props.__contractDescription = c.description;
    contracts[index] = c;
    saveContracts(contracts);
    try { if (window.patternBuilderApplyContractToSelectedDirect) window.patternBuilderApplyContractToSelectedDirect(c); } catch (err) { console.warn('Apply saved contract details to selected item failed:', err); }
    render();
    try { populateStandaloneContractEditor(c.id); } catch (err) {}
    status('Saved editable contract details for <' + tagName + '>. Export metadata applied to the selected canvas item.');
    return true;
  }

  function addEditablePropRow(cardEl){
    var list = cardEl && cardEl.querySelector('[data-contract-prop-list]');
    if (!list) return;
    var wrap = document.createElement('div');
    wrap.className = 'row';
    wrap.style.cssText = 'grid-template-columns:1.15fr .8fr 1fr;gap:6px;margin-top:6px;';
    wrap.innerHTML = '<input aria-label="Property name" data-contract-prop-name placeholder="prop name"><select aria-label="Property type" data-contract-prop-type><option>string</option><option>number</option><option>boolean</option><option>url</option><option>enum</option><option>object</option></select><input aria-label="Property default" data-contract-prop-default placeholder="default">';
    list.appendChild(wrap);
  }

  function addEditableSlotRow(cardEl){
    var list = cardEl && cardEl.querySelector('[data-contract-slot-list]');
    if (!list) return;
    var wrap = document.createElement('div');
    wrap.className = 'row';
    wrap.style.cssText = 'grid-template-columns:1fr 1.35fr;gap:6px;margin-top:6px;';
    wrap.innerHTML = '<input aria-label="Slot name" data-contract-slot-name placeholder="slot name"><input aria-label="Slot description" data-contract-slot-description placeholder="description">';
    list.appendChild(wrap);
  }

  function render(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl) return;
    var contracts = getContracts();
    if (!contracts.length) { listEl.innerHTML = '<div class="muted">No saved pattern contracts yet.</div>'; return; }
    function childDisplayName(child, index, contract){
      var props = contract && contract.props ? contract.props : {};
      if (child && child.name) return child.name;
      if (child && child.label) return child.label;
      if (child && child.role) {
        if (child.role === 'name field') return props.nameLabel || 'Name field';
        if (child.role === 'email field') return props.emailLabel || 'Email field';
        if (child.role === 'message field') return props.messageLabel || 'Message field';
        if (child.role === 'submit action') return props.buttonLabel || 'Submit button';
        return child.role;
      }
      if (props) {
        if (index === 0 && props.nameLabel) return props.nameLabel;
        if (index === 1 && props.emailLabel) return props.emailLabel;
        if (index === 2 && props.messageLabel) return props.messageLabel;
        if (index === 3 && props.buttonLabel) return props.buttonLabel;
      }
      return child && child.tag ? child.tag : 'Component';
    }

    function inferChildren(contract){
      if (contract && Array.isArray(contract.children) && contract.children.length) return contract.children;
      var props = contract && contract.props ? contract.props : {};
      if ((contract && (contract.wrapperTag || contract.patternComponent)) === 'spectrum-info-card') {
        return [
          { tag: 'sp-theme', role: 'theme wrapper', name: 'Spectrum theme' },
          ...(props.imageSrc ? [{ tag: 'img', role: 'card media', name: props.imageAlt || 'Card image' }] : []),
          { tag: 'sp-button', role: 'card action', name: props.buttonLabel || 'Card action' }
        ];
      }
      var baseKind = contract && (contract.patternComponent || contract.basePatternComponent || contract.wrapperTag);
      if (baseKind === 'editor-hero' || baseKind === 'hero' || baseKind === 'hero-section') {
        return [
          ...(props.imageSrc ? [{ tag: 'img', role: 'hero media', name: props.imageAlt || 'Hero image' }] : []),
          { tag: 'editor-hero', role: 'hero content', name: props.heading || 'Hero content' }
        ];
      }
      return [
        { tag: 'sp-textfield', role: 'name field', name: props.nameLabel || 'Name field' },
        { tag: 'sp-textfield', role: 'email field', name: props.emailLabel || 'Email field' },
        { tag: 'sp-textfield', role: 'message field', name: props.messageLabel || 'Message field' },
        { tag: 'sp-button', role: 'submit action', name: props.buttonLabel || 'Submit button' }
      ];
    }

    listEl.innerHTML = contracts.map(function(c, index){
      var childList = inferChildren(c);
      var children = childList.map(function(child, childIndex){ return childDisplayName(child, childIndex, c); }).join(', ');
      var saved = c.savedAt ? new Date(c.savedAt).toLocaleString() : '';
      var wrapperTag = c.wrapperTag || c.patternComponent || 'spectrum-contact-section';
      return '<div class="pattern-builder-contract-card" data-pattern-contract-card="' + escAttr(c.id || '') + '" style="border:1px solid var(--border);border-radius:12px;padding:10px;margin:8px 0;background:var(--panel);">' +
        '<strong>' + esc(c.name || c.props?.heading || 'Pattern contract') + '</strong>' +
        '<div class="xsmall muted">' + esc(c.type || 'pattern') + '</div>' +
        '<div class="xsmall muted"><strong>Exports as:</strong> <code>&lt;' + esc(wrapperTag) + '&gt;</code></div>' +
        ((c.contract && c.contract.description) ? '<div class="xsmall muted"><strong>Description:</strong> ' + esc(c.contract.description) + '</div>' : '') +
        ((c.contract && Array.isArray(c.contract.exposedProps) && c.contract.exposedProps.length) ? '<div class="xsmall muted"><strong>Props:</strong> ' + esc(c.contract.exposedProps.join(', ')) + '</div>' : '') +
        ((c.contract && Array.isArray(c.contract.slots) && c.contract.slots.length) ? '<div class="xsmall muted"><strong>Slots:</strong> ' + esc(c.contract.slots.join(', ')) + '</div>' : '') +
        '<div class="xsmall muted"><strong>Includes:</strong> ' + esc(children) + '</div>' +
        renderEditableContractDetails(c) +
        (saved ? '<div class="xsmall muted">Saved: ' + esc(saved) + '</div>' : '') +
        '<button class="btn primary" type="button" style="margin-top:8px;" data-pattern-builder-add-saved="' + escAttr(c.id || '') + '">Add saved pattern to canvas</button>' +
        '<button class="btn" type="button" style="margin-top:8px;" data-pattern-builder-generate-wrapper="' + escAttr(c.id || '') + '">Edit Wrapper Contract</button>' +
        '<div class="row" style="margin-top:8px;">' +
          '<button class="btn" type="button" data-pattern-builder-rename="' + escAttr(c.id || '') + '">Rename</button>' +
          '<button class="btn danger" type="button" data-pattern-builder-delete="' + escAttr(c.id || '') + '">Delete</button>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  function saveNewContract(contract){
    var contracts = getContracts();
    contract = contract || contactContract();

    // Multi-pattern behavior: each Capture/Save creates a separate library item.
    // Older builds used one fixed id and overwrote the previous pattern. This keeps
    // every captured assembly available as Pattern A, Pattern B, Pattern C, etc.
    contract.id = uniquePatternId(contract);
    contract.name = nextPatternName(contract.name || 'Spectrum Contact Section', contracts);
    contract.savedAt = new Date().toISOString();

    contracts.unshift(contract);
    saveContracts(contracts);
    setLastCapturedPatternId(contract.id);
    render();
    return contract;
  }

  window.patternBuilderAddContact = function(){
    if (window.patternBuilderAddContactDirect) { window.patternBuilderAddContactDirect(); status('Added Contact Section to canvas.'); return; }
    var btn = document.getElementById('leftSpectrumContactSectionPlugin');
    if (btn) { btn.click(); status('Clicked the existing Adobe Spectrum Contact Section palette action.'); }
    else status('Could not find the Contact Section palette action.');
  };

  window.patternBuilderSaveContact = function(){
    var contract = (window.patternBuilderCaptureSelectedPatternDirect && window.patternBuilderCaptureSelectedPatternDirect()) || (window.patternBuilderCaptureSelectedContactDirect && window.patternBuilderCaptureSelectedContactDirect()) || contactContract();
    saveNewContract(contract);
    status(contract.props ? 'Saved selected Contact Section edits as a new reusable pattern.' : 'Saved Contact Section as a new reusable pattern.');
  };

  window.patternBuilderCaptureSelected = function(){
    var before = getContracts().length;
    window.patternBuilderSaveContact();
    var latest = getLastCapturedContract();
    if (latest) status('Captured the current assembly as a new reusable pattern: ' + (latest.name || 'Pattern') + '. You can now generate a wrapper contract from it.');
    else status('Capture did not create a saved pattern. Select a canvas assembly and try again.');
  };

  window.patternBuilderAddSavedToCanvas = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || contracts[0] || null;
    if (!contract) { status('No saved pattern contract was found. Capture the Contact Section first.'); return false; }

    if (typeof window.patternBuilderAddPatternDirect === 'function') {
      var added = window.patternBuilderAddPatternDirect(contract);
      if (added) { status('Added saved pattern to canvas.'); return true; }
    }

    var btn = document.getElementById('leftSpectrumContactSectionPlugin');
    if (btn) { btn.click(); status('Added saved pattern to canvas using the palette fallback.'); return true; }
    status('Could not find the Contact Section action to add the saved pattern.');
    return false;
  };

  window.patternBuilderRenameContract = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || null;
    if (!contract) { status('Pattern contract not found.'); return false; }
    var next = prompt('Rename saved pattern:', contract.name || 'Pattern contract');
    if (next == null) return false;
    next = String(next).trim();
    if (!next) { status('Rename cancelled: pattern name cannot be blank.'); return false; }
    contract.name = next;
    contract.updatedAt = new Date().toISOString();
    saveContracts(contracts);
    render();
    status('Renamed saved pattern to "' + next + '".');
    return true;
  };

  function cloneContractForWrapper(contract){
    return JSON.parse(JSON.stringify(contract || {}));
  }

  function applyWrapperPrompts(contract, opts){
    opts = opts || {};
    contract = cloneContractForWrapper(contract);
    var basePattern = contract.patternComponent || contract.basePatternComponent || contract.wrapperTag || 'spectrum-contact-section';
    var defaultName = contract.wrapperName || contract.name || (contract.props && contract.props.heading) || 'Custom Pattern Component';
    var wrapperName = prompt('Wrapper component name:', defaultName);
    if (wrapperName == null) return null;
    wrapperName = String(wrapperName).trim();
    if (!wrapperName) { status('Wrapper name cannot be blank.'); return null; }
    var suggestedTag = titleToTag(wrapperName, basePattern || 'custom-pattern-component');
    var priorCustomTag = contract.wrapperTag && contract.wrapperTag !== basePattern ? contract.wrapperTag : '';
    var wrapperTag = prompt('Custom element tag name. Must include a hyphen:', priorCustomTag || suggestedTag);
    if (wrapperTag == null) return null;
    wrapperTag = slugifyWrapperTag(wrapperTag, suggestedTag);
    if (!wrapperTag || wrapperTag.indexOf('-') === -1) { status('Wrapper tag must include a hyphen, like hero-banner.'); return null; }
    var description = prompt('Short description for developer handoff:', contract.description || (contract.contract && contract.contract.description) || ('Generated wrapper for ' + wrapperName));
    if (description == null) description = contract.description || (contract.contract && contract.contract.description) || '';

    var currentExposedProps = (contract.contract && Array.isArray(contract.contract.exposedProps) && contract.contract.exposedProps.length)
      ? contract.contract.exposedProps
      : defaultContractPropsForBase(contract);
    var exposedPropsText = prompt('Exposed properties, comma-separated:', currentExposedProps.join(', '));
    if (exposedPropsText == null) exposedPropsText = currentExposedProps.join(', ');
    var exposedProps = splitCsv(exposedPropsText);

    var currentSlots = (contract.contract && Array.isArray(contract.contract.slots) && contract.contract.slots.length)
      ? contract.contract.slots
      : defaultSlotsForBase(contract);
    var slotsText = prompt('Slots, comma-separated:', currentSlots.join(', '));
    if (slotsText == null) slotsText = currentSlots.join(', ');
    var slots = splitCsv(slotsText);

    // Preserve the base pattern renderer, but let the exported custom element tag be designer-controlled.
    contract.basePatternComponent = basePattern;
    contract.patternComponent = basePattern === 'spectrum-info-card' ? 'spectrum-info-card' : (basePattern === 'spectrum-contact-section' ? 'spectrum-contact-section' : (basePattern === 'editor-hero' || basePattern === 'hero' || basePattern === 'hero-section' ? 'editor-hero' : basePattern));
    contract.wrapperTag = wrapperTag;
    contract.wrapperName = wrapperName;
    contract.name = wrapperName;
    contract.description = String(description || '').trim();
    contract.generatedWrapperContract = true;
    contract.updatedAt = new Date().toISOString();
    contract.savedAt = contract.savedAt || new Date().toISOString();
    contract.editableFields = contract.editableFields || [];
    contract.exportIntent = 'Export this saved pattern as a custom web component wrapper using the designer-specified tag.';
    contract.props = contract.props || {};
    contract.props.__wrapperTag = wrapperTag;
    contract.props.__wrapperName = wrapperName;
    contract.props.__wrapperDescription = contract.description;
    contract.contract = {
      componentName: wrapperName,
      tagName: wrapperTag,
      description: contract.description,
      exposedProps: exposedProps,
      slots: slots,
      events: []
    };
    contract.props.__contractProps = exposedProps.join(',');
    contract.props.__contractSlots = slots.join(',');
    contract.props.__contractDescription = contract.description;
    if (opts.newId) contract.id = uniquePatternId(contract);
    return contract;
  }

  window.patternBuilderGenerateWrapperContract = function(id){
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    var savedContract = index >= 0 ? contracts[index] : null;
    if (!savedContract) { status('Pattern contract not found.'); return false; }

    // AB fix: a button inside a saved pattern card must use THAT saved pattern only.
    // It must not silently reuse the first/demo pattern or a stale canvas selection.
    var updated = applyWrapperPrompts(savedContract, { newId: false });
    if (!updated) return false;
    contracts[index] = updated;
    saveContracts(contracts);
    render();
    status('Generated wrapper contract from saved pattern "' + (updated.name || 'Pattern') + '": <' + updated.wrapperTag + '>.');
    return true;
  };

  window.patternBuilderGenerateWrapperFromSelected = function(){
    var selectedContract = null;
    try {
      if (typeof window.patternBuilderCaptureSelectedPatternDirect === 'function') {
        selectedContract = window.patternBuilderCaptureSelectedPatternDirect();
      }
    } catch (err) { selectedContract = null; }

    // AC fix: if the button loses the canvas selection, use the most recently captured
    // saved pattern instead of falling back to stale/demo data. This supports the
    // designer workflow: Capture Selected Assembly -> Generate Wrapper From Selected.
    if (!selectedContract || !selectedContract.props) {
      selectedContract = getLastCapturedContract();
    }

    if (!selectedContract || !selectedContract.props) {
      status('Select and capture the canvas component/pattern first, then generate the wrapper.');
      return false;
    }

    var generated = applyWrapperPrompts(selectedContract, { newId: true });
    if (!generated) return false;
    var contracts = getContracts();
    contracts.unshift(generated);
    saveContracts(contracts);
    setLastCapturedPatternId(generated.id);
    render();
    status('Generated wrapper contract from the captured/selected assembly: <' + generated.wrapperTag + '>.');
    return true;
  };

  window.patternBuilderDeleteContract = function(id){
    var contracts = getContracts();
    var contract = contracts.filter(function(item){ return item && item.id === id; })[0] || null;
    if (!contract) { status('Pattern contract not found.'); return false; }
    if (!confirm('Delete saved pattern "' + (contract.name || 'Pattern contract') + '"?')) return false;
    saveContracts(contracts.filter(function(item){ return item && item.id !== id; }));
    render();
    status('Deleted saved pattern.');
    return true;
  };


  function ensureStandaloneContractEditorPanel(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl) return null;
    var panel = document.getElementById('patternBuilderContractEditorPanel');
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = 'patternBuilderContractEditorPanel';
    panel.className = 'group pattern-builder-workflow';
    panel.style.marginTop = '12px';
    panel.style.border = '2px solid var(--brand)';
    panel.innerHTML = '' +
      '<h4 style="margin:0 0 8px;">Contract Editor</h4>' +
      '<div class="hint">Select a saved pattern, then edit the wrapper contract metadata developers will see in export and handoff.</div>' +
      '<label>Saved pattern</label>' +
      '<select id="patternContractEditorSelect"></select>' +
      '<label style="margin-top:8px;">Component name</label>' +
      '<input id="patternContractEditorName" placeholder="Hero Banner">' +
      '<label style="margin-top:8px;">Tag name</label>' +
      '<input id="patternContractEditorTag" placeholder="hero-banner-section">' +
      '<label style="margin-top:8px;">Description</label>' +
      '<textarea id="patternContractEditorDescription" placeholder="Short developer-facing description" style="min-height:56px;"></textarea>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Properties</div>' +
      '<div class="xsmall muted">One property per row: name, type, default value.</div>' +
      '<div id="patternContractEditorProps"></div>' +
      '<button class="btn" type="button" id="patternContractEditorAddProp" style="margin-top:8px;">Add Property</button>' +
      '<div style="margin-top:10px;font-weight:800;font-size:12px;">Slots</div>' +
      '<div class="xsmall muted">One slot per row: slot name and description.</div>' +
      '<div id="patternContractEditorSlots"></div>' +
      '<button class="btn" type="button" id="patternContractEditorAddSlot" style="margin-top:8px;">Add Slot</button>' +
      '<button class="btn primary" type="button" id="patternContractEditorSave" style="margin-top:10px;">Save Contract Details</button>' +
      '<div class="xsmall muted" id="patternContractEditorStatus" style="margin-top:8px;">Ready.</div>';
    listEl.insertAdjacentElement('afterend', panel);
    bindStandaloneContractEditorPanel(panel);
    return panel;
  }

  function editorSelectValue(){
    var el = document.getElementById('patternContractEditorSelect');
    return el ? el.value : '';
  }

  function addEditorPropRow(item){
    var root = document.getElementById('patternContractEditorProps');
    if (!root) return;
    item = item || { name:'', type:'string', defaultValue:'' };
    var row = document.createElement('div');
    row.className = 'row';
    row.style.gridTemplateColumns = '1.15fr .8fr 1fr auto';
    row.style.gap = '6px';
    row.style.marginTop = '6px';
    row.innerHTML = '' +
      '<input data-standalone-prop-name placeholder="prop name" value="' + escAttr(item.name || '') + '">' +
      '<select data-standalone-prop-type>' + ['string','number','boolean','url','enum','object'].map(function(type){ return '<option value="' + escAttr(type) + '"' + (item.type === type ? ' selected' : '') + '>' + esc(type) + '</option>'; }).join('') + '</select>' +
      '<input data-standalone-prop-default placeholder="default" value="' + escAttr(item.defaultValue || '') + '">' +
      '<button class="btn danger" type="button" data-standalone-remove-row style="width:auto;padding:6px 8px;">×</button>';
    root.appendChild(row);
  }

  function addEditorSlotRow(item){
    var root = document.getElementById('patternContractEditorSlots');
    if (!root) return;
    item = item || { name:'', description:'' };
    var row = document.createElement('div');
    row.className = 'row';
    row.style.gridTemplateColumns = '1fr 1.35fr auto';
    row.style.gap = '6px';
    row.style.marginTop = '6px';
    row.innerHTML = '' +
      '<input data-standalone-slot-name placeholder="slot name" value="' + escAttr(item.name || '') + '">' +
      '<input data-standalone-slot-description placeholder="description" value="' + escAttr(item.description || '') + '">' +
      '<button class="btn danger" type="button" data-standalone-remove-row style="width:auto;padding:6px 8px;">×</button>';
    root.appendChild(row);
  }

  function populateStandaloneContractEditor(selectedId){
    ensureStandaloneContractEditorPanel();
    var contracts = getContracts();
    var select = document.getElementById('patternContractEditorSelect');
    if (!select) return;
    var currentId = selectedId || select.value || (contracts[0] && contracts[0].id) || '';
    select.innerHTML = contracts.length
      ? contracts.map(function(c){ return '<option value="' + escAttr(c.id || '') + '"' + ((c.id || '') === currentId ? ' selected' : '') + '>' + esc(c.name || c.wrapperName || c.wrapperTag || 'Pattern') + '</option>'; }).join('')
      : '<option value="">No saved patterns yet</option>';
    var c = contracts.filter(function(item){ return item && item.id === (select.value || currentId); })[0] || null;
    var statusEl = document.getElementById('patternContractEditorStatus');
    var propsRoot = document.getElementById('patternContractEditorProps');
    var slotsRoot = document.getElementById('patternContractEditorSlots');
    if (!c) {
      ['patternContractEditorName','patternContractEditorTag','patternContractEditorDescription'].forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
      if (propsRoot) propsRoot.innerHTML = '';
      if (slotsRoot) slotsRoot.innerHTML = '';
      if (statusEl) statusEl.textContent = 'Capture a pattern first.';
      return;
    }
    var contract = c.contract || {};
    var nameEl = document.getElementById('patternContractEditorName');
    var tagEl = document.getElementById('patternContractEditorTag');
    var descEl = document.getElementById('patternContractEditorDescription');
    if (nameEl) nameEl.value = contract.componentName || c.wrapperName || c.name || c.props?.heading || 'Pattern Component';
    if (tagEl) tagEl.value = contract.tagName || c.wrapperTag || c.patternComponent || titleToTag(c.name || c.props?.heading || 'pattern-component', 'custom-pattern-component');
    if (descEl) descEl.value = contract.description || c.description || '';
    if (propsRoot) propsRoot.innerHTML = '';
    normalizePropDefinitions(c).forEach(addEditorPropRow);
    if (propsRoot && !propsRoot.children.length) addEditorPropRow({name:'heading', type:'string', defaultValue:''});
    if (slotsRoot) slotsRoot.innerHTML = '';
    normalizeSlotDefinitions(c).forEach(addEditorSlotRow);
    if (slotsRoot && !slotsRoot.children.length) addEditorSlotRow({name:'content', description:''});
    if (statusEl) statusEl.textContent = 'Editing: ' + (c.name || 'Pattern');
  }

  function saveStandaloneContractEditor(){
    var id = editorSelectValue();
    if (!id) { status('Capture a pattern first.'); return false; }
    var contracts = getContracts();
    var index = contracts.findIndex(function(item){ return item && item.id === id; });
    if (index < 0) { status('Pattern contract not found.'); return false; }
    var c = contracts[index];
    var componentName = (document.getElementById('patternContractEditorName')?.value || '').trim() || c.name || 'Pattern Component';
    var tagName = titleToTag((document.getElementById('patternContractEditorTag')?.value || '').trim() || componentName, 'custom-pattern-component');
    var description = (document.getElementById('patternContractEditorDescription')?.value || '').trim();
    var propDefs = Array.from(document.querySelectorAll('#patternContractEditorProps .row')).map(function(row){
      return {
        name: (row.querySelector('[data-standalone-prop-name]')?.value || '').trim(),
        type: (row.querySelector('[data-standalone-prop-type]')?.value || 'string').trim(),
        defaultValue: (row.querySelector('[data-standalone-prop-default]')?.value || '').trim()
      };
    }).filter(function(item){ return item.name; });
    var slotDefs = Array.from(document.querySelectorAll('#patternContractEditorSlots .row')).map(function(row){
      return {
        name: (row.querySelector('[data-standalone-slot-name]')?.value || '').trim(),
        description: (row.querySelector('[data-standalone-slot-description]')?.value || '').trim()
      };
    }).filter(function(item){ return item.name; });
    c.generatedWrapperContract = true;
    c.wrapperName = componentName;
    c.wrapperTag = tagName;
    c.patternComponent = tagName;
    c.description = description;
    c.contract = c.contract || {};
    c.contract.componentName = componentName;
    c.contract.tagName = tagName;
    c.contract.description = description;
    c.contract.exposedProps = propDefs.map(function(item){ return item.name; });
    c.contract.propDefinitions = propDefs;
    c.contract.slots = slotDefs.map(function(item){ return item.name; });
    c.contract.slotDefinitions = slotDefs;
    c.props = c.props || {};
    c.props.__wrapperTag = tagName;
    c.props.__wrapperName = componentName;
    c.props.__wrapperDescription = description;
    c.props.__contractProps = c.contract.exposedProps.join(',');
    c.props.__contractSlots = c.contract.slots.join(',');
    c.props.__contractDescription = description;
    c.savedAt = new Date().toISOString();
    contracts[index] = c;
    saveContracts(contracts);
    try { if (window.patternBuilderApplyContractToSelectedDirect) window.patternBuilderApplyContractToSelectedDirect(c); } catch (err) { console.warn('Apply standalone contract details to selected item failed:', err); }
    render();
    populateStandaloneContractEditor(id);
    status('Saved editable contract details for <' + tagName + '>. Export metadata applied to the selected canvas item.');
    return true;
  }

  function bindStandaloneContractEditorPanel(panel){
    if (!panel || panel.dataset.contractEditorBound === 'true') return;
    panel.dataset.contractEditorBound = 'true';
    panel.addEventListener('change', function(e){
      if (e.target && e.target.id === 'patternContractEditorSelect') populateStandaloneContractEditor(e.target.value);
    });
    panel.addEventListener('click', function(e){
      var removeBtn = e.target && e.target.closest ? e.target.closest('[data-standalone-remove-row]') : null;
      if (removeBtn) { e.preventDefault(); removeBtn.closest('.row')?.remove(); return; }
      if (e.target && e.target.id === 'patternContractEditorAddProp') { e.preventDefault(); addEditorPropRow(); return; }
      if (e.target && e.target.id === 'patternContractEditorAddSlot') { e.preventDefault(); addEditorSlotRow(); return; }
      if (e.target && e.target.id === 'patternContractEditorSave') { e.preventDefault(); saveStandaloneContractEditor(); return; }
    });
  }

  function bindSavedPatternCardButtons(){
    var listEl = document.getElementById('patternBuilderSavedList');
    if (!listEl || listEl.dataset.pbSavedDelegated === 'true') return;
    listEl.dataset.pbSavedDelegated = 'true';
    listEl.addEventListener('click', function(e){
      var addBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-add-saved]') : null;
      var renameBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-rename]') : null;
      var wrapperBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-generate-wrapper]') : null;
      var deleteBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-delete]') : null;
      var saveDetailsBtn = e.target && e.target.closest ? e.target.closest('[data-pattern-builder-save-contract-details]') : null;
      var addPropBtn = e.target && e.target.closest ? e.target.closest('[data-contract-add-prop]') : null;
      var addSlotBtn = e.target && e.target.closest ? e.target.closest('[data-contract-add-slot]') : null;
      var btn = addBtn || renameBtn || wrapperBtn || deleteBtn || saveDetailsBtn || addPropBtn || addSlotBtn;
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      var cardEl = btn.closest('[data-pattern-contract-card]');
      if (addBtn) window.patternBuilderAddSavedToCanvas(addBtn.getAttribute('data-pattern-builder-add-saved') || '');
      if (renameBtn) window.patternBuilderRenameContract(renameBtn.getAttribute('data-pattern-builder-rename') || '');
      if (wrapperBtn) window.patternBuilderGenerateWrapperContract(wrapperBtn.getAttribute('data-pattern-builder-generate-wrapper') || '');
      if (deleteBtn) window.patternBuilderDeleteContract(deleteBtn.getAttribute('data-pattern-builder-delete') || '');
      if (saveDetailsBtn) saveContractDetails(saveDetailsBtn.getAttribute('data-pattern-builder-save-contract-details') || '', cardEl);
      if (addPropBtn) addEditablePropRow(cardEl);
      if (addSlotBtn) addEditableSlotRow(cardEl);
    }, true);
  }

  window.patternBuilderDownloadContracts = function(){
    var contracts = getContracts();
    var blob = new Blob([JSON.stringify({ version: 'pattern-contracts.v1', contracts: contracts }, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'pattern-contracts.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 500);
    status('Downloaded pattern-contracts.json.');
  };

  function bind(){
    var captureBtn = document.getElementById('patternBuilderCaptureSelectedBtn');
    if (captureBtn && !document.getElementById('patternBuilderGenerateSelectedWrapperBtn')) {
      var selectedWrapperBtn = document.createElement('button');
      selectedWrapperBtn.className = 'btn';
      selectedWrapperBtn.type = 'button';
      selectedWrapperBtn.id = 'patternBuilderGenerateSelectedWrapperBtn';
      selectedWrapperBtn.style.marginTop = '8px';
      selectedWrapperBtn.textContent = 'Generate Wrapper / Contract Editor';
      captureBtn.insertAdjacentElement('afterend', selectedWrapperBtn);
    }
    [['patternBuilderAddContactBtn', window.patternBuilderAddContact], ['patternBuilderSaveContactBtn', window.patternBuilderSaveContact], ['patternBuilderCaptureSelectedBtn', window.patternBuilderCaptureSelected], ['patternBuilderGenerateSelectedWrapperBtn', window.patternBuilderGenerateWrapperFromSelected], ['patternBuilderDownloadContractsBtn', window.patternBuilderDownloadContracts]].forEach(function(pair){
      var el = document.getElementById(pair[0]);
      if (el && el.dataset.pbFallbackBound !== 'true') { el.dataset.pbFallbackBound = 'true'; el.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); pair[1](); }, true); }
    });
    render();
    bindSavedPatternCardButtons();
    populateStandaloneContractEditor();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
