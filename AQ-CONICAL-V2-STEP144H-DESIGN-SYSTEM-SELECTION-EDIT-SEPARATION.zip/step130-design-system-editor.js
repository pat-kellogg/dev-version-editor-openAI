(function(){
  'use strict';
  const ROLES=['surface.default','surface.accent','text.primary','text.muted','radius.default','spacing.sm','spacing.md','spacing.lg'];
  const TEMPLATES={
    'AQ Default':{'surface.default':'#ffffff','surface.accent':'#2563eb','text.primary':'#0f172a','text.muted':'#475569','radius.default':'16px','spacing.sm':'8px','spacing.md':'16px','spacing.lg':'24px'},
    'Brand':{'surface.default':'#b91c1c','surface.accent':'#4f46e5','text.primary':'#ffffff','text.muted':'#ffffff','radius.default':'0px','spacing.sm':'8px','spacing.md':'24px','spacing.lg':'32px'},
    'Ocean Test':{'surface.default':'#006D77','surface.accent':'#FF5DA2','text.primary':'#FFF4A3','text.muted':'#FFFFFF','radius.default':'20px','spacing.sm':'10px','spacing.md':'24px','spacing.lg':'36px'},
    'Shock Test':{'surface.default':'#3B0A45','surface.accent':'#39FF14','text.primary':'#FFFFFF','text.muted':'#FFFFFF','radius.default':'0px','spacing.sm':'12px','spacing.md':'32px','spacing.lg':'48px'},
    'Minimal Test':{'surface.default':'#FFFFFF','surface.accent':'#E5E7EB','text.primary':'#111827','text.muted':'#4B5563','radius.default':'4px','spacing.sm':'8px','spacing.md':'16px','spacing.lg':'24px'}
  };
  let selectedId='', draft=null, editMode=false;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slug=s=>String(s||'design-system').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  function registry(){return window.AQDesignSystemRegistry}
  function uniqueId(name){let base=slug(name),id=base,n=2;while(registry().has(id))id=base+'-'+n++;return id}
  function semanticTokens(system){
    if(!system)return {...TEMPLATES['AQ Default']};
    if(system.id==='aq-default')return {...TEMPLATES['AQ Default']};
    if(system.id==='brand-default')return {...TEMPLATES.Brand};
    const map=(system.metadata&&system.metadata.semanticMapping)||{};
    const out={}; ROLES.forEach(r=>out[r]=(system.tokens||{})[map[r]||r]);
    return Object.assign({...TEMPLATES['AQ Default']},Object.fromEntries(Object.entries(out).filter(([,v])=>v!==undefined)));
  }
  function install(){
    const anchor=document.getElementById('designSystemImportGroup'); if(!anchor||document.getElementById('aqDesignSystemBuilder'))return;
    const box=document.createElement('div'); box.className='group aq-ds-builder'; box.id='aqDesignSystemBuilder';
    box.innerHTML='<div class="aq-ds-builder-head"><div><strong>Design System Workspace</strong><div class="xsmall muted">Add, edit, duplicate, delete, or select the system AQ will apply to newly created components.</div></div><div class="aq-ds-builder-actions"><button class="btn primary" id="aqDsNew" type="button">Add Design System</button></div></div><div class="aq-ds-workspace-status xsmall muted" id="aqDsWorkspaceStatus" aria-live="polite"></div><div class="aq-ds-builder-layout"><div class="aq-ds-builder-list" id="aqDsList"></div><div class="aq-ds-builder-editor" id="aqDsEditor"><div class="aq-ds-builder-empty">Select a design system to review its properties, or add a new one.</div></div></div>';
    anchor.parentNode.insertBefore(box,anchor); document.getElementById('aqDsNew').onclick=newFlow; renderList();
  }
  function renderList(){
    const el=document.getElementById('aqDsList'); if(!el||!registry())return;
    const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';
    const systems=registry().list();
    el.innerHTML=systems.map(s=>'<button type="button" data-id="'+esc(s.id)+'" class="'+(s.id===selectedId?'is-selected ':'')+(s.id===active?'is-active':'')+'"><strong>'+esc(s.name)+'</strong><div class="xsmall muted">'+(s.builtIn?'Built in':'Custom')+' · Version '+esc(s.version||'1.0.0')+'</div><div class="aq-ds-list-status">'+(s.id===active?'Default system':'Available')+'</div></button>').join('');
    el.querySelectorAll('button').forEach(b=>b.onclick=()=>selectSystem(b.dataset.id));
    const activeSystem=systems.find(s=>s.id===active);
    const status=document.getElementById('aqDsWorkspaceStatus');
    if(status)status.innerHTML='<strong>Default design system:</strong> '+esc(activeSystem?activeSystem.name:'AQ Default');
  }
  function defaultProfile(system){const m=system&&system.metadata||{},profiles=Array.isArray(m.profiles)?m.profiles:[];return profiles[0]||{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'}}
  function selectSystem(id){const s=registry().get(id);if(!s)return;const profile=defaultProfile(s);selectedId=id;editMode=false;draft={id:s.id,name:s.name,version:s.version||'1.0.0',description:(s.metadata&&s.metadata.description)||'',builtIn:s.builtIn,tokens:semanticTokens(s),baseTokens:((s.metadata&&s.metadata.baseTokens)||semanticTokens(s)),metadata:{...(s.metadata||{})},profile:{...profile}};renderList();renderEditor()}
  function newFlow(){
    const choices=Object.keys(TEMPLATES).concat(registry().list().filter(s=>!s.builtIn).map(s=>s.name));
    const previous=document.getElementById('aqDsNewDialog');
    if(previous)previous.remove();
    const dialog=document.createElement('dialog');
    dialog.id='aqDsNewDialog';
    dialog.className='aq-ds-new-dialog';
    dialog.innerHTML='<form method="dialog" class="aq-ds-new-dialog-card"><div class="aq-ds-new-dialog-head"><div><strong>New Design System</strong><div class="xsmall muted">Choose a starting point, then name your system.</div></div><button class="btn" value="cancel" type="submit" aria-label="Close">Close</button></div><label class="aq-ds-builder-field"><span>Start from</span><select id="aqDsBaseChoice">'+choices.map(x=>'<option value="'+esc(x)+'">'+esc(x)+'</option>').join('')+'</select></label><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsNewName" type="text" value="My Design System" autocomplete="off"></label><div class="aq-ds-new-dialog-actions"><button class="btn" value="cancel" type="submit">Cancel</button><button class="btn primary" id="aqDsCreateNew" value="default" type="button">Create</button></div></form>';
    document.body.appendChild(dialog);
    const select=dialog.querySelector('#aqDsBaseChoice');
    const nameInput=dialog.querySelector('#aqDsNewName');
    const create=dialog.querySelector('#aqDsCreateNew');
    const syncCreateState=()=>{create.disabled=!nameInput.value.trim();};
    nameInput.addEventListener('input',syncCreateState);
    create.addEventListener('click',()=>{
      const choice=select.value;
      let tokens=TEMPLATES[choice];
      if(!tokens){const existing=registry().list().find(s=>s.name.toLowerCase()===String(choice).toLowerCase());tokens=semanticTokens(existing)}
      tokens={...(tokens||TEMPLATES['AQ Default'])};
      const name=nameInput.value.trim();
      if(!name){nameInput.focus();return}
      selectedId='';editMode=true;draft={id:uniqueId(name),name,version:'1.0.0',description:'',builtIn:false,isNew:true,tokens,baseTokens:{...tokens},metadata:{},profile:{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'}};
      dialog.close();dialog.remove();renderList();renderEditor();
    });
    dialog.addEventListener('close',()=>dialog.remove(),{once:true});
    syncCreateState();
    dialog.showModal();
    setTimeout(()=>nameInput.select(),0);
  }
  function field(label,key,type='text'){
    const value=draft.tokens[key];
    if(type==='color')return '<label class="aq-ds-builder-field"><span>'+label+'</span><div class="aq-ds-color-row"><input data-token="'+key+'" type="text" value="'+esc(value)+'"><input data-color="'+key+'" type="color" value="'+esc(/^#[0-9a-f]{6}$/i.test(value)?value:'#000000')+'"></div></label>';
    return '<label class="aq-ds-builder-field"><span>'+label+'</span><input data-token="'+key+'" type="text" value="'+esc(value)+'"></label>';
  }
  function renderEditor(){
    const el=document.getElementById('aqDsEditor');if(!el||!draft)return;
    const activeId=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';
    const isActive=draft.id===activeId;
    if(!editMode&&!draft.isNew){
      el.innerHTML='<div class="aq-ds-editor-heading"><div><strong>'+esc(draft.name)+'</strong><div class="xsmall muted">'+(draft.builtIn?'Built-in system':'Custom design system')+' · Version '+esc(draft.version)+'</div></div><span class="aq-ds-readiness">Ready</span></div><div class="aq-ds-selection-summary"><div><span>Profile</span><strong>'+esc(draft.profile.name||'Default')+'</strong></div><div><span>Density</span><strong>'+esc(draft.profile.density||'comfortable')+'</strong></div><div><span>Typography</span><strong>'+esc(draft.profile.typographyScale||'standard')+'</strong></div><div><span>Corners</span><strong>'+esc(draft.profile.cornerTreatment||'system')+'</strong></div></div>'+(draft.description?'<p class="muted aq-ds-selection-description">'+esc(draft.description)+'</p>':'')+'<div class="aq-ds-builder-preview" id="aqDsPreview"><div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">Profile Preview</div><h3 style="margin:8px 0">Professional Plan</h3><p class="muted">A governed component using this design system.</p><div style="font-size:28px;font-weight:700;margin:12px 0">$49 <span class="muted" style="font-size:14px">per month</span></div><button type="button">Subscribe</button></div><div class="aq-ds-builder-footer"><button class="btn '+(isActive?'':'primary')+'" id="aqDsActivate" type="button" '+(isActive?'disabled aria-pressed="true"':'')+'>'+(isActive?'Currently Applied':'Use This System')+'</button>'+(draft.builtIn?'<button class="btn" id="aqDsDuplicate" type="button">Duplicate to Customize</button>':'<button class="btn" id="aqDsEdit" type="button">Edit Selected System</button><button class="btn" id="aqDsDuplicate" type="button">Duplicate</button>')+'</div>';
      const activate=document.getElementById('aqDsActivate');if(activate&&!isActive)activate.onclick=()=>{if(window.AQActiveDesignSystem&&window.AQActiveDesignSystem.setActiveSystem){window.AQActiveDesignSystem.setActiveSystem(draft.id,{source:'design-system-workspace'});renderList();renderEditor();}};
      const edit=document.getElementById('aqDsEdit');if(edit)edit.onclick=()=>{editMode=true;renderEditor()};
      document.getElementById('aqDsDuplicate').onclick=duplicate;preview();return;
    }
    const editable=!draft.builtIn;
    el.innerHTML='<div class="aq-ds-editor-heading"><div><strong>'+(draft.isNew?'Add Design System':'Edit '+esc(draft.name))+'</strong><div class="xsmall muted">'+(draft.isNew?'Define the new system, then save it.':'Change this custom design system.')+'</div></div><span class="aq-ds-readiness">Ready</span></div><div class="aq-ds-builder-grid"><label class="aq-ds-builder-field"><span>Name</span><input id="aqDsName" type="text" value="'+esc(draft.name)+'" '+(!editable?'disabled':'')+'></label><label class="aq-ds-builder-field"><span>Version</span><input id="aqDsVersion" type="text" value="'+esc(draft.version)+'" '+(!editable?'disabled':'')+'></label></div><label class="aq-ds-builder-field" style="margin-top:10px"><span>Description</span><textarea id="aqDsDescription" rows="2" '+(!editable?'disabled':'')+'>'+esc(draft.description)+'</textarea></label><h4>Design System Profile</h4><div class="aq-ds-builder-grid"><label class="aq-ds-builder-field"><span>Profile name</span><input id="aqDsProfileName" type="text" value="'+esc(draft.profile.name)+'" '+(!editable?'disabled':'')+'></label><label class="aq-ds-builder-field"><span>Density</span><select id="aqDsProfileDensity" '+(!editable?'disabled':'')+'><option value="compact" '+(draft.profile.density==='compact'?'selected':'')+'>Compact</option><option value="comfortable" '+(draft.profile.density==='comfortable'?'selected':'')+'>Comfortable</option><option value="spacious" '+(draft.profile.density==='spacious'?'selected':'')+'>Spacious</option></select></label><label class="aq-ds-builder-field"><span>Typography scale</span><select id="aqDsProfileType" '+(!editable?'disabled':'')+'><option value="compact" '+(draft.profile.typographyScale==='compact'?'selected':'')+'>Compact</option><option value="standard" '+(draft.profile.typographyScale==='standard'?'selected':'')+'>Standard</option><option value="large" '+(draft.profile.typographyScale==='large'?'selected':'')+'>Large</option></select></label><label class="aq-ds-builder-field"><span>Corner treatment</span><select id="aqDsProfileCorners" '+(!editable?'disabled':'')+'><option value="system" '+(draft.profile.cornerTreatment==='system'?'selected':'')+'>Use system radius</option><option value="square" '+(draft.profile.cornerTreatment==='square'?'selected':'')+'>Square</option><option value="rounded" '+(draft.profile.cornerTreatment==='rounded'?'selected':'')+'>Rounded</option></select></label></div><label class="aq-ds-builder-field" style="margin-top:10px"><span>Profile description</span><textarea id="aqDsProfileDescription" rows="2" '+(!editable?'disabled':'')+'>'+esc(draft.profile.description)+'</textarea></label><h4>Core properties</h4><div class="aq-ds-builder-grid">'+field('Surface','surface.default','color')+field('Accent / action','surface.accent','color')+field('Primary text','text.primary','color')+field('Muted text','text.muted','color')+'</div><h4>Corners and spacing</h4><div class="aq-ds-builder-grid">'+field('Corner radius','radius.default')+field('Small spacing','spacing.sm')+field('Medium spacing','spacing.md')+field('Large spacing','spacing.lg')+'</div><div class="aq-ds-builder-preview" id="aqDsPreview"><div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">Profile Preview</div><h3 style="margin:8px 0">Professional Plan</h3><p class="muted">A governed component using this design system.</p><div style="font-size:28px;font-weight:700;margin:12px 0">$49 <span class="muted" style="font-size:14px">per month</span></div><button type="button">Subscribe</button></div><div class="aq-ds-builder-footer"><button class="btn primary" id="aqDsSave" type="button">Save Changes</button><button class="btn" id="aqDsCancel" type="button">Cancel</button>'+(draft.isNew?'':'<button class="btn" id="aqDsDuplicate" type="button">Duplicate</button><button class="btn" id="aqDsExport" type="button">Export JSON</button><button class="btn" id="aqDsDelete" type="button">Delete</button>')+'</div>';
    el.querySelectorAll('[data-token]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.token]=i.value;const c=el.querySelector('[data-color="'+i.dataset.token+'"]');if(c&&/^#[0-9a-f]{6}$/i.test(i.value))c.value=i.value;preview()}});
    el.querySelectorAll('[data-color]').forEach(i=>{i.disabled=!editable;i.oninput=()=>{draft.tokens[i.dataset.color]=i.value;el.querySelector('[data-token="'+i.dataset.color+'"]').value=i.value;preview()}});
    document.getElementById('aqDsSave').onclick=save;
    document.getElementById('aqDsCancel').onclick=()=>{if(draft.isNew){selectedId='';draft=null;editMode=false;renderList();el.innerHTML='<div class="aq-ds-builder-empty">Select a design system or create a new one.</div>';}else selectSystem(draft.id)};
    if(!draft.isNew){document.getElementById('aqDsDuplicate').onclick=duplicate;document.getElementById('aqDsExport').onclick=exportJson;document.getElementById('aqDsDelete').onclick=remove}
    preview();
  }
  function preview(){const p=document.getElementById('aqDsPreview');if(!p)return;p.style.setProperty('--aq-preview-surface',draft.tokens['surface.default']);p.style.setProperty('--aq-preview-accent',draft.tokens['surface.accent']);p.style.setProperty('--aq-preview-primary',draft.tokens['text.primary']);p.style.setProperty('--aq-preview-muted',draft.tokens['text.muted']);p.style.setProperty('--aq-preview-radius',draft.tokens['radius.default']);p.style.padding=draft.tokens['spacing.md']}
  function payload(){const profile={id:(draft.profile&&draft.profile.id)||'default',name:(document.getElementById('aqDsProfileName')||{}).value?.trim()||'Default',description:(document.getElementById('aqDsProfileDescription')||{}).value?.trim()||'',density:(document.getElementById('aqDsProfileDensity')||{}).value||'comfortable',typographyScale:(document.getElementById('aqDsProfileType')||{}).value||'standard',cornerTreatment:(document.getElementById('aqDsProfileCorners')||{}).value||'system'};return{id:draft.id,name:document.getElementById('aqDsName').value.trim(),version:document.getElementById('aqDsVersion').value.trim()||'1.0.0',tokens:{...draft.tokens},metadata:{...(draft.metadata||{}),description:document.getElementById('aqDsDescription').value.trim(),baseTokens:{...draft.baseTokens},profiles:[profile],defaultProfileId:profile.id}}}
  function save(){try{const data=payload();let rec;if(draft.isNew)rec=registry().importFromObject(data,{fallbackName:data.name+'.json'});else rec=registry().replaceImported(draft.id,data,{useImportedName:true});selectedId=rec.id;draft.isNew=false;editMode=false;selectSystem(rec.id);if(window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId&&window.AQActiveDesignSystem.getActiveId()===rec.id)window.AQActiveDesignSystem.setActiveSystem(rec.id,{source:'design-system-editor-save'});if(typeof window.renderImportedDesignSystemRegistry==='function')window.renderImportedDesignSystemRegistry();alert('Design system saved.')}catch(e){alert('Could not save: '+e.message)}}
  function duplicate(){
    const name=window.prompt('Name the duplicate:',draft.name+' Copy');
    if(!name||!name.trim())return;
    try{
      const originalId=draft.id;
      const originalRecord=registry().get(originalId);
      if(!originalRecord)throw new Error('The original design system could not be found.');
      const source=payload();
      const copyName=name.trim();
      const copyProfile={...((source.metadata&&Array.isArray(source.metadata.profiles)&&source.metadata.profiles[0])||draft.profile||{id:'default',name:'Default',description:'Standard component presentation for this design system.',density:'comfortable',typographyScale:'standard',cornerTreatment:'system'})};
      const copyId=uniqueId(copyName+'-copy');
      if(copyId===originalId)throw new Error('AQ could not create a separate identity for the duplicate.');
      const copy={
        id:copyId,
        name:copyName,
        version:source.version||'1.0.0',
        tokens:{...(source.tokens||draft.tokens)},
        metadata:{...(source.metadata||{}),description:(source.metadata&&source.metadata.description)||draft.description||'',baseTokens:{...(source.tokens||draft.tokens)},profiles:[copyProfile],defaultProfileId:copyProfile.id||'default',duplicatedFromId:originalId,duplicatedAt:new Date().toISOString()}
      };
      const rec=registry().importFromObject(copy,{fallbackName:copyName+'.json'});
      if(!registry().has(originalId)){
        registry().importFromObject(originalRecord,{fallbackName:originalRecord.name+'.json'});
      }
      if(!registry().has(originalId)||!registry().has(rec.id)||rec.id===originalId){
        throw new Error('Duplicate integrity check failed; both systems were not preserved.');
      }
      if(typeof window.renderImportedDesignSystemRegistry==='function')window.renderImportedDesignSystemRegistry();
      selectedId=rec.id;
      editMode=false;
      selectSystem(rec.id);
      alert('Design system duplicated and saved. The original was preserved.');
    }catch(e){alert('Could not duplicate: '+e.message)}
  }
  function exportJson(){const data=payload();const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=slug(data.name)+'-'+data.version+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
  function remove(){if(!confirm('Delete '+draft.name+'?'))return;const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'';if(active===draft.id){alert('Activate another system before deleting this one.');return}registry().remove(draft.id);selectedId='';draft=null;editMode=false;renderList();document.getElementById('aqDsEditor').innerHTML='<div class="aq-ds-builder-empty">Select a design system or create a new one.</div>'}
  document.addEventListener('DOMContentLoaded',()=>{install();const btn=document.getElementById('designSystemBtn');if(btn)btn.addEventListener('click',()=>setTimeout(()=>{install();renderList();if(!selectedId&&registry()){const active=window.AQActiveDesignSystem&&window.AQActiveDesignSystem.getActiveId?window.AQActiveDesignSystem.getActiveId():'aq-default';selectSystem(active);}},0));});
})();
