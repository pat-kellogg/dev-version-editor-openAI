Open index.html with app.js, styles.css, and component-contracts-sidecar.json in the same folder. This build adds read-only token binding display for the imported contract POC.
