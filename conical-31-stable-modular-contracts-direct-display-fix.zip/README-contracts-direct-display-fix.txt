This package makes the Developer Handoff > Component Contracts panel display a direct embedded fallback list if local sidecar JSON loading is blocked. No canvas/rendering behavior is changed.
