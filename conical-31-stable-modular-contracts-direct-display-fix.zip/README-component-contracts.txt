Component Contracts Sidecar

This package includes component-contracts-sidecar.json as a separate metadata file.
No editor UI, canvas behavior, Delete/Undo behavior, or export behavior has been changed.

Next step after testing: add a hidden app.js loader that reads this JSON into memory.


Update: component contracts are now embedded as a local-file fallback, so the Developer Handoff tab can show contracts even when index.html is opened directly from disk.
