(() => {
  'use strict';

  function createSection(name = 'Section') {
    return {
      id: `section-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, items: [],
      rootTag: 'section', layout: 'stack', gap: 16, padding: 24,
      background: '#ffffff', backgroundMode: 'solid', backgroundGradientStart: '#2563eb', backgroundGradientEnd: '#7c3aed', backgroundGradientAngle: 135, textColor: '#172033', borderColor: '#cbd5e1', radius: 12,
      rootWrap: 'nowrap', rootJustify: 'flex-start', rootAlign: 'stretch',
      gridColumns: 2, gridPattern: 'equal', responsiveStack: true
    };
  }
  const firstSection = createSection('Section 1');
  const state = { sections:[firstSection], activeSectionId:firstSection.id, selectedId:null, draggedId:null, draggedFrom:null };
  const sectionFields = ['items','rootTag','layout','gap','padding','background','backgroundMode','backgroundGradientStart','backgroundGradientEnd','backgroundGradientAngle','textColor','borderColor','radius','rootWrap','rootJustify','rootAlign','gridColumns','gridPattern','responsiveStack'];
  function activeSection(){ return state.sections.find(section=>section.id===state.activeSectionId)||state.sections[0]; }
  sectionFields.forEach(field=>Object.defineProperty(state,field,{get(){return activeSection()[field]},set(value){activeSection()[field]=value},configurable:true}));

  const defaults = {
    heading: { text: 'Component heading', className: 'component-title' },
    paragraph: { text: 'Add a short description for this component.', className: 'component-description' },
    image: { src: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='640' height='360' viewBox='0 0 640 360'%3E%3Crect width='640' height='360' fill='%23dbeafe'/%3E%3Crect x='24' y='24' width='592' height='312' rx='18' fill='%23eff6ff' stroke='%232563eb' stroke-width='4'/%3E%3Ctext x='320' y='190' text-anchor='middle' font-family='Arial,sans-serif' font-size='34' fill='%231e3a8a'%3EChoose an image%3C/text%3E%3C/svg%3E", alt: 'Placeholder image', className: 'component-image' },
    button: { text: 'Get started', className: 'component-button' },
    link: { text: 'Learn more', href: '#', className: 'component-link' },
    list: { text: 'First item\nSecond item\nThird item', className: 'component-list' },
    divider: { className: 'component-divider' },
    blockquote: { text: 'Good design makes complex things understandable.', className: 'component-quote' },
    code: { text: 'display: grid', className: 'component-code' },
    pre: { text: '.feature-card {\n  display: grid;\n  gap: 1rem;\n}', className: 'component-code-block' },
    small: { text: 'Last updated August 5, 2026', className: 'component-small-print' },
    mark: { text: 'Highlighted text', className: 'component-highlight' },
    details: { text: 'View additional information\nAdd supporting details here.', className: 'component-details' },
    progress: { text: '65', className: 'component-progress' },
    meter: { text: '82', className: 'component-meter' },
    container: { className: 'component-group' }
  };

  const ids = ['sectionSelect','addSectionBtn','deleteSectionBtn','backgroundModeSelect','backgroundSolidLabel','backgroundGradientControls','backgroundGradientStartInput','backgroundGradientEndInput','backgroundGradientAngleInput','itemBackgroundModeSelect','itemBackgroundSolidLabel','itemBackgroundGradientControls','itemBackgroundGradientStartInput','itemBackgroundGradientEndInput','itemBackgroundGradientAngleInput','palette','builderCanvas','previewFrame','outputCode','propertiesForm','noSelection','selectedType','textInput','srcInput','altInput','hrefInput','classInput','itemBackgroundInput','itemTextColorInput','itemPaddingInput','itemRadiusInput','textFieldLabel','srcFieldLabel','imageFileFieldLabel','imageFileInput','applyImageUrlBtn','altFieldLabel','hrefFieldLabel','deleteBtn','deleteSelectedBtn','copyBtn','copyOutputBtn','downloadBtn','clearBtn','layoutSelect','gapInput','paddingInput','backgroundInput','textColorInput','borderColorInput','radiusInput','rootTagSelect','toast','flexRootControls','gridRootControls','rootWrapSelect','rootJustifySelect','rootAlignSelect','gridColumnsSelect','gridPatternSelect','responsiveStackInput','containerControls','containerDirectionSelect','containerWrapSelect','containerJustifySelect','containerAlignSelect','containerGapInput'];
  const els = Object.fromEntries(ids.map(id => [id, document.getElementById(id)]));

  function uid() { return `item-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`; }
  function escapeHtml(value = '') { return String(value).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c])); }
  function safeClass(value = '') { return String(value).trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'component-item'; }
  function showToast(message) { els.toast.textContent = message; els.toast.classList.add('show'); setTimeout(() => els.toast.classList.remove('show'), 1600); }

  function createItem(type) {
    const base = defaults[type] || {};
    return {
      id: uid(), type, text: base.text || '', src: base.src || '', alt: base.alt || '', href: base.href || '#',
      className: base.className || `component-${type}`, background: '#ffffff', backgroundMode: 'solid', backgroundGradientStart: '#2563eb', backgroundGradientEnd: '#7c3aed', backgroundGradientAngle: 135, textColor: '#172033', padding: 0, radius: 0,
      children: type === 'container' ? [] : undefined,
      containerDirection: 'column', containerWrap: 'nowrap', containerJustify: 'flex-start', containerAlign: 'stretch', containerGap: 12
    };
  }

  function walk(items, callback, parentId = null) {
    for (const item of items) {
      if (callback(item, parentId)) return true;
      if (item.type === 'container' && walk(item.children || [], callback, item.id)) return true;
    }
    return false;
  }
  function findItem(id) {
    let found=null;
    for(const section of state.sections){ if(walk(section.items,item=>{if(item.id===id){found=item;return true}return false})) break; }
    return found;
  }
  function findParentArray(id) {
    for(const section of state.sections){
      if(section.items.some(item=>item.id===id)) return {array:section.items,parentId:null,sectionId:section.id};
      let result=null;
      walk(section.items,item=>{ if(item.type==='container'&&(item.children||[]).some(child=>child.id===id)){result={array:item.children,parentId:item.id,sectionId:section.id};return true} return false; });
      if(result) return result;
    }
    return null;
  }
  function selectedItem() { return findItem(state.selectedId); }
  function removeItem(id) {
    const loc = findParentArray(id); if (!loc) return null;
    const index = loc.array.findIndex(item => item.id === id); if (index < 0) return null;
    return loc.array.splice(index, 1)[0];
  }
  function insertItem(item, targetParentId = null, targetIndex = null) {
    const target = targetParentId ? findItem(targetParentId) : null;
    const array = target && target.type === 'container' ? target.children : state.items;
    if (targetIndex == null || targetIndex < 0 || targetIndex > array.length) array.push(item); else array.splice(targetIndex, 0, item);
  }

  function backgroundValue(target) { return target.backgroundMode === 'gradient' ? `linear-gradient(${Number(target.backgroundGradientAngle) || 0}deg, ${target.backgroundGradientStart}, ${target.backgroundGradientEnd})` : target.background; }
  function inlineStyle(item) { return `background:${backgroundValue(item)};color:${item.textColor};padding:${item.padding}px;border-radius:${item.radius}px;`; }
  function editorContent(item) {
    const common = `class="${escapeHtml(item.className)}" style="${inlineStyle(item)}"`;
    switch (item.type) {
      case 'heading': return `<h2 ${common}>${escapeHtml(item.text)}</h2>`;
      case 'paragraph': return `<p ${common}>${escapeHtml(item.text)}</p>`;
      case 'image': return `<img ${common} src="${escapeHtml(item.src)}" alt="${escapeHtml(item.alt)}">`;
      case 'button': return `<button ${common} type="button">${escapeHtml(item.text)}</button>`;
      case 'link': return `<a ${common} href="${escapeHtml(item.href)}">${escapeHtml(item.text)}</a>`;
      case 'list': return `<ul ${common}>${item.text.split(/\n+/).filter(Boolean).map(v => `<li>${escapeHtml(v.trim())}</li>`).join('')}</ul>`;
      case 'divider': return `<hr ${common}>`;
      case 'blockquote': return `<blockquote ${common}>${escapeHtml(item.text)}</blockquote>`;
      case 'code': return `<code ${common}>${escapeHtml(item.text)}</code>`;
      case 'pre': return `<pre ${common}><code>${escapeHtml(item.text)}</code></pre>`;
      case 'small': return `<small ${common}>${escapeHtml(item.text)}</small>`;
      case 'mark': return `<mark ${common}>${escapeHtml(item.text)}</mark>`;
      case 'details': {
        const lines = String(item.text || '').split(/\n/);
        const summary = lines.shift() || 'View additional information';
        const body = lines.join('\n') || 'Add supporting details here.';
        return `<details ${common} open><summary>${escapeHtml(summary)}</summary><p>${escapeHtml(body)}</p></details>`;
      }
      case 'progress': { const value = Math.max(0, Math.min(100, Number(item.text) || 0)); return `<progress ${common} value="${value}" max="100">${value}%</progress>`; }
      case 'meter': { const value = Math.max(0, Math.min(100, Number(item.text) || 0)); return `<meter ${common} min="0" max="100" value="${value}">${value} out of 100</meter>`; }
      default: return '';
    }
  }

  function attachDragEvents(wrapper, item, parentId, sectionId) {
    wrapper.addEventListener('click', e => { e.stopPropagation(); state.activeSectionId=sectionId; state.selectedId = item.id; render(); });
    wrapper.addEventListener('dragstart', e => {
      state.activeSectionId=sectionId; state.draggedId = item.id; state.draggedFrom = parentId; e.dataTransfer.setData('application/x-builder-item', item.id); e.dataTransfer.effectAllowed = 'move';
    });
    wrapper.addEventListener('dragover', e => e.preventDefault());
    wrapper.addEventListener('drop', e => {
      e.preventDefault(); e.stopPropagation();

      // Palette elements dropped over an existing child must still be added to
      // that child's Container. Without this branch, the child wrapper absorbs
      // the drop and the Container appears to accept only one element.
      const paletteType = e.dataTransfer.getData('text/plain');
      if (paletteType && defaults[paletteType]) {
        if (!parentId) return;
        if (paletteType === 'container') { showToast('Nested Containers are not allowed'); return; }
        const destination = findParentArray(item.id); if (!destination || !destination.parentId) return;
        const child = createItem(paletteType);
        const index = destination.array.findIndex(candidate => candidate.id === item.id);
        destination.array.splice(index + 1, 0, child);
        state.selectedId = child.id; state.draggedId = null; render(); return;
      }

      const draggedId = state.draggedId || e.dataTransfer.getData('application/x-builder-item');
      if (!draggedId || draggedId === item.id) return;
      const moving = findItem(draggedId); if (!moving) return;
      const destination = findParentArray(item.id); if (!destination) return;
      if (moving.type === 'container' && destination.parentId) { showToast('Nested Containers are not allowed'); return; }
      const moved = removeItem(draggedId); if (!moved) return;
      const index = destination.array.findIndex(candidate => candidate.id === item.id);
      destination.array.splice(index, 0, moved); state.draggedId = null; render();
    });
  }

  function makeEditorItem(item, parentId = null, sectionId = state.activeSectionId) {
    const wrapper = document.createElement('div');
    wrapper.className = `builder-item${parentId ? ' nested-item' : ''}${item.id === state.selectedId ? ' selected' : ''}`;
    wrapper.dataset.id = item.id; wrapper.dataset.label = item.type; wrapper.draggable = true;
    attachDragEvents(wrapper, item, parentId, sectionId);
    if (item.type !== 'container') { wrapper.innerHTML = editorContent(item); return wrapper; }

    const shell = document.createElement('div');
    shell.className = 'container-shell';
    shell.style.cssText = inlineStyle(item);
    const zone = document.createElement('div');
    zone.className = 'container-dropzone';
    zone.style.flexDirection = item.containerDirection;
    zone.style.flexWrap = item.containerWrap;
    zone.style.justifyContent = item.containerJustify;
    zone.style.alignItems = item.containerAlign;
    zone.style.gap = `${item.containerGap}px`;
    zone.dataset.containerId = item.id;
    if (!(item.children || []).length) zone.innerHTML = '<div class="container-empty">Drop elements inside this Container</div>';
    else item.children.forEach(child => zone.appendChild(makeEditorItem(child, item.id, sectionId)));
    zone.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); zone.classList.add('drag-over'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
    zone.addEventListener('drop', e => {
      e.preventDefault(); e.stopPropagation(); zone.classList.remove('drag-over');
      const paletteType = e.dataTransfer.getData('text/plain');
      if (paletteType) {
        if (paletteType === 'container') { showToast('Nested Containers are not allowed'); return; }
        const child = createItem(paletteType); item.children.push(child); state.selectedId = child.id; render(); return;
      }
      const draggedId = state.draggedId || e.dataTransfer.getData('application/x-builder-item');
      if (!draggedId || draggedId === item.id) return;
      const moving = findItem(draggedId); if (!moving) return;
      if (moving.type === 'container') { showToast('Nested Containers are not allowed'); return; }
      const moved = removeItem(draggedId); if (!moved) return;
      item.children.push(moved); state.selectedId = moved.id; state.draggedId = null; render();
    });
    shell.appendChild(zone); wrapper.appendChild(shell); return wrapper;
  }

  function configureSectionCanvas(canvas, section) {
    canvas.style.display=section.layout==='grid'?'grid':'flex';
    canvas.style.flexDirection=section.layout==='row'?'row':'column';
    canvas.style.flexWrap=section.rootWrap; canvas.style.justifyContent=section.rootJustify; canvas.style.alignItems=section.rootAlign;
    canvas.style.gridTemplateColumns=section.layout==='grid'?gridTemplate(section):'';
    canvas.style.gap=`${section.gap}px`; canvas.style.background=backgroundValue(section);
    canvas.classList.toggle('show-grid-guides',section.layout==='grid');
  }
  function attachSectionDrop(canvas,section){
    canvas.addEventListener('dragover',e=>{e.preventDefault();e.stopPropagation();canvas.classList.add('drag-over')});
    canvas.addEventListener('dragleave',()=>canvas.classList.remove('drag-over'));
    canvas.addEventListener('drop',e=>{e.preventDefault();e.stopPropagation();canvas.classList.remove('drag-over');state.activeSectionId=section.id;
      const type=e.dataTransfer.getData('text/plain');
      if(type&&defaults[type]){const item=createItem(type);section.items.push(item);state.selectedId=item.id;render();return}
      const draggedId=state.draggedId||e.dataTransfer.getData('application/x-builder-item'); if(!draggedId)return; const moved=removeItem(draggedId); if(!moved)return; section.items.push(moved);state.selectedId=moved.id;state.draggedId=null;render();
    });
    canvas.addEventListener('click',e=>{e.stopPropagation();state.activeSectionId=section.id;state.selectedId=null;render()});
  }
  function renderCanvas(){
    els.builderCanvas.innerHTML='';
    state.sections.forEach(section=>{
      const wrapper=document.createElement('div');wrapper.className=`builder-section${section.id===state.activeSectionId?' active':''}`;wrapper.dataset.sectionId=section.id;
      const header=document.createElement('div');header.className='builder-section-header';const name=document.createElement('span');name.className='builder-section-name';name.textContent=section.name;header.appendChild(name);wrapper.appendChild(header);
      const canvas=document.createElement('div');canvas.className='section-canvas';canvas.setAttribute('aria-label',`${section.name} canvas`);configureSectionCanvas(canvas,section);
      if(section.layout==='grid'){const guides=document.createElement('div');guides.className='grid-guide-layer';guides.setAttribute('aria-hidden','true');guides.style.gridTemplateColumns=gridTemplate(section);guides.style.gap=`${section.gap}px`;for(let i=0;i<section.gridColumns;i+=1){const guide=document.createElement('div');guide.className='grid-guide-cell';guide.innerHTML=`<span>Column ${i+1}</span>`;guides.appendChild(guide)}canvas.appendChild(guides)}
      if(!section.items.length){const empty=document.createElement('div');empty.className='empty-state';empty.textContent='Drag elements here';canvas.appendChild(empty)}else section.items.forEach(item=>canvas.appendChild(makeEditorItem(item,null,section.id)));
      attachSectionDrop(canvas,section);wrapper.appendChild(canvas);wrapper.addEventListener('click',e=>{if(e.target===wrapper||e.target===header||e.target===name){state.activeSectionId=section.id;state.selectedId=null;render()}});els.builderCanvas.appendChild(wrapper);
    });
  }

  function gridTemplate(section = activeSection()) {
    if (section.gridColumns === 2 && section.gridPattern === '1-2') return 'minmax(0,1fr) minmax(0,2fr)';
    if (section.gridColumns === 2 && section.gridPattern === '2-1') return 'minmax(0,2fr) minmax(0,1fr)';
    return `repeat(${section.gridColumns}, minmax(0,1fr))`;
  }
  function generatedCss(){
    const base='.aq-built-component{display:block;width:100%;max-width:100%;min-width:0;box-sizing:border-box}.aq-built-component__surface{box-sizing:border-box;width:100%;max-width:100%;min-width:0;font-family:Arial,sans-serif}.aq-built-component__surface *{box-sizing:border-box}.aq-built-component__surface img{max-width:100%;height:auto;display:block}.aq-built-component__surface button,.aq-built-component__surface a{width:max-content;max-width:100%}.aq-built-component__surface blockquote{margin:0;border-left:4px solid currentColor}.aq-built-component__surface pre{margin:0;max-width:100%;overflow:auto;white-space:pre-wrap}.aq-built-component__surface code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.aq-built-component__surface details>summary{cursor:pointer;font-weight:700}.aq-built-component__surface hr{display:block;width:100%;height:0;margin:0;border:0;border-top:1px solid currentColor;opacity:.45}.aq-built-component__surface progress,.aq-built-component__surface meter{width:100%;max-width:22rem}.aq-built-container{display:flex;min-width:0}.aq-built-container>*{min-width:0}';
    const rules=state.sections.map((section,index)=>{const cls=`.aq-built-component__surface--${index+1}`;const layout=section.layout==='grid'?`display:grid;grid-template-columns:${gridTemplate(section)};`:`display:flex;flex-direction:${section.layout==='row'?'row':'column'};flex-wrap:${section.rootWrap};justify-content:${section.rootJustify};align-items:${section.rootAlign};`;const rule=`${cls}{${layout}gap:${section.gap}px;padding:${section.padding}px;border:1px solid ${section.borderColor};border-radius:${section.radius}px;background:${backgroundValue(section)};color:${section.textColor};}`;const mobile=section.layout==='grid'&&section.responsiveStack?`\n@media (max-width: 640px) { ${cls} { grid-template-columns:minmax(0,1fr); } }`:'';return rule+mobile}).join('\n');return `${base}\n${rules}`;
  }

  function styleAttr(item, forceRadius = false) {
    const values = [];
    if (item.backgroundMode === 'gradient' || item.background !== '#ffffff') values.push(`background:${backgroundValue(item)}`);
    if (item.textColor !== '#172033') values.push(`color:${item.textColor}`);
    if (item.padding) values.push(`padding:${item.padding}px`);
    if (forceRadius || item.radius) values.push(`border-radius:${item.radius}px`);
    return values.length ? ` style="${values.join(';')}"` : '';
  }

  function semanticItem(item, indent = '    ') {
    const cls = safeClass(item.className); const style = styleAttr(item);
    switch (item.type) {
      case 'heading': return `${indent}<h2 class="${cls}" data-aq-role="heading" data-component-region="heading"${style}>${escapeHtml(item.text)}</h2>`;
      case 'paragraph': return `${indent}<p class="${cls}" data-aq-role="description" data-component-region="description"${style}>${escapeHtml(item.text)}</p>`;
      case 'image': return `${indent}<figure class="${cls}-figure" data-aq-role="media" data-component-region="media"><img class="${cls}" src="${escapeHtml(item.src)}" alt="${escapeHtml(item.alt)}" loading="lazy" decoding="async"${styleAttr(item, true)}></figure>`;
      case 'button': return `${indent}<button class="${cls}" data-aq-role="primary-action" data-component-region="primary-action" type="button"${style}>${escapeHtml(item.text)}</button>`;
      case 'link': return `${indent}<a class="${cls}" data-aq-role="secondary-action" data-component-region="secondary-action" href="${escapeHtml(item.href)}"${style}>${escapeHtml(item.text)}</a>`;
      case 'list': return `${indent}<ul class="${cls}" data-aq-role="features" data-component-region="features"${style}>\n${item.text.split(/\n+/).filter(Boolean).map(v => `${indent}  <li data-aq-role="feature-item">${escapeHtml(v.trim())}</li>`).join('\n')}\n${indent}</ul>`;
      case 'divider': return `${indent}<hr class="${cls}" aria-hidden="true"${style}>`;
      case 'blockquote': return `${indent}<blockquote class="${cls}" data-aq-role="quotation" data-component-region="quotation"${style}>${escapeHtml(item.text)}</blockquote>`;
      case 'code': return `${indent}<code class="${cls}" data-aq-role="inline-code" data-component-region="code"${style}>${escapeHtml(item.text)}</code>`;
      case 'pre': return `${indent}<pre class="${cls}" data-aq-role="code-block" data-component-region="code-block"${style}><code>${escapeHtml(item.text)}</code></pre>`;
      case 'small': return `${indent}<small class="${cls}" data-aq-role="supporting-text" data-component-region="supporting-text"${style}>${escapeHtml(item.text)}</small>`;
      case 'mark': return `${indent}<mark class="${cls}" data-aq-role="highlight" data-component-region="highlight"${style}>${escapeHtml(item.text)}</mark>`;
      case 'details': {
        const lines = String(item.text || '').split(/\n/);
        const summary = lines.shift() || 'View additional information';
        const body = lines.join('\n') || 'Add supporting details here.';
        return `${indent}<details class="${cls}" data-aq-role="disclosure" data-component-region="details"${style}>\n${indent}  <summary>${escapeHtml(summary)}</summary>\n${indent}  <p>${escapeHtml(body)}</p>\n${indent}</details>`;
      }
      case 'progress': { const value = Math.max(0, Math.min(100, Number(item.text) || 0)); return `${indent}<progress class="${cls}" data-aq-role="progress" data-component-region="progress" value="${value}" max="100"${style}>${value}%</progress>`; }
      case 'meter': { const value = Math.max(0, Math.min(100, Number(item.text) || 0)); return `${indent}<meter class="${cls}" data-aq-role="measurement" data-component-region="measurement" min="0" max="100" value="${value}"${style}>${value} out of 100</meter>`; }
      case 'container': {
        const flexStyle = [`display:flex`,`flex-direction:${item.containerDirection}`,`flex-wrap:${item.containerWrap}`,`justify-content:${item.containerJustify}`,`align-items:${item.containerAlign}`,`gap:${item.containerGap}px`];
        if (item.backgroundMode === 'gradient' || item.background !== '#ffffff') flexStyle.push(`background:${backgroundValue(item)}`);
        if (item.textColor !== '#172033') flexStyle.push(`color:${item.textColor}`);
        if (item.padding) flexStyle.push(`padding:${item.padding}px`);
        if (item.radius) flexStyle.push(`border-radius:${item.radius}px`);
        const children = (item.children || []).map(child => semanticItem(child, `${indent}  `)).join('\n');
        return `${indent}<div class="${cls} aq-built-container" data-aq-role="content" data-component-region="content" style="${flexStyle.join(';')}">\n${children}\n${indent}</div>`;
      }
      default: return '';
    }
  }

  function generatedHtml(){
    const sections=state.sections.map((section,index)=>{const inner=section.items.map(item=>semanticItem(item)).join('\n\n');let heading='';walk(section.items,item=>{if(item.type==='heading'){heading=item.text;return true}return false});heading=heading||section.name;return `<${section.rootTag} class="aq-built-component aq-built-component--section-${index+1}" data-aq-component="true" data-aq-source="designer" data-aq-intent-version="1" data-aq-section="${index+1}" aria-label="${escapeHtml(heading)}">\n  <div class="aq-built-component__surface aq-built-component__surface--${index+1}" data-aq-role="component-surface">\n${inner}\n  </div>\n</${section.rootTag}>`}).join('\n\n');return `<style>\n${generatedCss()}\n</style>\n\n${sections}`;
  }
  function previewDocument() { return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:#f8fafc}body{padding:24px}</style></head><body>${generatedHtml()}</body></html>`; }

  function renderProperties() {
    const item = selectedItem(); els.noSelection.hidden = !!item; els.propertiesForm.hidden = !item; els.deleteSelectedBtn.disabled = !item;
    if (!item) return;
    els.selectedType.value = item.type; els.textInput.value = item.text || ''; els.srcInput.value = item.src || ''; els.altInput.value = item.alt || ''; els.hrefInput.value = item.href || '#'; els.classInput.value = item.className; els.itemBackgroundInput.value = item.background; els.itemBackgroundModeSelect.value = item.backgroundMode || 'solid'; els.itemBackgroundGradientStartInput.value = item.backgroundGradientStart || '#2563eb'; els.itemBackgroundGradientEndInput.value = item.backgroundGradientEnd || '#7c3aed'; els.itemBackgroundGradientAngleInput.value = item.backgroundGradientAngle ?? 135; els.itemBackgroundSolidLabel.hidden = els.itemBackgroundModeSelect.value === 'gradient'; els.itemBackgroundGradientControls.hidden = els.itemBackgroundModeSelect.value !== 'gradient'; els.itemTextColorInput.value = item.textColor; els.itemPaddingInput.value = item.padding; els.itemRadiusInput.value = item.radius;
    els.textFieldLabel.hidden = !['heading','paragraph','button','link','list','blockquote','code','pre','small','mark','details','progress','meter'].includes(item.type);
    els.srcFieldLabel.hidden = item.type !== 'image'; els.imageFileFieldLabel.hidden = item.type !== 'image'; els.altFieldLabel.hidden = item.type !== 'image'; els.hrefFieldLabel.hidden = item.type !== 'link';
    els.containerControls.hidden = item.type !== 'container';
    if (item.type === 'container') { els.containerDirectionSelect.value = item.containerDirection; els.containerWrapSelect.value = item.containerWrap; els.containerJustifySelect.value = item.containerJustify; els.containerAlignSelect.value = item.containerAlign; els.containerGapInput.value = item.containerGap; }
  }
  function renderRootControls(){const section=activeSection();els.sectionSelect.innerHTML=state.sections.map(item=>`<option value="${item.id}">${escapeHtml(item.name)}</option>`).join('');els.sectionSelect.value=section.id;els.deleteSectionBtn.disabled=state.sections.length<=1;els.layoutSelect.value=section.layout;els.gapInput.value=section.gap;els.paddingInput.value=section.padding;els.textColorInput.value=section.textColor;els.borderColorInput.value=section.borderColor;els.radiusInput.value=section.radius;els.rootTagSelect.value=section.rootTag;els.rootWrapSelect.value=section.rootWrap;els.rootJustifySelect.value=section.rootJustify;els.rootAlignSelect.value=section.rootAlign;els.gridColumnsSelect.value=section.gridColumns;els.gridPatternSelect.value=section.gridPattern;els.responsiveStackInput.checked=section.responsiveStack;els.flexRootControls.hidden=section.layout==='grid';els.gridRootControls.hidden=section.layout!=='grid';els.gridPatternSelect.disabled=section.gridColumns!==2;els.backgroundModeSelect.value=section.backgroundMode||'solid';els.backgroundSolidLabel.hidden=els.backgroundModeSelect.value==='gradient';els.backgroundGradientControls.hidden=els.backgroundModeSelect.value!=='gradient';els.backgroundInput.value=section.background;els.backgroundGradientStartInput.value=section.backgroundGradientStart;els.backgroundGradientEndInput.value=section.backgroundGradientEnd;els.backgroundGradientAngleInput.value=section.backgroundGradientAngle;}
  function render() { renderRootControls(); renderCanvas(); renderProperties(); const html = generatedHtml(); els.outputCode.value = html; els.previewFrame.srcdoc = previewDocument(); }

  function updateSelected(field, value) { const item = selectedItem(); if (!item) return; item[field] = value; render(); }
  function deleteSelected() { if (!state.selectedId) return; removeItem(state.selectedId); state.selectedId = null; render(); showToast('Element deleted'); }

  els.palette.addEventListener('dragstart', e => { const btn = e.target.closest('[data-type]'); if (!btn) return; e.dataTransfer.setData('text/plain', btn.dataset.type); e.dataTransfer.effectAllowed = 'copy'; });

  els.textInput.addEventListener('input', e => updateSelected('text', e.target.value));
  els.srcInput.addEventListener('change', e => updateSelected('src', e.target.value.trim()));
  els.srcInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); updateSelected('src', e.currentTarget.value.trim()); showToast('Image URL applied'); } });
  els.applyImageUrlBtn.addEventListener('click', () => { updateSelected('src', els.srcInput.value.trim()); showToast('Image URL applied'); });
  els.imageFileInput.addEventListener('change', e => {
    const file = e.target.files && e.target.files[0]; const item = selectedItem(); const id = item && item.type === 'image' ? item.id : null;
    if (!file || !id) return; if (!file.type.startsWith('image/')) { showToast('Please choose an image file'); return; }
    const reader = new FileReader(); reader.onload = () => { const target = findItem(id); if (!target) return; target.src = String(reader.result || ''); state.selectedId = id; render(); showToast('Image file added'); els.imageFileInput.value = ''; }; reader.onerror = () => showToast('Could not read image file'); reader.readAsDataURL(file);
  });
  [['altInput','alt'],['hrefInput','href'],['classInput','className'],['itemBackgroundInput','background'],['itemTextColorInput','textColor'],['itemBackgroundGradientStartInput','backgroundGradientStart'],['itemBackgroundGradientEndInput','backgroundGradientEnd']].forEach(([id,field]) => els[id].addEventListener('input', e => updateSelected(field,e.target.value)));
  els.itemBackgroundModeSelect.addEventListener('change', e => updateSelected('backgroundMode', e.target.value));
  els.itemBackgroundGradientAngleInput.addEventListener('input', e => updateSelected('backgroundGradientAngle', Number(e.target.value)));
  [['itemPaddingInput','padding'],['itemRadiusInput','radius'],['containerGapInput','containerGap']].forEach(([id,field]) => els[id].addEventListener('input', e => updateSelected(field,Number(e.target.value))));
  [['containerDirectionSelect','containerDirection'],['containerWrapSelect','containerWrap'],['containerJustifySelect','containerJustify'],['containerAlignSelect','containerAlign']].forEach(([id,field]) => els[id].addEventListener('change', e => updateSelected(field,e.target.value)));
  els.deleteBtn.addEventListener('click', deleteSelected); els.deleteSelectedBtn.addEventListener('click', deleteSelected);

  els.sectionSelect.addEventListener('change',e=>{state.activeSectionId=e.target.value;state.selectedId=null;render()});
  els.addSectionBtn.addEventListener('click',()=>{const section=createSection(`Section ${state.sections.length+1}`);state.sections.push(section);state.activeSectionId=section.id;state.selectedId=null;render();showToast('Section added')});
  els.deleteSectionBtn.addEventListener('click',()=>{if(state.sections.length<=1)return;const index=state.sections.findIndex(section=>section.id===state.activeSectionId);if(index<0)return;state.sections.splice(index,1);const next=state.sections[Math.max(0,index-1)]||state.sections[0];state.activeSectionId=next.id;state.selectedId=null;render();showToast('Section deleted')});
    els.layoutSelect.addEventListener('change', e => { state.layout=e.target.value; render(); });
  els.rootWrapSelect.addEventListener('change', e => { state.rootWrap=e.target.value; render(); });
  els.rootJustifySelect.addEventListener('change', e => { state.rootJustify=e.target.value; render(); });
  els.rootAlignSelect.addEventListener('change', e => { state.rootAlign=e.target.value; render(); });
  els.gridColumnsSelect.addEventListener('change', e => { state.gridColumns=Number(e.target.value); if(state.gridColumns!==2) state.gridPattern='equal'; els.gridPatternSelect.value=state.gridPattern; render(); });
  els.gridPatternSelect.addEventListener('change', e => { state.gridPattern=e.target.value; render(); });
  els.responsiveStackInput.addEventListener('change', e => { state.responsiveStack=e.target.checked; render(); });
  [['gapInput','gap'],['paddingInput','padding'],['radiusInput','radius']].forEach(([id,field]) => els[id].addEventListener('input', e => { state[field]=Number(e.target.value); render(); }));
  [['backgroundInput','background'],['textColorInput','textColor'],['borderColorInput','borderColor'],['backgroundGradientStartInput','backgroundGradientStart'],['backgroundGradientEndInput','backgroundGradientEnd']].forEach(([id,field]) => els[id].addEventListener('input', e => { state[field]=e.target.value; render(); }));
  els.backgroundModeSelect.addEventListener('change', e => { state.backgroundMode=e.target.value; render(); });
  els.backgroundGradientAngleInput.addEventListener('input', e => { state.backgroundGradientAngle=Number(e.target.value); render(); });
  els.rootTagSelect.addEventListener('change', e => { state.rootTag=e.target.value; render(); });

  async function copyHtml() { try { await navigator.clipboard.writeText(generatedHtml()); showToast('HTML copied'); } catch { els.outputCode.focus(); els.outputCode.select(); document.execCommand('copy'); showToast('HTML copied'); } }
  els.copyBtn.addEventListener('click',copyHtml); els.copyOutputBtn.addEventListener('click',copyHtml);
  els.downloadBtn.addEventListener('click',() => { const blob=new Blob([previewDocument()],{type:'text/html'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='aq-component-test.html'; a.click(); URL.revokeObjectURL(url); });
  els.clearBtn.addEventListener('click',() => { if(confirm('Clear the component canvas?')) { const section=createSection('Section 1'); state.sections=[section]; state.activeSectionId=section.id; state.selectedId=null; render(); } });

  render();
})();
