Clean rollback package based on the last working contracts direct-display version. Removed visible escaped patch anchors from index.html. Removed failed selected-component inspector changes.
