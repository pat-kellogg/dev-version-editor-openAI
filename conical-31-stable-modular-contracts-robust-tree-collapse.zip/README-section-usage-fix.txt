Fixes Component Contracts usage scanning by reading the actual editor state.sections tree instead of only scanning rendered custom-element tags.
