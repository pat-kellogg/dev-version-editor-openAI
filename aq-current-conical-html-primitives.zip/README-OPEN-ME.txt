Open index.html in a browser.

New in this build:
HTML Primitives have been added to the Components panel so a designer can build custom structure with native tags before a future Save as Component workflow.

Use:
Components > HTML Primitives > Div / Block, Span / Inline, Heading, Paragraph, List, List Item.

These export as real HTML tags, not as editor-only wrappers.
